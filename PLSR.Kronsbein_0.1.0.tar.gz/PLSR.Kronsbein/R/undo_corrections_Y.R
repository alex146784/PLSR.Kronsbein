undo_corrections_Y <- function(model, Ydata, Ydata_transformation = TRUE){

  cat(silver("undo_corrections_Y started\n"))
  model.methodnames <- model$directorymethoddone$names.donemethods() #read the names of all methods
  if((sum((grepl("centerY", model.methodnames) + grepl("scaleY", model.methodnames) + grepl("standardizeY", model.methodnames) + (grepl("Ydata_transformation", model.methodnames)))))>0){
    #create a similar dataconstruct, like created through fread.dataprep.plsr --> easier datapreperation with existing functions
    if(length(dim(Ydata))== 2){
      data <- list(prepdata = list(Y = Ydata), oriY = list(Y.values = Ydata))

      for(i in length(model.methodnames):1){#loop to go through all performed dataprep methods saved in the model and perform them on the new data
        data.methodmethod <- model$directorymethoddone$read.this.data(model.methodnames[i]) #read all saved information of the done dataprepmethod

        #following there are all dataprepmethods listed. If one of them is equal to name of the already performed dataprepmethod, then perform this method and go to the next method in the list (model.dataprepnames)

        if(grepl("centerY", model.methodnames[i])){
          Ydata <- apply.t(Ydata, MARGIN = 1, FUN = add.spectrum, mean.spec = data.methodmethod$data$meanspectrum)
          next()
        }

        if(grepl("scaleY", model.methodnames[i])){
          Ydata <- apply.t(Ydata, MARGIN = 1, FUN = multiply.spectrum, scale.spec = data.methodmethod$data$scales)
          next()
        }

        if(grepl("standardizeY", model.methodnames[i])){
          Ydata <- apply.t(Ydata, MARGIN = 1, FUN = multiply.spectrum, scale.spec = data.methodmethod$data$sdspectrum)
          next()

        }

        if(Ydata_transformation && grepl("Ydata_transformation", model.methodnames[i])){
          if(is.null(data.methodmethod$data$backtransformationFUN)){stop("There was not passed a backtransformation function in Ydata_transformation")}
          Ydata <- data.methodmethod$data$backtransformationFUN(Ydata)
          next()
        }


      }
    }else{
      Ydata.comp <- Ydata
      Ydata.comp.new <- array(data = NA, dim = dim(Ydata.comp))
      for(i.dim in 1:dim(Ydata.comp)[3]){
        Ydata <- Ydata.comp[,,i.dim, drop = FALSE]
        Ydata <- as.matrix(Ydata)
        data <- list(prepdata = list(Y = Ydata), oriY = list(Y.values = Ydata))

        for(i in length(model.methodnames):1){#loop to go through all performed dataprep methods saved in the model and perform them on the new data
          data.methodmethod <- model$directorymethoddone$read.this.data(model.methodnames[i]) #read all saved information of the done dataprepmethod

          #following there are all dataprepmethods listed. If one of them is equal to name of the already performed dataprepmethod, then perform this method and go to the next method in the list (model.dataprepnames)

          if(grepl("centerY", model.methodnames[i])){
            Ydata <- apply.t(Ydata, MARGIN = 1, FUN = add.spectrum, mean.spec = data.methodmethod$data$meanspectrum)
            next()
          }

          if(grepl("scaleY", model.methodnames[i])){
            Ydata <- apply.t(Ydata, MARGIN = 1, FUN = multiply.spectrum, scale.spec = data.methodmethod$data$scales)
            next()
          }

          if(grepl("standardizeY", model.methodnames[i])){
            Ydata <- apply.t(Ydata, MARGIN = 1, FUN = multiply.spectrum, scale.spec = data.methodmethod$data$sdspectrum)
            next()

          }

          if(Ydata_transformation && grepl("Ydata_transformation", model.methodnames[i])){
            if(is.null(data.methodmethod$data$backtransformationFUN)){stop("There was not passed a backtransformation function in Ydata_transformation")}
            Ydata <- data.methodmethod$data$backtransformationFUN(Ydata)
            next()
          }


        }
        Ydata.comp.new[,,i.dim] <- Ydata
      }
      Ydata <- Ydata.comp.new
    }




  }
  cat(green("undo_corrections_Y completed\n"))
  return(Ydata)

}
