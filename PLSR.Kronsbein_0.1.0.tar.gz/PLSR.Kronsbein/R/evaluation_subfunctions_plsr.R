#fucntion to evaluate the plsr
PLSR.eval <- function(data,
                      which.comp,
                      plotquality = 100, #percentage of quality
                      plotwidth = 1500, #width of plot in pixels
                      plotheight = 750, #width of plot in pixels
                      plotfontsize = 23, #size of the heads of the plot
                      plottype = "l", #type of the plot; p -> points; l -> lines
                      plotpch = 20, #size of the font
                      plotcex = 0.3, #size of the datapoints
                      ...){
  cat(silver("PLSR.eval started\n"))

  check.data(data = data, model = TRUE)

  whichfunc <- "plsr.ex" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be safed
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #create a dataset to pass to the old plsr evaluation functions
    data.model <- list(model = input.l$data$model, directorymethoddone = data$directorymethoddone, kpls = input.l$data$kpls)

    #call the old evaluation functions
    summary.eval(data = data.model)
    modelcoefficients.eval(data = data.model, which.comp = which.comp)
    scoresandloadings.eval(data = data.model)
    validationplot.eval(data = data.model, which.comp = which.comp)
    if(!input.l$data$kpls) correlationplot.eval(data = data.model, which.comp = which.comp)


    #call the new evaluation functions
    if(length(which.comp) >= 2){ #normal loading and scoreplot only useful with 2 components
      suppressWarnings(dir.create("Loadingplots"))
      PLSR.loadingplot(data = data, which.comp = which.comp, saveplots = TRUE, directory = "Loadingplots", which.n.method = input.l)
      for(i.Ycol in 1:ncol(input.l$data$oriY$Y.values)){ #create a Scoreplot for each Y value, so the Y values can be shown as colours
        name.dir <- paste0("Scoreplots_Y",i.Ycol)
        PLSR.scoreplot(data = data, which.comp = which.comp, saveplots = TRUE, directory = name.dir, Ycol = i.Ycol, which.n.method = input.l)
      }
    }
    #loadingplot as for one comp against the variable
    PLSR.loadingplot.singlecomp(data = data, which.comp = which.comp, saveplots = TRUE, directory = "Loadingplots.singlecomp", which.n.method = input.l)
    for(i.Ycol in 1:ncol(input.l$data$oriY$Y.values)){  #create a Scoreplot for each Y value, so the Y values can be shown as colours
      name.dir <- paste0("Scoreplots.singlecomp_Y",i.Ycol)
      #scoreplot of one component against the sample
      PLSR.scoreplot.singlecomp(data = data, which.comp = which.comp, saveplots = TRUE, directory = name.dir, Ycol = i.Ycol, which.n.method = input.l)
    }
    #print all different screeplots for the explained variance of the components
    PLSR.screeplot(data = data, type = "var",  which.comp = which.comp, saveplots = TRUE, directory = "Screeplots", which.n.method = input.l)
    PLSR.screeplot(data = data, type = "part.var",  which.comp = which.comp, saveplots = TRUE, directory = "Screeplots", which.n.method = input.l)
    PLSR.screeplot(data = data, type = "part.cum.var",  which.comp = which.comp, saveplots = TRUE, directory = "Screeplots", which.n.method = input.l)


    for(i.Ycol in 1:ncol(input.l$data$oriY$Y.values)){ #create a predictionplot for each Y-values (measured against predicted value)
      name.dir <- paste0("Predictionplots_Y",i.Ycol)
      PLSR.predictionplot(data = data, which.comp = which.comp, saveplots = TRUE, directory = name.dir, Ycol = i.Ycol, which.n.method = input.l)
    }

    #calculate and give back R.squared for all components and Y values
    #PLSR.R.squared(data = data, which.comp = which.comp, saveplots = TRUE, directory = "R-squared", which.n.method = input.l)

    if(input.l$data$kpls){
      kpls.eval(input.l = input.l)
    }


    setwd("..")#go back to the main directory
  }

  cat(green("PLSR.eval completed\n"))

}


#function, that saves all information of the plsr summaryfunction into a file
summary.eval <- function(data, # necessary dataset
                      ...){
  cat(silver("summary.eval started\n"))
  sink("summary.txt") # safe all in this file
  if(data$kpls){
    cat("Data:")
    cat(("\nX dimension:"))
    cat(dim(data$model$X))
    cat(("\nY dimension:"))
    cat(dim(data$model$Y))
    cat("\n\nFit method: kernelpls\n")
    cat(paste0("Number of components considered: ", data$model$ncomp))
    cat("\n\nTRAINING: X variance explained relativ\n")
    Xvar <- matrix(data$model$part.var, ncol = 1)
    dimnames(Xvar) <- list(dimnames(data$model$coefficients)[[3]],"X")
    Yvar <- matrix(data$model$part.Yvar, ncol = 1)
    dimnames(Yvar) <- list(dimnames(data$model$coefficients)[[3]],"Y")
    print(t(Xvar))

    cat("\nTRAINING: Y variance explained relativ\n")
    print(t(Yvar))

  }else{
    summary(data$model)#standard summarry function
  }




  #add RMSEC to summary
  cat("\n\nRMSEC:\n")
  RMSE <- signif(data$model$RMSEC$RMSE,4)
  dimnames(RMSE) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
  print(t(RMSE))
  cat("\n")
  cat("\n\nBIAS:\n")
  BIAS <- signif(data$model$RMSEC$BIAS,4)
  dimnames(BIAS) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
  print(t(BIAS))
  cat("\n")
  cat("\n\nSE:\n")
  SE <- signif(data$model$RMSEC$SE,4)
  dimnames(SE) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
  print(t(SE))
  cat("\n")
  cat("\n\nR-squared:\n")
  R2 <- signif(data$model$RMSEC$R2,4)
  dimnames(R2) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
  print(t(R2))
  cat("\n")

  cat("\n")




  sink() #stop safing things to a file
  cat(green("summary.eval completed\n"))
}

#function to print scoreplots for two components at a time
PLSR.scoreplot <- function(data, #model of plsr.ex
                          which.comp = c(1,2), #which comp should be printed
                          colourramp = TRUE, #colour the points, depending on the Y-values
                          fixedAxes = FALSE, #if TRUE the Axes will alway have be the same scale for all components
                          labels.sample.name = FALSE, #Label the names of the datapoints
                          labels.Yvalue = FALSE, #Label the Yvalue for each datapoint
                          Ycol = 1, #for which Ycol the points will be coloured or labled
                          plotcex = 0.8, #size of the points
                          plotpch = 20, #type of datapoints
                          textcex = 0.5, #size of the text of labels
                          textpos = 3, #postion of the text of the labels (3 = above datapoints)
                          saveplots = FALSE, #save plots to jpeg files
                          directory = NULL, #if save the plots, then save them to this directory
                          plotquality = 100, #percentage of quality
                          plotwidth = 1000, #width of plot in pixels
                          plotheight = 1000, #width of plot in pixels
                          plotfontsize = 23, #size of the heads of the plot
                          col = "black", #colour of the datapoints, will be overwritten of the colourramp
                          which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                          ...){
  cat(silver("PLSR.scoreplot started\n"))

  check.data(data = data, model = TRUE) #function to know if the dataset is correct

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "plsr.ex")#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  originalY <- input.l$data.info$read.originalY()
  input.l$data$oriY$Y.values <- checkandpeform.changes.Y(model = input.l$data, Ydata = input.l$data$oriY$Y.values)
  if(originalY){
    input.l$data$oriY$Y.values <- undo_corrections_Y(model = input.l$data, Ydata = input.l$data$oriY$Y.values)
  }

  if(length(which.comp) < 2){ #check if there are at least two components
    stop("the length of the vector which.comp has to be 2 or longer, if you only want to plot one component use PLSR.scoreplot.singlcomp()")
  }

  if(labels.sample.name & labels.Yvalue){stop("only use lables.sample.name or labels.Yvalue")} #check if both is TRUE
  if(labels.sample.name){
    labels. <- rownames(input.l$data$model$scores) #take the rownames of Scores as labels
    if(is.null(labels.)){
      labels. <- 1:nrow(input.l$data$model$scores) #if there are no rownames use the rownumbers
      warning("Because there were no rownames in scores, the rownumber were used as labels.")
    }
  }
  if(labels.Yvalue){
    if(ncol(input.l$data$oriY$Y.values) < Ycol){stop("this Ycol is not available!")} #check whether Ycol is available
    labels. <- input.l$data$oriY$Y.values[,Ycol, drop = TRUE] #use the Ymatrix and choose the specified Ycol for the labels
    labels. <- round(labels., digits = 2)
  }
  if(colourramp){
    col <- Colourramp.sorted.for.Y(data = data, input.l = input.l, Ycol = Ycol) #create a vector with colours, depending on the Yvalues
    legend.col <- round(c(min(input.l$data$oriY$Y.values[,Ycol]), quantile(input.l$data$oriY$Y.values[,Ycol],0.25), median(input.l$data$oriY$Y.values[,Ycol]), quantile(input.l$data$oriY$Y.values[,Ycol],0.75), max(input.l$data$oriY$Y.values[,Ycol])), digits = 4) #values for the legend
  }
  if(fixedAxes){
    lim <- c(min(input.l$data$model$scores),max(input.l$data$model$scores)) #if fixedAxes is TRUE, use always the same dimensions for the axes
  }
  for(i1 in which.comp){ #loop for the components
    for(i2 in which.comp) #loop for the components
      if(i1 < i2){ #do the following only if i1 is smalles than i2, so all usefull combinations will be printed
        xlab <- paste0("PC", which.comp[i1], " (", round((input.l$data$model$part.var[i1]*100), digits=2),"%)") #label X-axis
        ylab <- paste0("PC", which.comp[i2], " (", round((input.l$data$model$part.var[i2]*100), digits=2),"%)") #label Y-axis
        if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
          jpeg(paste0("PLSR.scoreplot.comp=",i1, "_and_", i2, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
        }
        if(fixedAxes){ #depending on fixedAxes call the plot function with lim parameter or without
          plot(x = input.l$data$model$scores[,which.comp[i1]], y = input.l$data$model$scores[,which.comp[i2]], main = "PLSR.Scoreplot", xlab = xlab, ylab = ylab, xlim = lim, ylim = lim, type = "p", col = col, pch = plotpch, cex = plotcex)
          if(colourramp){ #add legend, if colourramp is TRUE
            legend(x = lim[1], y = lim[2], legend =legend.col, col =  c("red", "yellow", "green", "blue", "black"), pch = rep(plotpch, 5), title = colnames(input.l$data$oriY$Y.values)[Ycol])
          }
        }else{
          plot(x = input.l$data$model$scores[,which.comp[i1]], y = input.l$data$model$scores[,which.comp[i2]], main = "PLSR.Scoreplot", xlab = xlab, ylab = ylab, type = "p", col = col, pch = plotpch, cex = plotcex)
          if(colourramp){ #add legend, if colourramp is TRUE
            legend(x = min(input.l$data$model$scores[,which.comp[i1]]), y = max(input.l$data$model$scores[,which.comp[i2]]), legend = legend.col, col =  c("red", "yellow", "green", "blue", "black"), pch = rep(plotpch, 5), title = colnames(input.l$data$oriY$Y.values)[Ycol])
          }
        }
        if(labels.sample.name | labels.Yvalue){ #if there are labels, add them to the plot
          text(x = input.l$data$model$scores[,which.comp[i1]], y = input.l$data$model$scores[,which.comp[i2]], labels = labels., cex = textcex, pos = textpos)
        }

        if(saveplots){
          dev.off()#end jpg export
        }
      }
  }
  if(saveplots & !is.null(directory)){ #if necessary set working directory back to original wd
    setwd(actwd)
  }
  cat(green("PLSR.scoreplot completed\n"))
}


#function to print scoreplots for one components at a time
PLSR.scoreplot.singlecomp <- function(data, #model of plsr.ex
                                     which.comp = 1, #which comp should be printed
                                     colourramp = FALSE, #colour the points, depending on the Y-values
                                     fixedAxes = FALSE, #if TRUE the Axes will alway have be the same scale for all components
                                     labels.sample.name = FALSE, #Label the names of the datapoints
                                     labels.Yvalue = FALSE, #Label the Yvalue for each datapoint
                                     Ycol = 1, #for which Ycol the points will be coloured or labled
                                     plotcex = 0.8, #size of the points
                                     plotpch = 20, #type of datapoints
                                     textcex = 0.5, #size of the text of labels
                                     textpos = 3, #postion of the text of the labels (3 = above datapoints)
                                     saveplots = FALSE, #save plots to jpeg files
                                     directory = NULL, #if save the plots, then save them to this directory
                                     plotquality = 100, #percentage of quality
                                     plotwidth = 1000, #width of plot in pixels
                                     plotheight = 500, #width of plot in pixels
                                     plotfontsize = 23, #size of the heads of the plot
                                     col = "black", #colour of the datapoints, will be overwritten of the colourramp
                                     which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                                     ...){
  cat(silver("PLSR.scoreplot.singlecomp started\n"))

  check.data(data = data, model = TRUE)#function to know if the dataset is correct

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "plsr.ex")#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  originalY <- input.l$data.info$read.originalY()
  input.l$data$oriY$Y.values <- checkandpeform.changes.Y(model = input.l$data, Ydata = input.l$data$oriY$Y.values)
  if(originalY){
    input.l$data$oriY$Y.values <- undo_corrections_Y(model = input.l$data, Ydata = input.l$data$oriY$Y.values)
  }

  if(labels.sample.name & labels.Yvalue){stop("only use lables.sample.name or labels.Yvalue")}
  if(labels.sample.name){
    labels. <- rownames(input.l$data$model$scores) #take the rownames of Scores as labels
    if(is.null(labels.)){
      labels. <- 1:nrow(input.l$data$model$scores) #if there are no rownames use the rownumbers
      warning("Because there were no rownames in scores, the rownumber were used as labels.")
    }
  }
  if(labels.Yvalue){
    if(ncol(input.l$data$oriY$Y.values) < Ycol){stop("this Ycol is not available!")} #check whether Ycol is available
    labels. <- input.l$data$oriY$Y.values[,Ycol, drop = TRUE] #use the Ymatrix and choose the specified Ycol for the labels
    labels. <- round(labels., digits = 2)
  }
  if(colourramp){
    col <- Colourramp.sorted.for.Y(data = data, input.l = input.l, Ycol = Ycol) #create a vector with colours, depending on the Yvalues
    legend.col <- round(c(min(input.l$data$oriY$Y.values[,Ycol]), quantile(input.l$data$oriY$Y.values[,Ycol],0.25), median(input.l$data$oriY$Y.values[,Ycol]), quantile(input.l$data$oriY$Y.values[,Ycol],0.75), max(input.l$data$oriY$Y.values[,Ycol])), digits = 4) #values for the legend
  }
  if(fixedAxes){
    xlim <- c(min(input.l$data$model$scores),max(input.l$data$model$scores)) #if fixedAxes is TRUE, use always the same dimensions for the axes
  }

  ylab <- colnames(input.l$data$oriY$Y.values)[Ycol] #label Y-axis

  if(is.null(ylab)){ylab <- paste0("Ydata column nr. ", Ycol)}
  for(i1 in which.comp){ #loop for the components
    xlab <- paste0("PC", which.comp[i1], " (", round((input.l$data$model$part.var[i1]*100), digits=2),"%)") #label X-axis
    if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
      jpeg(paste0("PLSR.scoreplot.comp=",i1, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    }
    if(fixedAxes){ #depending on fixedAxes call the plot function with lim parameter or without
      plot(x = input.l$data$model$scores[,which.comp[i1]], y = input.l$data$oriY$Y.values[,Ycol], main = "PLSR.Scoreplot", xlab = xlab, ylab = ylab, xlim = xlim, type = "p", col = col, pch = plotpch, cex = plotcex)
      if(colourramp){ #add legend, if colourramp is TRUE
        legend(x = xlim[1], y = max(input.l$data$oriY$Y.values[,Ycol]), legend =legend.col, col =  c("red", "yellow", "green", "blue", "black"), pch = rep(plotpch, 5), title = colnames(input.l$data$oriY$Y.values)[Ycol])
      }
    }else{
      plot(x = input.l$data$model$scores[,which.comp[i1]], y = input.l$data$oriY$Y.values[,Ycol], main = "PLSR.Scoreplot", xlab = xlab, ylab = ylab, type = "p", col = col, pch = plotpch, cex = plotcex)
      if(colourramp){ #add legend, if colourramp is TRUE
        legend(x = min(input.l$data$model$scores[,which.comp[i1]]), y = max(input.l$data$oriY$Y.values[,Ycol]), legend = legend.col, col =  c("red", "yellow", "green", "blue", "black"), pch = rep(plotpch, 5), title = colnames(input.l$data$oriY$Y.values)[Ycol])
      }
    }
    if(labels.sample.name | labels.Yvalue){ #if there are labels, add them to the plot
      text(x = input.l$data$model$scores[,which.comp[i1]], y = input.l$data$oriY$Y.values[,Ycol], labels = labels., cex = textcex, pos = textpos)
    }
    if(saveplots){
      dev.off()#end jpg export
    }
  }
  if(saveplots & !is.null(directory)){ #if necessary set working directory back to original wd
    setwd(actwd)
  }
  cat(green("PLSR.scoreplot.singlecomp completed\n"))
}

#function to printloadingplots for two components at a time
PLSR.loadingplot <- function(data, #model of plsr.ex
                            which.comp = c(1,2), #which comp should be printed
                            fixedAxes = FALSE, #if TRUE the Axes will alway have be the same scale for all components
                            labels.variable.name = FALSE, #Label the names of the datapoints
                            labels.wavelengths = FALSE, #Label with the values of wavelengths
                            plotcex = 0.8, #size of the points
                            plotpch = 20, #type of datapoints
                            textcex = 0.5, #size of the text of labels
                            textpos = 3, #postion of the text of the labels (3 = above datapoints)
                            saveplots = FALSE, #save plots to jpeg files
                            directory = NULL, #if save the plots, then save them to this directory
                            plotquality = 100, #percentage of quality
                            plotwidth = 1000, #width of plot in pixels
                            plotheight = 1000, #width of plot in pixels
                            plotfontsize = 23, #size of the heads of the plot
                            col = "black", #colour of the datapoints
                            which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                            ...){
  cat(silver("PLSR.loadingplot started\n"))

  check.data(data = data, model = TRUE)#function to know if the dataset is correct

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "plsr.ex")#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)


  originalY <- input.l$data.info$read.originalY()
  input.l$data$oriY$Y.values <- checkandpeform.changes.Y(model = input.l$data, Ydata = input.l$data$oriY$Y.values)
  if(originalY){
    input.l$data$oriY$Y.values <- undo_corrections_Y(model = input.l$data, Ydata = input.l$data$oriY$Y.values)
  }

  if(length(which.comp) < 2){ #check if there are at least two components
    stop("the length of the vector which.comp has to be 2 or longer, if you only want to plot one component use PLSR.scoreplot.singlcomp()")
  }

  if(labels.variable.name & labels.wavelengths){stop("only use lables.variable.name or labels.wavelengths")}
  if(labels.variable.name){
    labels. <- rownames(input.l$data$model$loadings) #take the rownames of Loadings as labels
    if(is.null(labels.)){ #if there are no rownames use the rownumbers
      labels. <- 1:nrow(input.l$data$model$loadings)
      warning("Because there were no rownames in loadings, the rownumber were used as labels.")
    }
  }
  if(labels.wavelengths){
    labels. <- input.l$data$wavelengths #use the Ymatrix and choose the specified Ycol for the labels
    labels. <- round(labels., digits = 0)
  }
  if(fixedAxes){
    lim <- c(min(input.l$data$model$loadings),max(input.l$data$model$loadings)) #if fixedAxes is TRUE, use always the same dimensions for the axes
  }
  for(i1 in which.comp){ #loop for the components
    for(i2 in which.comp) #loop for the components
      if(i1 < i2){ #do the following only if i1 is smalles than i2, so all usefull combinations will be printed
        xlab <- paste0("PC", which.comp[i1], " (", round((input.l$data$model$part.var[i1]*100), digits=2),"%)") #label X-axis
        ylab <- paste0("PC", which.comp[i2], " (", round((input.l$data$model$part.var[i2]*100), digits=2),"%)") #label Y-axis
        if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
          jpeg(paste0("PLSR.loadingplot.comp=",i1, "_and_", i2, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
        }
        if(fixedAxes){ #depending on fixedAxes call the plot function with lim parameter or without
          plot(x = input.l$data$model$loadings[,which.comp[i1]], y = input.l$data$model$loadings[,which.comp[i2]], main = "PLSR.Loadingplot", xlab = xlab, ylab = ylab, xlim = lim, ylim = lim, type = "p", col = col, pch = plotpch, cex = plotcex)
        }else{
          plot(x = input.l$data$model$loadings[,which.comp[i1]], y = input.l$data$model$loadings[,which.comp[i2]], main = "PLSR.Loadingplot", xlab = xlab, ylab = ylab, type = "p", col = col, pch = plotpch, cex = plotcex)
        }
        if(labels.variable.name | labels.wavelengths){ #if there are labels, add them to the plot
          text(x = input.l$data$model$loadings[,which.comp[i1]], y = input.l$data$model$loadings[,which.comp[i2]], labels = labels., cex = textcex, pos = textpos)
        }
        if(saveplots){
          dev.off()#end jpg export
        }
      }
  }
  if(saveplots & !is.null(directory)){ #if necessary set working directory back to original wd
    setwd(actwd)
  }
  cat(green("PLSR.loadingplot completed\n"))
}

#function to printloadingplots for one component at a time
PLSR.loadingplot.singlecomp <- function(data, #model of plsr.ex
                                       which.comp = 1, #which comp should be printed
                                       fixedAxes = FALSE, #if TRUE the Axes will alway have be the same scale for all components
                                       labels.variable.name = FALSE, #Label the names of the datapoints
                                       labels.wavelengths = FALSE, #Label with the values of wavelengths
                                       plotcex = 0.8, #size of the points
                                       plotpch = 20, #type of datapoints
                                       plottype = "p", #plottype
                                       textcex = 0.5, #size of the text of labels
                                       textpos = 3, #postion of the text of the labels (3 = above datapoints)
                                       saveplots = FALSE, #save plots to jpeg files
                                       directory = NULL, #if save the plots, then save them to this directory
                                       plotquality = 100, #percentage of quality
                                       plotwidth = 1000, #width of plot in pixels
                                       plotheight = 500, #width of plot in pixels
                                       plotfontsize = 23, #size of the heads of the plot
                                       col = "black", #colour of the datapoints
                                       which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                                       ...){
  cat(silver("PLSR.loadingplot.singlecomp started\n"))

  check.data(data = data, model = TRUE)#function to know if the dataset is correct

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "plsr.ex")#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  originalY <- input.l$data.info$read.originalY()
  input.l$data$oriY$Y.values <- checkandpeform.changes.Y(model = input.l$data, Ydata = input.l$data$oriY$Y.values)
  if(originalY){
    input.l$data$oriY$Y.values <- undo_corrections_Y(model = input.l$data, Ydata = input.l$data$oriY$Y.values)
  }

  if(labels.variable.name & labels.wavelengths){stop("only use lables.variable.name or labels.wavelengths")}
  if(labels.variable.name){
    labels. <- rownames(input.l$data$model$loadings) #take the rownames of Loadings as labels
    if(is.null(labels.)){ #if there are no rownames use the rownumbers
      labels. <- 1:nrow(input.l$data$model$loadings)
      warning("Because there were no rownames in loadings, the rownumber were used as labels.")
    }
  }
  if(labels.wavelengths){
    labels. <- input.l$data$wavelengths #use the Ymatrix and choose the specified Ycol for the labels
    labels. <- round(labels., digits = 0)
  }
  if(fixedAxes){
    ylim <- c(min(input.l$data$model$loadings),max(input.l$data$model$loadings)) #if fixedAxes is TRUE, use always the same dimensions for the axes
  }



  if(input.l$data$kpls){
    xlab <- paste0("variable Kernel") #label X-axis
    for(i1 in which.comp){ #loop for the components
      ylab <- paste0("loading value PC", which.comp[i1], " (", round((input.l$data$model$part.var[i1]*100), digits=2),"%)") #label Y-axis
      if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
        jpeg(paste0("PLSR.loadingplot.comp=",i1, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
      }
      if(fixedAxes){ #depending on fixedAxes call the plot function with lim parameter or without
        plot(x = 1:nrow(input.l$data$model$loadings), y = input.l$data$model$loadings[,which.comp[i1]], main = "PLSR.Loadingplot", xlab = xlab, ylab = ylab, ylim = ylim, type = plottype, col = col, pch = plotpch, cex = plotcex)
      }else{
        plot(x = 1:nrow(input.l$data$model$loadings), y = input.l$data$model$loadings[,which.comp[i1]], main = "PLSR.Loadingplot", xlab = xlab, ylab = ylab, type = plottype, col = col, pch = plotpch, cex = plotcex)
      }
      if(labels.variable.name | labels.wavelengths){ #if there are labels, add them to the plot
        text(x = 1:nrow(input.l$data$model$loadings), y = input.l$data$model$loadings[,which.comp[i1]], labels = labels., cex = textcex, pos = textpos)
      }
      if(saveplots){
        dev.off()#end jpg export
      }
    }
  }else{
    xlab <- paste0("variable (", data$data.info$read.UnitspecX(), ")") #label X-axis
    for(i1 in which.comp){ #loop for the components
      ylab <- paste0("loading value PC", which.comp[i1], " (", round((input.l$data$model$part.var[i1]*100), digits=2),"%)") #label Y-axis
      if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
        jpeg(paste0("PLSR.loadingplot.comp=",i1, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
      }
      if(fixedAxes){ #depending on fixedAxes call the plot function with lim parameter or without
        plot(x = input.l$data$wavelengths, y = input.l$data$model$loadings[,which.comp[i1]], main = "PLSR.Loadingplot", xlab = xlab, ylab = ylab, ylim = ylim, type = plottype, col = col, pch = plotpch, cex = plotcex)
      }else{
        plot(x = input.l$data$wavelengths, y = input.l$data$model$loadings[,which.comp[i1]], main = "PLSR.Loadingplot", xlab = xlab, ylab = ylab, type = plottype, col = col, pch = plotpch, cex = plotcex)
      }
      if(labels.variable.name | labels.wavelengths){ #if there are labels, add them to the plot
        text(x = input.l$data$wavelengths, y = input.l$data$model$loadings[,which.comp[i1]], labels = labels., cex = textcex, pos = textpos)
      }
      if(saveplots){
        dev.off()#end jpg export
      }
    }
  }

  if(saveplots & !is.null(directory)){ #if necessary set working directory back to original wd
    setwd(actwd)
  }
  cat(green("PLSR.loadingplot.singlecomp completed\n"))
}

#function to print a screeplot to show the explained variance of the components
PLSR.screeplot <- function(data, #model of plsr.ex
                          which.comp = NULL, #which comp should be print, default all
                          type = "part.var", #plottype (var -> variance, part.var -> partial variance per comp, part.cum.var -> cumulative partial variance)
                          saveplots = FALSE, #save plots to jpeg files
                          directory = NULL, #if save the plots, then save them to this directory
                          plotquality = 100, #percentage of quality
                          plotwidth = 1000, #width of plot in pixels
                          plotheight = 500, #width of plot in pixels
                          plotfontsize = 23, #size of the heads of the plot
                          col = "grey", #colour of the datapoints
                          which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                          ...){
  cat(silver("PLSR.screeplot started\n"))

  check.data(data = data, model = TRUE)#function to know if the dataset is correct

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "plsr.ex")#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  if(is.null(which.comp)){ #if which.comp was not specified set to the maximum available components
    which.comp <- 1:length(input.l$data$model$var)
  }
  switch(type, #set all plot parameters depending on plot type
         "var" = {
           plot.name <- "explained variance per component"
           data.plot <- input.l$data$model$var
           jpeg.name <- "PLSR.var.plot.jpg"
           ylab = "variance"
           ylim = c(0,max(input.l$data$model$var))
         },
         "part.var" = {
           plot.name <- "percentage of the explained variance per component"
           data.plot <- input.l$data$model$part.var *100
           jpeg.name <- "PLSR.part.var.plot.jpg"
           ylab <- "percentage variance [%]"
           ylim = c(0,100)
         },
         "part.cum.var" ={
           plot.name <- "cumulative percentage of the explained variance per component"
           data.plot <- input.l$data$model$part.cum.var *100
           jpeg.name <- "PLSR.part.cum.var.plot.jpg"
           ylab <- "percentage variance [%]"
           ylim = c(0,100)
         },
         {stop("invalid character for type. Possible: \"var\", \"part.var\", \"part.cum.var\"")} #if no valid plottype was entered, print an error
  )
  if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
    jpeg(jpeg.name, quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
  }
  #print a barplot with the informations
  barplot(height = data.plot[which.comp], names.arg = which.comp, main = "PLSR.Screeplot", xlab = "component", ylab = ylab, ylim = ylim, sub = plot.name, col = col)

  if(saveplots){
    dev.off()#end jpg export
  }

  if(saveplots & !is.null(directory)){#if necessary set working directory back to original wd
    setwd(actwd)
  }

  cat(green("PLSR.screeplot completed\n"))
}

#function to print scoreplots for two components at a time
PLSR.predictionplot <- function(data, #model of plsr.ex
                           which.comp = NULL, #which comp should be printed
                           colourramp = FALSE, #colour the points, depending on the Y-values
                           fixedAxes = TRUE, #if TRUE the Axes will alway have be the same scale for all components
                           labels.sample.name = FALSE, #Label the names of the datapoints
                           labels.Yvalue = FALSE, #Label the Yvalue for each datapoint
                           Ycol = 1, #for which Ycol the points will be coloured or labled
                           plotcex = 0.8, #size of the points
                           plotpch = 20, #type of datapoints
                           textcex = 0.5, #size of the text of labels
                           textpos = 3, #postion of the text of the labels (3 = above datapoints)
                           saveplots = FALSE, #save plots to jpeg files
                           directory = NULL, #if save the plots, then save them to this directory
                           plotquality = 100, #percentage of quality
                           plotwidth = 1000, #width of plot in pixels
                           plotheight = 1000, #width of plot in pixels
                           plotfontsize = 23, #size of the heads of the plot
                           col = "black", #colour of the datapoints, will be overwritten of the colourramp
                           which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                           ...){
  cat(silver("PLSR.predictionplot started\n"))

  check.data(data = data, model = TRUE)#function to know if the dataset is correct

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "plsr.ex")

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  originalY <- input.l$data.info$read.originalY()
  input.l$data$oriY$Y.values <- checkandpeform.changes.Y(model = input.l$data, Ydata = input.l$data$oriY$Y.values)
  if(originalY){
    input.l$data$oriY$Y.values <- undo_corrections_Y(model = input.l$data, Ydata = input.l$data$oriY$Y.values)
  }

  if(labels.sample.name & labels.Yvalue){stop("only use lables.sample.name or labels.Yvalue")} #check if both is TRUE
  if(labels.sample.name){
    labels. <- rownames(input.l$data$model$scores) #take the rownames of Scores as labels
    if(is.null(labels.)){
      labels. <- 1:nrow(input.l$data$model$scores) #if there are no rownames use the rownumbers
      warning("Because there were no rownames in scores, the rownumber were used as labels.")
    }
  }
  if(labels.Yvalue){
    if(ncol(input.l$data$oriY$Y.values) < Ycol){stop("this Ycol is not available!")} #check whether Ycol is available
    labels. <- input.l$data$oriY$Y.values[,Ycol, drop = TRUE] #use the Ymatrix and choose the specified Ycol for the labels
    labels. <- round(labels., digits = 2)
  }

  if(colourramp){
    col <- Colourramp.sorted.for.Y(data = data, input.l = input.l, Ycol = Ycol) #create a vector with colours, depending on the Yvalues
    legend.col <- round(c(min(input.l$data$oriY$Y.values[,Ycol]), quantile(input.l$data$oriY$Y.values[,Ycol],0.25), median(input.l$data$oriY$Y.values[,Ycol]), quantile(input.l$data$oriY$Y.values[,Ycol],0.75), max(input.l$data$oriY$Y.values[,Ycol])), digits = 4) #values for the legend
  }



  predicted.all <- predict.ex(model = data, ncomp = 1:max(which.comp), centeredY = input.l$data.info$read.centeredY(), which.n.method = input.l, savedata.TF = FALSE)
  #measured.all <- input.l$data$directorymethoddone$read.this.data(input.l$data$directorymethoddone$names.donemethods()[1])$data$dataYori
  #measured.all <- checkandpeform.changes.Y(model = data, Ydata = measured.all, Ydata_transformation = TRUE, calc.meanspectra = TRUE)

  measured.all <- data$oriY$Y.values
  measured.all <- checkandpeform.changes.Y(model = data, Ydata = measured.all)

  if(originalY){
    measured.all <- undo_corrections_Y(model = data, Ydata = measured.all)
  }

  # if((input.l$data$directorymethoddone$is.methoddone("calc.meanspectra"))){#correct measured.all, if calc.meanspectra was used
  #   dataset.new <- list(prepdata = data.frame(Y = I(measured.all),X = I(measured.all)), oriY = list(Y.values = measured.all))
  #   dataset.new <- calc.meanspectra(data = dataset.new, mean.n.spectra = input.l$data$directorymethoddone$read.this.data(paste0("calc.meanspectra", 1))$data$mean.n.spectra, repetitions = NULL, savedata.TF = FALSE)
  #   measured.all <- dataset.new$prepdata$Y
  # }
  measured <- measured.all[,Ycol]
  if(fixedAxes){
    lim <- c(min(measured),max(measured)) #if fixedAxes is TRUE, use always the same dimensions for the axes
  }

  for(i1 in which.comp){ #loop for the components
    xlab <- paste0("measured") #label X-axis
    ylab <- paste0("predicted") #label Y-axis
    main <- paste0("Predictionplot, comp ", i1, ", ", colnames(input.l$data$oriY$Y.values)[Ycol])
    if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
      jpeg(paste0("predictionplot.comp=",i1, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    }
    predicted <- predicted.all[,Ycol,i1]
    if(fixedAxes){ #depending on fixedAxes call the plot function with lim parameter or without
      plot(x = measured, y = predicted, main = main , xlab = xlab, ylab = ylab, xlim = lim, ylim = lim, type = "p", col = col, pch = plotpch, cex = plotcex)
      lines(x=c(min(measured), max(measured)),y=c(min(measured), max(measured)), col = "gray", lwd = 2)
      if(colourramp){ #add legend, if colourramp is TRUE
        legend(x = lim[1], y = lim[2], legend =legend.col, col = c("red", "yellow", "blue", "green", "black"), pch = rep(plotpch, 5), title = colnames(input.l$data$oriY$Y.values)[Ycol])
      }
    }else{
      plot(x = measured, y = predicted, main = main , xlab = xlab, ylab = ylab, type = "p", col = col, pch = plotpch, cex = plotcex)
      lines(x=c(min(measured), max(measured)),y=c(min(measured), max(measured)), col = "gray", lwd = 2)
      if(colourramp){ #add legend, if colourramp is TRUE
        legend(x = min(measured), y = max(measured), legend = legend.col, col = c("red", "yellow", "blue", "green", "black"), pch = rep(plotpch, 5), title = colnames(input.l$data$oriY$Y.values)[Ycol])
      }
    }
    if(labels.sample.name | labels.Yvalue){ #if there are labels, add them to the plot
      text(x = measured, y = predicted, labels = labels., cex = textcex, pos = textpos)
    }

    if(saveplots){
      dev.off()#end jpg export
    }
  }
  if(saveplots & !is.null(directory)){ #if necessary set working directory back to original wd
    setwd(actwd)
  }
  cat(green("PLSR.predictionplot completed\n"))
}



#function to export all model coefficients into a csv file. Possible for the normal coefficients and for the coefficients of the original model
modelcoefficients.eval <- function(data, # necessary dataset
                                which.comp, #which components should be used
                                ...){
  cat(silver("modelcoefficients.eval started\n"))
  export.local <- data$model$coefficients
  export.file.name <- "modelcoefficients.csv" #set right file name for normal modelcoefficients

  if(is.null(which.comp)){ #if there is no information about, which components should be used, export all coefficients
    write.csv(export.local, export.file.name) #safe the data as csv file
  }else{write.csv(export.local[,,which.comp, drop = FALSE], export.file.name)} #if there is a selection of components, which should be exported, safe only this comp as csv
  cat(green("modelcoefficients.eval completed\n"))
}

scoresandloadings.eval <- function(data,
                            ...){
  cat(silver("scoresandloadings.eval started\n"))
  suppressWarnings(dir.create("scores&loadings")) #create directory; supress warnings, because folder exists already
  setwd("scores&loadings") #set working directory to this folder
  write.csv(data$model$scores, "scores.csv")
  write.csv(data$model$Yscores, "Yscores.csv")
  write.csv(data$model$loadings, "loadings.csv")
  write.csv(data$model$Yloadings, "Yloadings.csv")
  setwd("..") #set working directory back to main directory
  cat(green("scoresandloadings.eval completed\n"))
}

#prints the validationplot as jpg
#Validation plot shows the RMSEP against the number of components, so it´s possible to choose a useful number of components
validationplot.eval <- function(data, #necessary dataset
                            which.comp, #which comp should be used
                            plotquality = 100,
                            plotwidth = 1000,
                            plotheight = 500,
                            plotfontsize = 23,
                            legendpos.p = "topright",
                            ...){
  cat(silver("validationplot.eval started\n"))
  suppressWarnings(dir.create("validationplots"))
  RMSEC <- data$model$RMSEC$RMSE
  setwd("validationplots")
  for (i in 1:ncol(RMSEC)){
    jpeg(paste0("Validationplot_CV_Y",i,".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = 1:nrow(RMSEC), y = RMSEC[,i], main = paste0("Validationplot_train_Y",i), type = "l", pch = 20, cex = 0.3, xlab = "number of components", ylab = "RMSEP")
    dev.off()#end jpg export
  }
  setwd("..")
  #jpeg("validationplot.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)#describe how to export the following plot as jpg
  #plot(data$model, plottype = "validation", legendpos = legendpos.p)#draw the plot, because jpg was opened befor, as jpg
  #dev.off()#end jpg export
  cat(green("validationplot.eval completed\n"))
}



#prints correlationplot as jpg. It prints a scatterplot and if wished all plots of only two components
#a correlationplots plots two components an the axes and shows all correlations of the samples on these two components
correlationplot.eval <- function(data, #necessary dataset
                              which.comp, #which comp should be used
                              correlationplotassingleplots = TRUE, #if TRUE print in addition all plots as single plots and not in a scatterplot
                              plotquality = 100,
                              plotwidth = 500,
                              plotheight = 500,
                              plotfontsize = 23,
                              ...){
  if(length(which.comp) <= 1){
    warning("Correlationplot is not possible, because only one component was choosen")
    return()
  }

  if(correlationplotassingleplots){ #if correlationplotassingleplot is choosen create new directory and set as wd
    suppressWarnings(dir.create("Correlationplots"))
    setwd("Correlationplots")
  }


  cat(silver("correlationplot.eval started\n"))
  jpeg("correlationplot.scatter.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)#describe how to export the following plot as jpg
#Attention: suppressed warnings in plotfunction
  suppressWarnings(plot(data$model, plottype = "correlation", comps = which.comp, main = "Correlationplot")) #plot all correlationplots as a scatterplot
  dev.off()#end jpg export
  if(correlationplotassingleplots&&length(which.comp)>2){#print all correlationplots not as a scatter, only if it is choosen and there are more two components
    # algorhythm to print all plots of all combinations of two components
    min.coeff <- min(which.comp)
    max.coeff <- max(which.comp)
    for(i1 in min.coeff:max.coeff){
      for(i2 in i1:max.coeff){
        if(i1<i2){
          file.local <- paste("correlationplot.comp=",i1,"_und_",i2,".jpg", sep = "")#specify filename
          main.name <- paste("correlationplot Components ", i1, " and ", i2)#specify header of plot
          jpeg(file.local, quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)#describe how to export the following plot as jpg
#Attention: suppressed warnings in plotfunction
          suppressWarnings(plot(data$model, plottype = "correlation", comps = c(i1,i2), main = main.name))#print the plot
          dev.off()#end jpg export
        }
      }
    }
  }
  if(correlationplotassingleplots){
    setwd("..") #set working directory back to main directory
  }
  cat(green("correlationplot.eval completed\n"))
}

#function to perform the evaluation of an external validation
externalvalidation.eval <- function(data, #passed data
                                    which.comp,
                          plotquality = 100, #percentage of quality
                          plotwidth = 1500, #width of plot in pixels
                          plotheight = 750, #width of plot in pixels
                          plotfontsize = 23, #size of the heads of the plot
                          plottype = "l", #type of the plot; p -> points; l -> lines
                          plotpch = 20, #size of the font
                          plotcex = 0.8, #size of the datapoints
                          ...){
  cat(silver("externalvalidation.eval started\n"))
  whichfunc <- "externalvalidation" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.



  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be safed
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    originalY <- input.l$data.info$read.originalY()

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    RMSEP.l <- input.l$data$RMSEP.ex$RMSE

    #write all data to the right csv files
    write.csv(RMSEP.l, paste("RMSEP_externalvalidation.csv"))
    write.csv(input.l$data$newdata, "newXdata.csv")
    write.csv(input.l$data$newYdata, "newYdata.csv")
    write.csv(input.l$data$Ypred, "predYdata.csv")

    #create jpgs with all important plots
    suppressWarnings(dir.create("validationplots"))
    setwd("validationplots")
    for (i in 1:ncol(RMSEP.l)){
      jpeg(paste0("Validationplot_external_Y",i,".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
      plot(x = input.l$data$whichcomp, y = RMSEP.l[,i], main = paste0("Validationplot_external_Y",i), type = plottype, pch = plotpch, cex = plotcex, xlab = "number of components", ylab = "RMSEP")
      dev.off()#end jpg export
    }
    setwd("..")

    measured.all <- input.l$data$newYdata
    predicted.all <- input.l$data$Ypred

    #measured.all <- checkandpeform.changes.Y(model = data, Ydata = measured.all, Ydata_transformation = TRUE, calc.meanspectra = FALSE)
    #if(originalY){
    #  measured.all <- undo_corrections_Y(model = data, Ydata = measured.all)
    #}

    if(ncol(measured.all) != dim(predicted.all)[2] || nrow(measured.all) != dim(predicted.all)[1]){stop("predicted and measured values don't fit together")}
    allYcol <- 1:ncol(measured.all)

    for(Ycol in allYcol){
      directory.l <- paste0("predictionplot", "Y", Ycol)
      actwd <- getwd()
      suppressWarnings(dir.create(directory.l)) #create new directory for the performed method
      setwd(directory.l) #go into this directory

      measured <- measured.all[,Ycol]

      lim <- c(min(measured),max(measured)) #if fixedAxes is TRUE, use always the same dimensions for the axes

      for(i1 in which.comp){ #loop for the components
        xlab <- paste0("measured") #label X-axis
        ylab <- paste0("predicted") #label Y-axis
        main <- paste0("Predictionplot externalvalidation, comp ", i1, ", ", colnames(input.l$data$oriY$Y.values)[Ycol])

        jpeg(paste0("predictionplot.comp=",i1, ".jpg"), quality = plotquality, width = 1000, height = 1000, pointsize = plotfontsize)

        predicted <- predicted.all[,Ycol,i1]

        plot(x = measured, y = predicted, main = main , xlab = xlab, ylab = ylab, xlim = lim, ylim = lim, type = "p", pch = plotpch, cex = plotcex)
        lines(x=c(min(measured), max(measured)),y=c(min(measured), max(measured)), col = "gray", lwd = 2)

        dev.off()#end jpg export


      }
      setwd(actwd)

    }

    sink(file = "external validation.txt")#start writing all outputs to the file infos.txt
    cat("###external validation###\n\n") #header of the file

    cat(paste0("The external validation is for this model: ", input.l$data$modelname, "\n\n"))

    #write a file with the RMSEs of the components
    cat("\n\nRMSEP:\n")
    RMSE <- signif(data$model$RMSEP.ex$RMSE,4)
    dimnames(RMSE) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
    print(t(RMSE))
    cat("\n")
    cat("\n\nBIAS:\n")
    BIAS <- signif(data$model$RMSEP.ex$BIAS,4)
    dimnames(BIAS) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
    print(t(BIAS))
    cat("\n")
    cat("\n\nSE:\n")
    SE <- signif(data$model$RMSEP.ex$SE,4)
    dimnames(SE) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
    print(t(SE))
    cat("\n")
    cat("\n\nR-squared:\n")
    R2 <- signif(data$model$RMSEP.ex$R2,4)
    dimnames(R2) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
    print(t(R2))
    cat("\n")

    sink() #stop writting outputs to a file

    setwd("..")#go back to the main directory
  }

  cat(green("externalvalidation.eval completed\n"))
}

#fucntion to perform the evaluation of an crossalidation, especially the creation of segments, the results are printed in summary of plsr.ex
crossvalidation.eval <- function(data, #passed data
                                 which.comp,
                                    plotquality = 100, #percentage of quality
                                    plotwidth = 1500, #width of plot in pixels
                                    plotheight = 750, #width of plot in pixels
                                    plotfontsize = 23, #size of the heads of the plot
                                    plottype = "l", #type of the plot; p -> points; l -> lines
                                    plotpch = 20, #size of the font
                                    plotcex = 0.8, #size of the datapoints
                                    ...){
  cat(silver("crossvalidation.eval started\n"))
  whichfunc <- "crossvalidation" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be safed
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    originalY <- input.l$data.info$read.originalY()

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    if(input.l$data$own.CV){
      RMSEP.l <- input.l$data$RMSEP.CV$RMSE

      #write all data to the right csv files
      write.csv(RMSEP.l, paste("RMSEP_crossvalidation.csv"))
      write.csv(input.l$data$measured.all, "measuredYdata.csv")
      write.csv(input.l$data$Y.pred, "predictedYdata.csv")

      #create jpgs with all important plots
      suppressWarnings(dir.create("validationplots"))
      setwd("validationplots")
      for (i in 1:ncol(RMSEP.l)){
        jpeg(paste0("Validationplot_CV_Y",i,".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
        plot(x = 1:input.l$data$ncomp, y = RMSEP.l[,i], main = paste0("Validationplot_CV_Y",i), type = plottype, pch = plotpch, cex = plotcex, xlab = "number of components", ylab = "RMSEP")
        dev.off()#end jpg export
      }
      setwd("..")

      measured.all <- input.l$data$measured.all
      predicted.all <- input.l$data$Y.pred

      #measured.all <- checkandpeform.changes.Y(model = data, Ydata = measured.all, Ydata_transformation = TRUE, calc.meanspectra = FALSE)
      #if(originalY){
      #  measured.all <- undo_corrections_Y(model = data, Ydata = measured.all)
      #}

      if(ncol(measured.all) != dim(predicted.all)[2] || nrow(measured.all) != dim(predicted.all)[1]){stop("predicted and measured values don't fit together")}
      allYcol <- 1:ncol(measured.all)

      for(Ycol in allYcol){
        directory.l <- paste0("predictionplot", "Y", Ycol)
        actwd <- getwd()
        suppressWarnings(dir.create(directory.l)) #create new directory for the performed method
        setwd(directory.l) #go into this directory

        measured <- measured.all[,Ycol]

        lim <- c(min(measured),max(measured)) #if fixedAxes is TRUE, use always the same dimensions for the axes

        for(i1 in which.comp){ #loop for the components
          xlab <- paste0("measured") #label X-axis
          ylab <- paste0("predicted") #label Y-axis
          main <- paste0("Predictionplot crossvalidation, comp ", i1, ", ", colnames(input.l$data$oriY$Y.values)[Ycol])

          jpeg(paste0("predictionplot.comp=",i1, ".jpg"), quality = plotquality, width = 1000, height = 1000, pointsize = plotfontsize)

          predicted <- predicted.all[,Ycol,i1]

          plot(x = measured, y = predicted, main = main , xlab = xlab, ylab = ylab, xlim = lim, ylim = lim, type = "p", pch = plotpch, cex = plotcex)
          lines(x=c(min(measured), max(measured)),y=c(min(measured), max(measured)), col = "gray", lwd = 2)

          dev.off()#end jpg export


        }
        setwd(actwd)

      }



      sink(file = "infos cross validation.txt")#start writing all outputs to the file infos.txt
      cat("###infos cross validation###\n\n") #header of the file
      cat("The crossvalidation was performed with the own crossvalidation() functionYou can find the results of the Cross Validation in the summary file\n\n")
      if(!is.null(input.l$data$segments.CV)){cat(paste0("The dataset was split into ", input.l$data$segments.CV, "parts (segments.CV).\n"))}
      if(!is.null(input.l$data$segments.type.CV)){cat(paste0("This method was used to select segments: ", input.l$data$segments.type.CV, " (segments.type.CV)\n" ))}
      if(!is.null(input.l$data$repetitions)){cat(paste0("In the dataset every datapoint was repeated ", input.l$data$repetitions, " times (repetitions).\nThis circumstance was mentioned in the creation of the segments."))}
      sink() #stop writting outputs to a file

      sink(file = "segments cross validation.txt")#start writing all outputs to the file infos.txt
      print(input.l$data$segments)
      sink() #stop writting outputs to a file

      sink(file = "crossvalidation.txt")#start writing all outputs to the file infos.txt
      cat("###crossvalidation###\n\n") #header of the file

      cat(paste0("The crossvalidation is for this model: ", input.l$data$modelname, "\n\n"))

      #write a file with the RMSEs of the components
      cat("\n\nRMSEP:\n")
      RMSE <- signif(data$model$RMSEP.CV$RMSE,4)
      dimnames(RMSE) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
      print(t(RMSE))
      cat("\n")
      cat("\n\nBIAS:\n")
      BIAS <- signif(data$model$RMSEP.CV$BIAS,4)
      dimnames(BIAS) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
      print(t(BIAS))
      cat("\n")
      cat("\n\nSE:\n")
      SE <- signif(data$model$RMSEP.CV$SE,4)
      dimnames(SE) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
      print(t(SE))
      cat("\n")
      cat("\n\nR-squared:\n")
      R2 <- signif(data$model$RMSEP.CV$R2,4)
      dimnames(R2) <- list(dimnames(data$model$coefficients)[[3]],dimnames(data$model$coefficients)[[2]])
      print(t(R2))
      cat("\n")

      sink() #stop writting outputs to a file
      setwd("..")#go back to the main directory

    }else{
      sink(file = "infos cross validation.txt")#start writing all outputs to the file infos.txt
      cat("###infos cross validation###\n\n") #header of the file
      cat("You can find the results of the Cross Validation in the summary file in directory plsr.ex\n\n")
      if(!is.null(input.l$data$segments.CV)){cat(paste0("The dataset was split into ", input.l$data$segments.CV, "parts (segments.CV).\n"))}
      if(!is.null(input.l$data$segments.type.CV)){cat(paste0("This method was used to select segments: ", input.l$data$segments.type.CV, " (segments.type.CV)\n" ))}
      if(!is.null(input.l$data$repetitions)){cat(paste0("In the dataset every datapoint was repeated ", input.l$data$repetitions, " times (repetitions).\nThis circumstance was mentioned in the creation of the segments."))}
      sink() #stop writting outputs to a file

      sink(file = "segments cross validation.txt")#start writing all outputs to the file infos.txt
      print(input.l$data$segments)
      sink() #stop writting outputs to a file
      setwd("..")#go back to the main directory


    }
  }

  cat(green("crossvalidation.eval completed\n"))
}


prediction.eval <- function(data,
                            ...){
  cat(silver("prediction.eval started\n"))
  whichfunc <- "prediction" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be safed
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    write.csv(input.l$data$newdata, file = "newXdata.csv")
    write.csv(input.l$data$predictions, file = "predictionsY.csv")

    sink(file = "info.txt")
    cat(paste0("As model this model was used: ", input.l$data$modelname, "\n\n"))
    sink()

    setwd("..")#go back to the main directory
   }

   cat(green("prediction.eval completed\n"))
}

kpls.eval <- function(input.l,...){
  cat(silver("kpls.eval started\n"))
  kpls.data <- input.l$data$kpls.data

  suppressWarnings(dir.create("kernelpls")) #create new directory for the performed method
  setwd("kernelpls") #go into this directory

  sink("kpls.function.txt")
  print(kpls.data$kFUN)
  sink()

  sink("kpls.info.txt")
  cat("For the modelcalculation a kernelpls was used.\n\n")
  cat(paste0("The kernelfunction was: ", kpls.data$kfun, "\n\n"))
  cat("The following parameters were used, if they are necessary for the choosen kernelfunction:\n")
  cat(paste0("sigma: ", kpls.data$sigma, "\n"))
  cat(paste0("degree: ", kpls.data$degree, "\n"))
  cat(paste0("scale: ", kpls.data$scale, "\n"))
  cat(paste0("offset: ", kpls.data$offset, "\n"))
  cat(paste0("order: ", kpls.data$order, "\n"))
  sink()

  setwd("..")
  cat(green("kpls.eval completed\n"))
}

