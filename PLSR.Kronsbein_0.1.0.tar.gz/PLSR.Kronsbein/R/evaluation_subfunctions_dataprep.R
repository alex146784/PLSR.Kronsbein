dataprep.plsr.eval <- function(data, #passed data
                        plotquality = 100, #percentage of quality
                        plotwidth = 1000, #width of plot in pixels
                        plotheight = 500, #width of plot in pixels
                        plotfontsize = 17, #size of the heads of the plot
                        ...){
  cat(silver("dataprep.plsr.eval started\n"))
  whichfunc <- "dataprep.plsr" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc)  #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    write.csv(input.l$data$dataX, paste("dataX.csv")) #write all X-data to a csv file
    write.csv(input.l$data$dataY, paste("dataY(possibly centered).csv")) #write all Y-data to a csv file
    write.csv(input.l$data$wavelengths, paste("wavelengths.csv")) #write all wavelengths to this file
    if(input.l$data$infos$centerY){ #create this files only, if the Y was centered
      write.csv(input.l$data$dataYori, paste("dataYori.csv")) #write all original Y-data to a csv file
      write.csv(input.l$data$dataYmean, paste("dataYmean.csv")) #write the mean values of the Ys to a csv file
    }
    #create a jpg with the plot of all original spectra
    jpeg("all_original_spectra.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$dataX, name = "all original spectra", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    #create a jpg with the plot of the first original spectra
    jpeg("first_original_spectrum.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$dataX[1,], type = "l", main = "first original spectrum", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export

    sink(file = "infos.txt")#start writing all outputs to the file infos.txt
    cat("###infofile for dataprep.plsr###\n\n") #header of the file
    #write into the file all following informations

    if(is.null(input.l$data$dataY)){cat("NO YDATA were passed, they are necessary for the modelcalculation!\n\n")}
    #additional informations, if fread.MPA2.dataprep.plsr function was used
    if(input.l$data$add.infos$dataprep.method == "fread.MPA2.dataprep.plsr"){
      cat("The function fread.MPA2.dataprep.plsr was used to prepare the data.\n\n")

      cat(paste0("The directory of the files was: ", input.l$data$add.infos$directory, "\n"))
      cat(paste0("The single spectra were loaded out of this subdirectory: ", input.l$data$add.infos$dirspectra, "\n"))
      cat(paste0("The source for Y data was: ", input.l$data$add.infos$sourceYfile, "\n"))
      if(!is.null(input.l$data$add.infos$sourceYcol)){cat(paste0("The columns for the Y data were: "))
                                                           cat(paste0(input.l$data$add.infos$sourceYcol, " "))
                                                            cat("\n")}
      if(input.l$data$add.infos$repeatYvalues && !is.null(input.l$data$repetitions)){cat(paste0("All Y data were repeated ", input.l$data$repetitions, " times.\n"))}

    }

    #additional informations, if fread.dataprep.plsr function was used
    if(input.l$data$add.infos$dataprep.method == "fread.dataprep.plsr"){
      cat("The function fread.dataprep.plsr was used to prepare the data.\n\n")
      cat(paste0("The directory of the files was: ", input.l$data$add.infos$directory, "\n"))

      if(!is.null(input.l$data$add.infos$sourcefile)){cat(paste0("The source for X and Y data was: ", input.l$data$add.infos$sourcefile, "\n"))}
      if(!is.null(input.l$data$add.infos$sourceXfile)){cat(paste0("The source for X data was: ", input.l$data$add.infos$sourceXfile, "\n"))}
      if(!is.null(input.l$data$add.infos$sourceYfile)){cat(paste0("The source for Y data was: ", input.l$data$add.infos$sourceYfile, "\n"))}
      if(!is.null(input.l$data$add.infos$sourcefile)){cat(paste0("The columns for the X data were: ", input.l$data$add.infos$sourceXcol, "\n"))}
      if(!is.null(input.l$data$add.infos$sourcefile)){cat(paste0("The columns for the Y data were: ", input.l$data$add.infos$sourceYcol, "\n"))}
    }
    cat(paste0("\n\nThe initial Unit for the X data of the spectra was: ",input.l$data$UnitspecX, "\n" ))
    cat(paste0("The initial Unit for the Y data of the spectra was: ",input.l$data$UnitspecY, "\n" ))
    if(!is.null(input.l$data$repetitions)){cat(paste0("\n\n Each measurement was repeated ", input.l$data$repetitions, "times.\n"))}

    if(input.l$data$infos$originalY){"\n\nAll the Ydata will be corrected to original Y-values for the evaluation of the plsr, validation, prediction and view spectra funcitons."}
    if(input.l$data$infos$centerY){cat("\n\nThe Y-data were centered to prevent bugs, the predictfunction will calculate the prediction considering this circumstance.")}
    sink() #stop writting outputs to a file
    setwd("..") #go back to the main directory
  }
  cat(green("dataprep.plsr.eval completed\n"))
}

splitdata.exval.eval <- function(data, #passed data
                                           plotquality = 100, #percentage of quality
                                           plotwidth = 1000, #width of plot in pixels
                                           plotheight = 500, #width of plot in pixels
                                           plotfontsize = 17, #size of the heads of the plot
                                           ...){
  cat(silver("splitdata.exval.eval started\n"))
  whichfunc <- "splitdata.exval" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc)  #read how often this method was performed, to know how often the following loop has be performed.


  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$train.X, "train.X.csv")
    write.csv(input.l$data$test.X, "test.X.csv")
    write.csv(input.l$data$test.orig.Y, "test.orig.Y.csv")
    write.csv(input.l$data$test.orig.Y.center, "test.orig.Y.center.csv")

    #start writing all outputs to the file infos.txt
    sink(file = "infos.txt")
    cat("###infofile for splitdata.externalvalidation###\n\n")
    cat(paste0("The source of the file was: ", input.l$data$infos$directory, "\n"))
    splitpercentage <- (input.l$data$infos$trainvalues.ratio *100)
    cat(paste0(splitpercentage, "% of the data were used as train data and ", (100-splitpercentage), "% of the data were used as test data.\n"))
    sink() #stop writting outputs to a file
    setwd("..")
  }
  cat(green("splitdata.exval.eval completed\n"))
}

EtoT_TtoE.eval <- function(data,#passed data
                   TtoE = FALSE, #TRUE, if performed method was TtoE; use the same function for two methods
                   EtoT = FALSE, #TRUE, if performed method was EtoT
                   plotquality = 100, #percentage of quality
                   plotwidth = 1000, #width of plot in pixels
                   plotheight = 500, #width of plot in pixels
                   plotfontsize = 17, #size of the heads of the plot
                   ...){
  cat(silver("EtoT_TtoE.eval started\n"))
  #prevent errors with the booleans TtoE and EtoT
  if(TtoE & EtoT){stop("EtoT and TtoE TRUE --> impossible to do both at the same time.")}
  if(!TtoE & !EtoT){stop("No option choosen, please set EtoT or TtoE TRUE")}
  #set which function depending to the performed method
  if(TtoE){
    whichfunc <- "Transmission_to_Extinction"
    ylab.befor <- "Transmission"
    ylab.after <- "Extinction"
    }
  if(EtoT){
    whichfunc <- "Extinction_to_Transmission"
    ylab.befor <- "Extinction"
    ylab.after <- "Transmission"
    }
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste0("databefor ", whichfunc, ".csv"))
    write.csv(input.l$data$dataafter, paste0("dataafter ", whichfunc, ".csv"))
    #create jpgs with all important plots
    jpeg(paste0("spectra_befor_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$databefor, name = paste0("spectra befor ", whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = ylab.befor, silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("spectra_after_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$dataafter, name = paste0("spectra after ", whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = ylab.after, silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_befor_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$databefor[1,], type = "l", main = paste0("first spectrum befor ", whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = ylab.befor)
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_after_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$dataafter[1,], type = "l", main = paste0("first spectrum after ", whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab =ylab.after)
    dev.off()#end jpg export
    setwd("..")#go back to the main directory
  }
  cat(green("EtoT_TtoE.eval completed\n"))
}

wn_to_wl__wl_to_wn.eval <- function(data,#passed data
                           wn_to_wl = FALSE, #TRUE, if performed method was wn_to_wl; use the same function for two methods
                           wl_to_wn = FALSE, #TRUE, if performed method was wl_to_wn
                           plotquality = 100, #percentage of quality
                           plotwidth = 1000, #width of plot in pixels
                           plotheight = 500, #width of plot in pixels
                           plotfontsize = 17, #size of the heads of the plot
                           ...){
  cat(silver("wn_to_wl__wl_to_wn.eval started\n"))
  #prevent errors with the booleans wn_to_wl and wl_to_wn
  if(wn_to_wl & wl_to_wn){stop("wl_to_wn and wn_to_wl TRUE --> impossible to do both at the same time.")}
  if(!wn_to_wl & !wl_to_wn){stop("No option choosen, please set wl_to_wn or wn_to_wl TRUE")}
  #set which function depending to the performed method
  if(wn_to_wl){
    whichfunc <- "Wavenumber_to_Wavelength"
    xlab.befor <- "Wavenumber [cm^-1]"
    xlab.after <- "Wavelength [nm]"
  }
  if(wl_to_wn){
    whichfunc <- "Wavelength_to_Wavenumber"
    xlab.befor <- "Wavelength [nm]"
    xlab.after <- "Wavenumber [cm^-1]"
  }
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$wavelengthsbefor, paste0("wavelengthsbefor ", whichfunc, ".csv"))
    write.csv(input.l$data$wavelengthsafter, paste0("wavelengthsafter ", whichfunc, ".csv"))
    #create jpgs with all important plots
    jpeg(paste0("spectra_befor_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsbefor, Y = input.l$data$data, name = paste0("spectra befor ", whichfunc),xlab = xlab.befor ,ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("spectra_after_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsafter, Y = input.l$data$data, name = paste0("spectra after ", whichfunc),xlab = xlab.after ,ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_befor_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsbefor, y = input.l$data$data[1,], type = "l", main = paste0("first spectrum befor ", whichfunc),xlab = xlab.befor ,ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_after_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsafter, y = input.l$data$data[1,], type = "l", main = paste0("first spectrum after ", whichfunc),xlab = xlab.after ,ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    setwd("..")#go back to the main directory
  }
  cat(green("wn_to_wl__wl_to_wn.eval completed\n"))
}

cutspectrum.eval <- function(data, #passed data
                          plotquality = 100, #percentage of quality
                          plotwidth = 1000, #width of plot in pixels
                          plotheight = 500, #width of plot in pixels
                          plotfontsize = 17, #size of the heads of the plot
                          plottype = "p", #type of the plot; p -> points; l -> lines
                          plotpch = 20, #size of the font
                          plotcex = 0.3, #size of the datapoints
                          ...){
  cat(silver("cutspectrum.eval started\n"))
  whichfunc <- "cutspectrum"  #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("databefor.csv"))
    write.csv(input.l$data$dataafter, paste("dataafter.csv"))
    write.csv(input.l$data$wavelengthsbefor, paste("wavelengthsbefor.csv"))
    write.csv(input.l$data$wavelengthsafter, paste("wavelengthsafter.csv"))

    #create jpgs with all important plot
    jpeg("spectra_befor_cut.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsbefor, Y = input.l$data$databefor, name = "spectra befor cut", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("spectra_after_cut.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsafter, Y = input.l$data$dataafter, name = "spectra after cut", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("first_spectrum_befor_cut.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsbefor, y = input.l$data$databefor[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum befor cut", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg("first_spectrum_after_cut.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsafter, y = input.l$data$dataafter[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum after cut", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    sink(file = "cuts.txt") #start writing all done cuts to the file cuts.txt
    cat("###documentation of the cuts for cutspectrum###\n\n")
    cuts <- input.l$data$allcuts# read the datamatrix of all cuts
    if(!is.null(cuts)){#if there are any cuts go on
      if(nrow(cuts > 0)){ #if there are any cuts go on
        for (i in 1:nrow(cuts)){ #go through the rows, each row is one cut
          if(cuts[i,3]== "w"){typeofcut <- "wavelengths"} #a w in the third column means that the cuts were performed with the wavelengths
          if(cuts[i,3]== "n"){typeofcut <- "numbers"} #a n in the third column means that the cuts were performed with the numbers
          cat(paste0(i, ".\tfrom ", cuts[i,1], " to ", cuts[i,2], " with method ", typeofcut, "\n")) #write down the informations
        }
      }
    }

    sink() #stop writting outputs to a file
    setwd("..") #go back to the main directory
  }
  cat(green("cutspectrum.eval completed\n"))
}

MSC.adapted.eval <- function(data, #passed data
                          plotquality = 100, #percentage of quality
                          plotwidth = 1000, #width of plot in pixels
                          plotheight = 500, #width of plot in pixels
                          plotfontsize = 17, #size of the heads of the plot
                          plottype = "l", #type of the plot; p -> points; l -> lines
                          plotpch = 20, #size of the font
                          plotcex = 0.3, #size of the datapoints
                          ...){
  cat(silver("MSC.adapted.eval started\n"))
  whichfunc <- "MSC.adapted" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("databefor.csv"))
    write.csv(input.l$data$dataafter, paste("dataafter.csv"))
    write.csv(input.l$data$referencespectrum, paste("referencespectrum.csv"))
    write.csv(input.l$data$wavelengths, paste("wavelengths.csv"))

    #create jpgs with all important plots
    jpeg("spectra_befor_MSC.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$databefor, name = "spectra befor MSC", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("spectra_after_MSC.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$dataafter, name = "spectra after MSC", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("first_spectrum_befor_MSC.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$databefor[1,], type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), main = "first spectrum befor MSC")
    dev.off()#end jpg export
    jpeg("first_spectrum_after_MSC.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$dataafter[1,], type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), main = "first spectrum after MSC")
    dev.off()#end jpg export
    jpeg("referencespectrum.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$referencespectrum, type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), main = "referencespectrum")
    dev.off()#end jpg export
    setwd("..")#go back to the main directory
  }
  cat(green("MSC.adapted.eval completed\n"))
}

pbc.eval <- function(data, #passed data
                  plotquality = 100, #percentage of quality
                  plotwidth = 1000, #width of plot in pixels
                  plotheight = 500, #width of plot in pixels
                  plotfontsize = 17, #size of the heads of the plot
                  plottype = "l", #type of the plot; p -> points; l -> lines
                  plotpch = 20, #size of the font
                  plotcex = 0.3, #size of the datapoints
                  ...){
  cat(silver("pbc.eval started\n"))
  whichfunc <- "pbc" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("databefor.csv"))
    write.csv(input.l$data$dataafter, paste("dataafter.csv"))
    write.csv(input.l$data$baseline, paste("baseline.csv"))
    write.csv(input.l$data$wavelengths, paste("wavelengths.csv"))

    #create jpgs with all important plots
    jpeg("spectra_befor_pbc.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$databefor, name = "spectra befor pbc", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("spectra_after_pbc.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$dataafter, name = "spectra after pbc", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("spectra_befor_pbc_with_underground.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = rbind(input.l$data$databefor, input.l$data$baseline), name = "spectra befor pbc with underground", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("first_spectrum_befor_pbc.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$databefor[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum befor pbc", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg("first_spectrum_after_pbc.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$dataafter[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum after pbc", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg("first_spectrum_befor_pbc_with_underground.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = rbind(input.l$data$databefor[1,], input.l$data$baseline[1,]), name = "first spectrum befor pbc with underground", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("baseline.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$baseline, name = "baselines", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export


    sink(file = "infos.txt")#start writing all outputs to the file infos.txt
    cat("###infofile for polynomial baseline correction###\n\n") #header of the file
    if(input.l$data$multithread){cat("Multithread was used, so all cores were used to perform the calculations.\n\n")}
    model <- "" #variable for a string with the model is empty at the beginning
    for (i in input.l$data$model : 0){ #loop for every power in the model, beginning with the highest
      if(i == 0){model <- paste0(model,"Y-Intercept")} #if the power is 0, than add Y-Intercept
      else{model <- paste0(model, "X^", i, " + ")} #else add the right term

    }
    cat(paste0("Model: ",model, "\n")) #print info model
    cat(paste0("Threshold: ", input.l$data$threshold, "\n")) #print info threshold
    sink() #stop writting outputs to a file
    setwd("..") #go back to the main directory
  }
  cat(green("pbc.eval completed\n"))
}


smoothing_derivation.eval <- function(data, #passed data
                        smoothing.mean = FALSE, #TRUE, if performed method was smoothing.mean; use the same function for three methods
                        smoothing.sg = FALSE, #TRUE, if performed method was smoothing.sg
                        derivation.sg = FALSE, #TRUE, if performed method was derivation.sg
                        plotquality = 100, #percentage of quality
                        plotwidth = 1000, #width of plot in pixels
                        plotheight = 500, #width of plot in pixels
                        plotfontsize = 17, #size of the heads of the plot
                        ...){
  cat(silver("smoothing_derivation.eval started\n"))
  #prevent errors with the booleans for the different methods
  if(sum(smoothing.mean, smoothing.sg, derivation.sg)>1){stop("Choose only one method of smoothing.mean, smoothing.sg or derivation.sg")}
  if(sum(smoothing.mean, smoothing.sg, derivation.sg)==0){stop("No option choosen, please set one smoothing.mean, smoothing.sg or derivation.sg TRUE")}
  #set which function depending to the performed method
  if(smoothing.mean){whichfunc <- "smoothing.mean"}
  if(smoothing.sg){whichfunc <- "smoothing.sg"}
  if(derivation.sg){whichfunc <- "derivation.sg"}

  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste0("databefor ", whichfunc, ".csv"))
    write.csv(input.l$data$dataafter, paste0("dataafter ", whichfunc, ".csv"))
    write.csv(input.l$data$wavelengthsbefor, paste0("wavelengthsbefor ", whichfunc, ".csv"))
    write.csv(input.l$data$wavelengthsafter, paste0("wavelengthsafter ", whichfunc, ".csv"))

    #create jpgs with all important plots
    jpeg(paste0("spectra_befor_",whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsbefor, Y = input.l$data$databefor, name = paste0("spectra befor ",whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("spectra_after_",whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsafter, Y = input.l$data$dataafter, name = paste0("spectra after ",whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_befor_",whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsbefor, y = input.l$data$databefor[1,], type = "l", main = paste0("first spectrum befor ",whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_after_",whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsafter, y = input.l$data$dataafter[1,], type = "l", main = paste0("first spectrum after ",whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    sink(file = "infos.txt") #start writing all outputs to the file infos.txt
    cat(paste0("###infofile for ", whichfunc, "###\n\n")) #header of the file
    cat(paste0("Degreeofsmoothing: ", input.l$data$infos$degreeofsmoothing, "\n"))
    if(!smoothing.mean){ #if method was not smoothing.mean, print the used model. (explanation function above)
      model <- ""
      for (i in input.l$data$infos$model : 0){
        if(i == 0){model <- paste0(model,"Y-Intercept")}
        else{model <- paste0(model, "X^", i, " + ")}
      }
      cat(paste0("Model: ",model, "\n"))
    }
    if(derivation.sg){cat(paste0("Grade of derivation: ", input.l$data$infos$derivation, "\n"))} #if method was derivation.sg print the derivation
    #add some information depending on the method an the parameters
    if(derivation.sg & input.l$data$infos$repeatfirstderivation){cat("Repeatfirstderivation was choosen \n\t--> If the grade of the derivation is bigger than 1, the first derivation was repeated as much times as the derivation.\n")}
    sink() #stop writting outputs to a file
    setwd("..") #go back to the main directory
  }
  cat(green("smoothing_derivation.eval completed\n"))
}

centerX_scaleX_standardizeX.eval <- function(data,  #passed data
                                   center = FALSE, #TRUE, if performed method was center; use the same function for three methods
                                   scale = FALSE, #TRUE, if performed method was scale
                                   standardize = FALSE, #TRUE, if performed method was standardize
                                   plotquality = 100, #percentage of quality
                                   plotwidth = 1000, #width of plot in pixels
                                   plotheight = 500, #width of plot in pixels
                                   plotfontsize = 17, #size of the heads of the plot
                                   ...){
  cat(silver("centerX_scaleX_standardizeX.eval started\n"))
  #prevent errors with the booleans for the different methods
  if(sum(center, scale, standardize)>1){stop("Choose only one method of center, scale or standardize")}
  if(sum(center, scale, standardize)==0){stop("No option choosen, please set one center, scale or standardize TRUE")}
  #set which function depending to the performed method
  if(center){whichfunc <- "centerX"}
  if(scale){whichfunc <- "scaleX"}
  if(standardize){whichfunc <- "standardizeX"}
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste0("databefor ", whichfunc, ".csv"))
    write.csv(input.l$data$dataafter, paste0("dataafter ", whichfunc, ".csv"))
    write.csv(input.l$data$wavelengths, paste0("wavelengths ", whichfunc, ".csv"))
    if(center){write.csv(input.l$data$meanspectrum, "meanspectrum.csv")}
    if(scale){write.csv(input.l$data$scales, "scales.csv")}
    if(standardize){write.csv(input.l$data$sdspectrum, "standard deviation spectrum.csv")}

    #create jpgs with all important plots
    jpeg(paste0("spectra_befor_",whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$databefor, name = paste0("spectra befor ",whichfunc), xlab = input.l$data$old.UnitspecX, ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("spectra_after_",whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$dataafter, name = paste0("spectra after ",whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_befor_",whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$databefor[1,], type = "l", main = paste0("first spectrum befor ",whichfunc), xlab = input.l$data$old.UnitspecX, ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_after_",whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$dataafter[1,], type = "l", main = paste0("first spectrum after ",whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    if(center){
      jpeg("meanspectrum.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
      plot(x = input.l$data$wavelengths, y = input.l$data$meanspectrum, type = "l", main = "meanspectrum", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
      dev.off()
    }
    if(scale){
      jpeg("scales.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
      plot(x = input.l$data$wavelengths, y = input.l$data$scales, type = "l", main = "scales", xlab = input.l$data$old.UnitspecX, ylab = input.l$data.info$read.UnitspecY())
      dev.off()
    }
    if(standardize){
      jpeg("standarddeviation.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
      plot(x = input.l$data$wavelengths, y = input.l$data$sdspectrum, type = "l", main = "standarddeviation", xlab = input.l$data$old.UnitspecX, ylab = input.l$data.info$read.UnitspecY())
      dev.off()
    }
    setwd("..")#go back to the main directory
  }
  cat(green("centerX_scaleX_standardizeX.eval completed\n"))
}

centerY_scaleY_standardizeY.eval <- function(data,  #passed data
                                             center = FALSE, #TRUE, if performed method was center; use the same function for three methods
                                             scale = FALSE, #TRUE, if performed method was scale
                                             standardize = FALSE, #TRUE, if performed method was standardize
                                             plotquality = 100, #percentage of quality
                                             plotwidth = 1000, #width of plot in pixels
                                             plotheight = 500, #width of plot in pixels
                                             plotfontsize = 17, #size of the heads of the plot
                                             ...){
  cat(silver("centerY_scaleY_standardizeY.eval started\n"))
  #prevent errors with the booleans for the different methods
  if(sum(center, scale, standardize)>1){stop("Choose only one method of center, scale or standardize")}
  if(sum(center, scale, standardize)==0){stop("No option choosen, please set one center, scale or standardize TRUE")}
  #set which function depending to the performed method
  if(center){whichfunc <- "centerY"}
  if(scale){whichfunc <- "scaleY"}
  if(standardize){whichfunc <- "standardizeY"}
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #select the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste0("databefor ", whichfunc, ".csv"))
    write.csv(input.l$data$dataafter, paste0("dataafter ", whichfunc, ".csv"))
    if(center){write.csv(input.l$data$meanspectrum, "meanvalues.csv")}
    if(scale){write.csv(input.l$data$scales, "scales.csv")}
    if(standardize){write.csv(input.l$data$sdspectrum, "standard deviations.csv")}
    setwd("..")#go back to the main directory
  }
  cat(green("centerY_scaleY_standardizeY.eval completed\n"))
}

SNV.eval <- function(data, #passed data
                          plotquality = 100, #percentage of quality
                          plotwidth = 1000, #width of plot in pixels
                          plotheight = 500, #width of plot in pixels
                          plotfontsize = 17, #size of the heads of the plot
                          plottype = "l", #type of the plot; p -> points; l -> lines
                          plotpch = 20, #type of datapoints
                          plotcex = 0.3, #size of the datapoints
                          ...){
  cat(silver("SNV.eval started\n"))
  whichfunc <- "SNV" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("databefor.csv"))
    write.csv(input.l$data$dataafter, paste("dataafter.csv"))
    write.csv(input.l$data$wavelengths, paste("wavelengths.csv"))

    #create jpgs with all important plots
    jpeg("spectra_befor_SNV.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$databefor, name = "spectra befor SNV", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("spectra_after_SNV.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$dataafter, name = "spectra after SNV", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("first_spectrum_befor_SNV.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$databefor[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum befor SNV", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg("first_spectrum_after_SNV.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$dataafter[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum after SNV", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    setwd("..")#go back to the main directory
  }
  cat(green("SNV.eval completed\n"))
}

variableselection.eval <- function(data, #passed data
                      whichfunc,
                  plotquality = 100, #percentage of quality
                  plotwidth = 1000, #width of plot in pixels
                  plotheight = 500, #width of plot in pixels
                  plotfontsize = 17, #size of the heads of the plot
                  plottype = "p", #type of the plot; p -> points; l -> lines
                  plotpch = 20, #type of datapoints
                  plotcex = 0.3, #size of the datapoints
                  ...){
  cat(silver("variableselection.eval started\n"))
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #select the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("databefor.csv"))
    write.csv(input.l$data$dataafter, paste("dataafter.csv"))
    write.csv(input.l$data$wavelengthsbefor, paste("wavelengthsbefor.csv"))
    write.csv(input.l$data$wavelengthsafter, paste("wavelengthsafter.csv"))
    m.left.variables <- cbind(input.l$data$wavelengthsbefor,input.l$data$left.variables)
    colnames(m.left.variables) <- c("wavelengths", "left.variables")
    write.csv(m.left.variables, paste("left.variables.csv"))
    write.csv(input.l$data$history, "history.csv")

    #create jpgs with all important plots
    jpeg(paste0("spectra_befor_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsbefor, Y = input.l$data$databefor, name = paste0("spectra befor ", whichfunc), type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("spectra_after_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsafter, Y = input.l$data$dataafter, name = paste0("spectra after ", whichfunc), type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_befor_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsbefor, y = input.l$data$databefor[1,], type = plottype, pch = plotpch, cex = plotcex, main = paste0("first spectrum befor ", whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_after_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsafter, y = input.l$data$dataafter[1,], type = plottype, pch = plotpch, cex = plotcex, main = paste0("first spectrum after ", whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    #generate a plot, where all leftvariables are marked in red
    col.p <- rep("black", length(input.l$data$left.variables))
    col.p[input.l$data$left.variables] <- "red"
    jpeg(paste0("spectra_leftvariables_marked", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsbefor, Y = input.l$data$databefor, name = paste0("spectra with red marked leftvariables ", whichfunc), type = "p", col.p = col.p, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export

    #save history to txt.file
    sink(file = "history.txt")
    print(input.l$data$history)
    sink()

    #calculate parameters
    add.infos <- input.l$data$add.infos #save additional infos to variables, to avoid writing so much
    all.var <- length(input.l$data$left.variables) #all variables befor CARS
    n.left.var <- sum(input.l$data$left.variables) #left variables after CARS
    n.del.var <- all.var - n.left.var #number of deleted variables
    part.left.var <- round((n.left.var/all.var)*100, digits = 3) #Percentage of the left variables in comparison to number of variables befor CARS
    dec.RMSEP <- round((1 - (add.infos$RMSEP.fin/add.infos$RMSEP.init))*100,digits = 3) #Percentage decrease of the RMSEP


    sink(file = "segments cross validation.txt")#start writing all outputs to the file infos.txt
    print(input.l$data$CV.infos$segments)
    sink() #stop writting outputs to a file
    #create summary file
    sink(file = "summary.txt")
    cat("SUMMARY VARIABLESELECTION\n\n")
    cat(paste0("Selectionalgorithm: ", whichfunc, "\n"))
    cat(paste0("Direction of selection: ", add.infos$direction, "\n"))
    if(add.infos$multithread){cat("Multithreading was used.\n")}
    cat(paste0("\nThe Breakup-criterion was: ", input.l$data$break.up,"\n"))
    if(input.l$data$break.up == "RMSEP.decrease.break"){
      cat("The algorythm was breaked up, when the RMSEP was worse than in the last round\n")
    }
    if(input.l$data$break.up == "specify.n.vari"){
      cat(paste0("A breakup after aspecified number of left variables was defined.\n"))
    }
    if(input.l$data$break.up == "best.overall"){
      cat(paste0("The Algorythm was repeated until all variables were changed. After this the best number of variables was choosen automatically.\n"))
    }
    if(input.l$data$break.up == "interactive"){
      cat(paste0("The Algorythm was repeated until all variables were changed. After this the user selected the number of variables, which should be changed.\n"))
    }
    if(!is.null(input.l$data$n.variables)){
      cat(paste0("The algorithm was (also) breaked up after this number of variables was reached: ", input.l$data$n.variables, "\n"))
    }
    if(whichfunc == "PCA.procrustes"){
      cat(paste0("\nThere were used ", input.l$data$add.data$ncomp.PCA.PA, " components of the PCA for the procrustes analysis.\n"))
    }
    cat("\nPLSR-function informations:\n")
    cat(paste0("Validationtyp:" ,add.infos$validation, "\n"))
    if(!is.null(input.l$data$CV.infos)){
      cat("Additional informations for the CV. For the exact segments look into segments.txt.\n")
      if(!is.null(input.l$data$CV.infos$segments.CV)){cat(paste0("The dataset was split into ", input.l$data$CV.infos$segments.CV, "parts (segments.CV).\n"))}
      if(!is.null(input.l$data$CV.infos$segments.type.CV)){cat(paste0("This method was used to select segments: ", input.l$data$CV.infos$segments.type.CV, " (segments.type.CV)\n" ))}
      if(!is.null(input.l$data$CV.infos$repetitions)){cat(paste0("In the dataset every datapoint was repeated ", input.l$data$CV.infos$repetitions, " times (repetitions).\nThis circumstance was mentioned in the creation of the segments.\n"))}
    }
    cat(paste0("PLSR-algorythm: ", add.infos$method, "\n"))
    cat(paste0("max. number of calculated components: ", add.infos$ncomp, "\n"))
    if(add.infos$centerX){cat("The X-data were centered.\n")}
    if(add.infos$standardizeX){cat("The X-data were standardized.\n")}
    cat("\nsummary result:\n")
    cat(paste0("Number of left variables: ", n.left.var, "\n"))
    cat(paste0("Number of deleted variables: ", n.del.var, "\n"))
    cat(paste0("Percentage of left variables: ", part.left.var, "%\n"))
    if(add.infos$n.Y ==1){#print this, if there is only Y-variable
      cat(paste0("Initial RMSEP: ", round(add.infos$RMSEP.init, digits = 6), "\n"))
      cat(paste0("Final RMSEP: ", round(add.infos$RMSEP.fin, digits = 6), "\n"))
      cat(paste0("Dercrease of RMSEP in percent: ", dec.RMSEP, "%\n"))
    }else{ #print this, if there are more than 1 Y-Variable
      cat("The CARS Wavelengthselection was performed with more than 1 Y-variable, so the sum of all RMSEPs was used for the optimization!")
      cat(paste0("SUM Initial RMSEP: ", round(add.infos$RMSEP.init, digits = 6), "\n"))
      cat(paste0("SUM Final RMSEP: ", round(add.infos$RMSEP.fin, digits = 6), "\n"))
      cat(paste0("Dercrease of SUM RMSEP in percent: ", dec.RMSEP, "%\n"))
    }
    sink()
    setwd("..")#go back to the main directory
  }
  cat(green("cut.left.variables.eval completed\n"))
}

cut.left.variables.eval <- function(data, #passed data
                                   plotquality = 100, #percentage of quality
                                   plotwidth = 1000, #width of plot in pixels
                                   plotheight = 500, #width of plot in pixels
                                   plotfontsize = 17, #size of the heads of the plot
                                   plottype = "p", #type of the plot; p -> points; l -> lines
                                   plotpch = 20, #type of datapoints
                                   plotcex = 0.3, #size of the datapoints
                                   ...){
  cat(silver("cut.left.variables.eval started\n"))
  whichfunc <- "cut.left.variables"
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #select the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("databefor.csv"))
    write.csv(input.l$data$dataafter, paste("dataafter.csv"))
    write.csv(input.l$data$wavelengthsbefor, paste("wavelengthsbefor.csv"))
    write.csv(input.l$data$wavelengthsafter, paste("wavelengthsafter.csv"))
    m.left.variables <- cbind(input.l$data$wavelengthsbefor,input.l$data$left.variables)
    colnames(m.left.variables) <- c("wavelengths", "left.variables")
    write.csv(m.left.variables, paste("left.variables.csv"))


    #create jpgs with all important plots
    jpeg(paste0("spectra_befor_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsbefor, Y = input.l$data$databefor, name = paste0("spectra befor ", whichfunc), type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("spectra_after_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsafter, Y = input.l$data$dataafter, name = paste0("spectra after ", whichfunc), type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_befor_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsbefor, y = input.l$data$databefor[1,], type = plottype, pch = plotpch, cex = plotcex, main = paste0("first spectrum befor ", whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_after_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsafter, y = input.l$data$dataafter[1,], type = plottype, pch = plotpch, cex = plotcex, main = paste0("first spectrum after ", whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export

    setwd("..")#go back to the main directory
  }
  cat(green("cut.left.variables.eval completed\n"))
}

load.variableselection.eval <- function(data, #passed data
                                    plotquality = 100, #percentage of quality
                                    plotwidth = 1000, #width of plot in pixels
                                    plotheight = 500, #width of plot in pixels
                                    plotfontsize = 17, #size of the heads of the plot
                                    plottype = "p", #type of the plot; p -> points; l -> lines
                                    plotpch = 20, #type of datapoints
                                    plotcex = 0.3, #size of the datapoints
                                    ...){
  cat(silver("load.variableselection.eval started\n"))
  whichfunc <- "load.variableselection"
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #select the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("databefor.csv"))
    write.csv(input.l$data$dataafter, paste("dataafter.csv"))
    write.csv(input.l$data$wavelengthsbefor, paste("wavelengthsbefor.csv"))
    write.csv(input.l$data$wavelengthsafter, paste("wavelengthsafter.csv"))

    m.left.variables <- cbind(input.l$data$wavelengthsbefor,input.l$data$left.variables)
    colnames(m.left.variables) <- c("wavelengths", "left.variables")
    write.csv(m.left.variables, paste("left.variables.csv"))

    sink("history.variableselection.txt")
    print(input.l$data$data.variableselection$history)
    sink()



    #create jpgs with all important plots
    jpeg(paste0("spectra_befor_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsbefor, Y = input.l$data$databefor, name = paste0("spectra befor ", whichfunc), type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("spectra_after_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsafter, Y = input.l$data$dataafter, name = paste0("spectra after ", whichfunc), type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_befor_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsbefor, y = input.l$data$databefor[1,], type = plottype, pch = plotpch, cex = plotcex, main = paste0("first spectrum befor ", whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg(paste0("first_spectrum_after_", whichfunc, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsafter, y = input.l$data$dataafter[1,], type = plottype, pch = plotpch, cex = plotcex, main = paste0("first spectrum after ", whichfunc), xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export

    sink("infofile.txt")
    cat("The information of the original variableselectionalgorithm look up in the evaluation, where you performed the selectionalgorithm\n")
    cat(input.l$data$whichorigmethod)
    cat("\n")
    sink()
    setwd("..")#go back to the main directory
  }
  cat(green("load.variableselection.eval completed\n"))
}

reduce_variables_spectra.eval <- function(data, #passed data
                             plotquality = 100, #percentage of quality
                             plotwidth = 1000, #width of plot in pixels
                             plotheight = 500, #width of plot in pixels
                             plotfontsize = 17, #size of the heads of the plot
                             plottype = "p", #type of the plot; p -> points; l -> lines
                             plotpch = 20, #size of the font
                             plotcex = 0.3, #size of the datapoints
                             ...){
  cat(silver("reduce_variables_spectra.eval started\n"))
  whichfunc <- "reduce_variables_spectra"  #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("databefor.csv"))
    write.csv(input.l$data$dataafter, paste("dataafter.csv"))
    write.csv(input.l$data$wavelengthsbefor, paste("wavelengthsbefor.csv"))
    write.csv(input.l$data$wavelengthsafter, paste("wavelengthsafter.csv"))
    m.left.variables <- cbind(input.l$data$wavelengthsbefor,input.l$data$left.variables)
    colnames(m.left.variables) <- c("wavelengths", "left.variables")
    write.csv(m.left.variables, paste("left.variables.csv"))

    #create jpgs with all important plot
    jpeg("spectra_befor_reduction_of_variables.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsbefor, Y = input.l$data$databefor, name = "spectra befor reduction of variables", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("spectra_after_reduction_of_variables.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengthsafter, Y = input.l$data$dataafter, name = "spectra after reduction of variables", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("first_spectrum_befor_reduction_of_variables.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsbefor, y = input.l$data$databefor[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum befor reduction of variables", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg("first_spectrum_after_reduction_of_variables.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengthsafter, y = input.l$data$dataafter[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum after reduction of variables", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export

    sink(file = "infos.txt")
    cat(paste0("The degreeofreduction was ", input.l$data$degreeofreduction, ".\n"))
    cat(paste0("So each new datapoint is the average of ", input.l$data$degreeofreduction, " old ones.\n"))
    sink()

    setwd("..") #go back to the main directory
  }
  cat(green("reduce_variables_spectra.eval completed\n"))
}

calc.meanspectra.eval <- function(data, #passed data
                                  plotquality = 100, #percentage of quality
                                  plotwidth = 1000, #width of plot in pixels
                                  plotheight = 500, #width of plot in pixels
                                  plotfontsize = 17, #size of the heads of the plot
                                  plottype = "p", #type of the plot; p -> points; l -> lines
                                  plotpch = 20, #size of the font
                                  plotcex = 0.3, #size of the datapoints
                                  ...){
  cat(silver("calc.meanspectra.eval started\n"))
  whichfunc <- "calc.meanspectra"  #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("Xdatabefor.csv"))
    write.csv(input.l$data$dataafter, paste("Xdataafter.csv"))
    write.csv(input.l$data$wavelengths, paste("wavelengths.csv"))
    write.csv(input.l$data$oriY.befor, paste("oriY.befor.csv"))
    write.csv(input.l$data$oriY.after, paste("oriY.after.csv"))
    write.csv(input.l$data$Ydata.befor, paste("Ydatabefor.csv"))
    write.csv(input.l$data$Ydata.after, paste("Ydataafter.csv"))

    #create jpgs with all important plot
    jpeg("spectra_befor_calc.meanspectra.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$databefor, name = "spectra befor averaging", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("spectra_after_calc.meanspectra.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$dataafter, name = "spectra after averaging", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("first_spectrum_befor_calc.meanspectra.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$databefor[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum befor averaging", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg("first_spectrum_after_calc.meanspectra.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$dataafter[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum after averaging", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export

    sink(file = "infos.txt")
    if(input.l$data$all.repetitions){
      cat(paste0("all.repetitions was TRUE. So all spectra, which were repeated were averaged. \n"))
    }
    cat(paste0(input.l$data$mean.n.spectra, " spectra were averaged. \n"))
    sink()

    setwd("..") #go back to the main directory
  }
  cat(green("calc.meanspectra.eval completed\n"))
}

IIR.correction.eval <- function(data, #passed data
                                  plotquality = 100, #percentage of quality
                                  plotwidth = 1000, #width of plot in pixels
                                  plotheight = 500, #width of plot in pixels
                                  plotfontsize = 17, #size of the heads of the plot
                                  plottype = "p", #type of the plot; p -> points; l -> lines
                                  plotpch = 20, #size of the font
                                  plotcex = 0.3, #size of the datapoints
                                  ...){
  cat(silver("IIR.correction.eval started\n"))
  whichfunc <- "IIR.correction"  #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("Xdatabefor.csv"))
    write.csv(input.l$data$dataafter, paste("Xdataafter.csv"))
    write.csv(input.l$data$corrections, "Xcorrections.csv")
    write.csv(input.l$data$wavelengths, paste("wavelengths.csv"))
    write.csv(input.l$data$P.simple, "Eigenvectors PCA X.simple.csv")
    write.csv(input.l$data$X.simple, "Xdata.simple.csv")
    write.csv(input.l$data$X.simple.mean, "mean.Xdata.simple.csv")
    write.csv(input.l$data$part.cum.var, "part.cum.var.compsPCA.csv")

    #create jpgs with all important plot
    jpeg("spectra_befor_IIF.correction.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$databefor, name = "spectra befor IIF correction", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("spectra_after_IIF.correction.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$dataafter, name = "spectra after IIF correction", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("first_spectrum_befor_IIF.correction.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$databefor[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum befor IIF correction", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export
    jpeg("first_spectrum_after_IIF.correction.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    plot(x = input.l$data$wavelengths, y = input.l$data$dataafter[1,], type = plottype, pch = plotpch, cex = plotcex, main = "first spectrum after IIF correction", xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY())
    dev.off()#end jpg export

    sink(file = "infos.txt")
    cat("The IIF correction was used to reduce the Variance in the spectra.\n")
    cat(paste0("To do this ", input.l$data$ncomp, " componentes were used.\n"))

    if(!is.null(input.l$data$comp.explained.variance)){
      cat(paste0("There were used as many components, that at the minimum ", (input.l$data$comp.explained.variance * 100), "% of the variance was explained"))
    }
    sink()

    setwd("..") #go back to the main directory
  }
  cat(green("IIR.correction.eval completed\n"))
}


Ydata_transformation.eval <- function(data, #passed data
                                      plotquality = 100, #percentage of quality
                                      plotwidth = 1000, #width of plot in pixels
                                      plotheight = 500, #width of plot in pixels
                                      plotfontsize = 17, #size of the heads of the plot
                                      plottype = "p", #type of the plot; p -> points; l -> lines
                                      plotpch = 20, #size of the font
                                      plotcex = 0.3, #size of the datapoints
                                      ...){
  cat(silver("Ydata_transformation.eval started\n"))
  whichfunc <- "Ydata_transformation"  #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("Ydatabefor.csv"))
    write.csv(input.l$data$dataafter, paste("Ydataafter.csv"))




    sink(file = "infos.txt")
    cat("The Ydata were transformed.\n")
    cat("This was done for this ")
    cat(paste(input.l$data$whichYvalues, sep = "; "))
    cat(" Yvalues.\n")

    if(input.l$data$centeredY){
      cat(paste0("The Ydata were centered after this because of centeredY"))
    }
    sink()

    sink(file = "transformationfunction.txt")
    print(input.l$data$transformationFUN)
    sink()

    sink(file = "backtransformationfunction.txt")
    print(input.l$data$backtransformationFUN)
    sink()

    setwd("..") #go back to the main directory
  }
  cat(green("Ydata_transformation.eval completed\n"))
}

reduce.calibrationrange.eval <- function(data, #passed data
                                         plotquality = 100, #percentage of quality
                                         plotwidth = 1000, #width of plot in pixels
                                         plotheight = 500, #width of plot in pixels
                                         plotfontsize = 17, #size of the heads of the plot
                                         plottype = "l", #type of the plot; p -> points; l -> lines
                                         plotpch = 20, #type of datapoints
                                         plotcex = 0.3, #size of the datapoints
                                         ...){
  cat(silver("reduce.calibrationrange.eval started\n"))
  whichfunc <- "reduce.calibrationrange" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory

    #write all data to the right csv files
    write.csv(input.l$data$databefor, paste("databefor.csv"))
    write.csv(input.l$data$dataafter, paste("dataafter.csv"))
    write.csv(input.l$data$wavelengths, paste("wavelengths.csv"))
    write.csv(input.l$data$oriYbefor, paste("dataYbefor.csv"))
    write.csv(input.l$data$oriYafter, paste("dataYafter.csv"))

    m.left.Yvalues <- cbind(input.l$data$oriYbefor,input.l$data$whichY)
    colnames(m.left.Yvalues) <- c("oriYvalue", "leftYvalue")
    write.csv(m.left.Yvalues, paste("left.Y.values.csv"))

    #create jpgs with all important plots
    jpeg("original_spectra.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$databefor, name = "original spectra", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export
    jpeg("selected_spectra.jpg", quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    printplot.allspectrums(X = input.l$data$wavelengths, Y = input.l$data$dataafter, name = "selected spectra", type = plottype, pch = plotpch, cex = plotcex, xlab = input.l$data.info$read.UnitspecX(), ylab = input.l$data.info$read.UnitspecY(), silent = TRUE)
    dev.off()#end jpg export

    sink(file = "infos.txt")
    cat(paste0("The new calibration range for the spectra is ", input.l$data$newcalrange[1], " to " , input.l$data$newcalrange[2]))
    cat("\nAll spectra with the Y.value in this range were choosen.\n\n")
    cat("This Y column were used to select the spectra: ", input.l$data$Ycol)
    sink()

    setwd("..")#go back to the main directory

  }
  cat(green("reduce.calibrationrange.eval completed\n"))
}
