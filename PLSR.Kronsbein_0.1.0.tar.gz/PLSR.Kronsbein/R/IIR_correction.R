#A function to perform the IIR correction (independent interference reduction).
#This function uses a simple dataset (very often measuered the same sample) to model the interfernences and then remove this variances
IIR.correction <- function(data = NULL, #PLSR.Kronsbein Dataset, normal dataset with different samples
                           data.simple = NULL, #simple PLSR.Kronsbein Dataset, measured the same sample really often, to model the interfernces
                           ncomp = NULL, #the number of components used of the PCA during the IIR
                           comp.explained.variance = NULL, #which part of the variance should be explained by the components (value has to be between 0 and 1)
                           printplots.TF = FALSE, #plotted spectrums desired?
                           savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                           ...){
  cat(silver("IIR.correction started\n"))
  check.data(data = data) #function to check, if there was passed a dataset
  check.data(data = data.simple) #function to check, if there was passed a dataset

  #prevent errors
  if(ncol(data$prepdata$X) != ncol(data.simple$prepdata$X)){stop("The datasets data and data.simple have to have the same number of variables")}

  if(printplots.TF){
    printplot.allspectrums(X = data$wavelengths, Y = data$prepdata$X, name = "original spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY()) #print all spectrums of the original dataset in one plot
  }
  #extract Xdata of simple dataset
  X.simple <- data.simple$prepdata$X

  #center simple Xdata
  X.simple.mean <- apply(X = X.simple, MARGIN = 2, FUN = mean)
  X.simple.centered <- X.simple - matrix(data = rep(X.simple.mean, nrow(X.simple)), ncol = length(X.simple.mean), byrow = TRUE)

  #calculate principal components of simple Xdata
  prcomp.X.simple <- prcomp(x = X.simple)

  #extract Xdata of the normal (special) dataset
  X.special <- data$prepdata$X
  #substract meanspectra of simple Xdata of the normal Xdata
  X.special.centered <- X.special - matrix(data = rep(X.simple.mean, nrow(X.special)), ncol = length(X.simple.mean), byrow = TRUE)

  #use the eigenvectors of the components
  P.simple <- prcomp.X.simple$rotation
  var <- prcomp.X.simple$sdev^2 #calculate explained variances for the components
  part.cum.var <- cumsum(var)/sum(var) #calculate the part of the variance, that explains a component and all lower components together

  #if comp.explained variance was used, choose the right number of components
  if(!is.null(comp.explained.variance)){
    if(!is.null(ncomp)){warning("ncomp will not be used, because comp.explained.variance was used")}
    if(comp.explained.variance > 0 && comp.explained.variance <= 1){
      ncomp <- min(which(part.cum.var >= comp.explained.variance))
    }else{
      stop("the value of comp.explained.variance is invalid. It has to be between 0 and 1")
    }
  }
  #if no components passed, use the maximal available number of components
  if(is.null(ncomp)){
    ncomp <- ncol(prcomp.X.simple$rotation)
  }

  #use the eigenvectors of the components
  P.simple <- P.simple[,1:ncomp]

  #calculate the correction Matrix
  X.corrections <- X.special.centered %*% P.simple %*% t(P.simple)
  #correct the spectra
  X.special.corrected <- X.special.centered - X.corrections

  #save the corrected spectra
  data$prepdata$X <- X.special.corrected

  if(printplots.TF){
    printplot.allspectrums(X = data$wavelengths, Y = data$prepdata$X, name = "IIF corrected spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY()) #print all spectrums of the original dataset in one plot
  }

  if(savedata.TF){
    savedata <- list(databefor = X.special, dataafter = X.special.corrected, corrections = X.corrections, wavelengths = data$wavelengths, P.simple = P.simple, X.simple = data.simple$prepdata$X, X.simple.mean = X.simple.mean, ncomp = ncomp, comp.explained.variance = comp.explained.variance, part.cum.var = part.cum.var)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object activ is necessary
    data$directorymethoddone$methoddone(whichmethod = "IIR.correction", data = savedata, data.info = data$data.info$clone(deep = TRUE))
  }

  cat(green("IIR.correction completed\n"))
  return(data)
}

#internal function to perform IIR during the prediction in the same way like in the calibration
IIR.correction.pred <- function(data, #PLSR.Kronsbein Dataset
                                P.simple, #eigenvector calculated in IIR
                                X.simple.mean, #mean spectra of the simple dataset of the IIR
                                ...){
  cat(silver("IIR.correction.pred started\n"))
  X.pred <- data$prepdata$X #extract Xdata, which should be used for the predictions
  #substract X.simple.mean of each of the spectra
  X.pred.centered <- X.pred - matrix(data = rep(X.simple.mean, nrow(X.pred)), ncol = length(X.simple.mean), byrow = TRUE)
  #calculate corrections matrix
  X.pred.corrections <- X.pred.centered %*% P.simple %*% t(P.simple)
  #substract corrections matrix to get the corrected Xdata
  X.pred.corrected <- X.pred.centered - X.pred.corrections

  #save the corrected Xdata
  data$prepdata$X <- X.pred.corrected

  cat(green("IIR.correction.pred completed\n"))
  return(data)
}


