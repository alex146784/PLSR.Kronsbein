

#function to perform all PCA calculations
PCA.calc <- function(data, #pass pataset of fread.prepdata()
                     center = FALSE, #center the Data
                     standardize = FALSE, #standardize Data
                     savedata.TF = TRUE,
                     ...){
  cat(silver("PCA.calc started\n"))

  check.data(data = data)

  data.PCA = list() #create empty list for the results
  if(ncol(data$prepdata$X)<= nrow(data$prepdata$X)){#the number of components, that will be calculated
    ncomp <- ncol(data$prepdata$X)
  }else{
    ncomp <- nrow(data$prepdata$X)
  }

  data.PCA$prcomp <- prcomp(data$prepdata$X, center = center, scale. = standardize) #calculate principle components with the standard R function prcomp()
  data.PCA$var <- data.PCA$prcomp$sdev^2 #calculate explained variances for the components
  data.PCA$part.var <- data.PCA$var/sum(data.PCA$var) #calculate the part of the variance, that explains one component
  data.PCA$part.cum.var <- cumsum(data.PCA$var)/sum(data.PCA$var) #calculate the part of the variance, that explains a component and all lower components together

  data.PCA$eigenvectors <- data.PCA$prcomp$rotation #eigenvectors of the components
  data.PCA$eigenvalues <- data.PCA$var #eigenvalues of the components
  data.PCA$scores <- predict(data.PCA$prcomp) #scores for components
  data.PCA$loadings <- matrix(data = NA, ncol = ncomp, nrow = ncol(data$prepdata$X)) #create empty matrix for the loadings of the components
  data.PCA$wavelengths <- data$wavelengths
  for(i in 1:ncomp){
    data.PCA$loadings[,i] <- data.PCA$eigenvectors[,i] * (data.PCA$eigenvalues[i])^0.5 #calculate loadings, for each component
  }
  dimnames(data.PCA$loadings) <- dimnames(data.PCA$eigenvectors) #correct dimnames of the loadings
  data$PCA <- data.PCA
  if(savedata.TF){
    savedata <- list(inputdata = data$prepdata, oriY = data$oriY, wavelengths = data$wavelengths, data.PCA = data.PCA, center = center, standardize = standardize)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object activ is necessary
    data$directorymethoddone$methoddone(whichmethod = "PCA.calc", data = savedata, data.info = data$data.info$clone(deep = TRUE))
  }
  cat(green("PCA.calc completed\n"))
  return(data)
}










