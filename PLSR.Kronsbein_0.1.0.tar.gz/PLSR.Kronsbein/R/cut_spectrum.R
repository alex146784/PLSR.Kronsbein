compare.cut <- function(values, cuts.l){ #function to translate the matrix with cuts in a logical vector, which values should be retained
  drop.wavelengths.l <- rep(FALSE, length(values)) #start with a logical vector drop, with all values false (drop no values)
  for (i in 1:nrow(cuts.l)){# go through all rows of cuts
    if(cuts.l[i,1] == 0){b1 <- which(values == min(values))}else{b1 <- which(values == cuts.l[i,1])} #if the first column is 0 set b1 to 1, because cut from the first value, else look up at which position the cut should performed and save to b1
    if(cuts.l[i,2] == 0){b2 <- which(values == max(values))}else{b2 <- which(values == cuts.l[i,2])} #if the second column is 0 set b1 to the last value of all values, because cut to the last value, else look up at which position the cut should performed and save to b2
    if(is.empty(b1)){if(cuts.l[i,1] == 0){b1 <- which(values == min(values))}else{b1 <- which(round(values) == round(cuts.l[i,1]))}} #try the same with rounded values, if it doesn´t work
    if(is.empty(b2)){if(cuts.l[i,2] == 0){b2 <- which(values == max(values))}else{b2 <- which(round(values) == round(cuts.l[i,2]))}} #try the same with rounded values, if it doesn´t work
    if(length(b1)>1){b1 <- min(b1)}
    if(length(b2)>1){b2 <- max(b2)}
    if(is.empty(b1)|is.empty(b2)){stop("the entry for the cut is not valid. Please check, if the values for the cuts are available in spectrum as numbers or as wavelengths, depending on th choosen input option.")}
    drop.wavelengths.l[b1:b2]<-TRUE #set all values between b1 and b2 to TRUE -> drop these values
  }
  keep.wavelengths.l <- !drop.wavelengths.l #change TRUE to FALSE and in the other way. to recieve logical vector keep wavelengths
  return(keep.wavelengths.l)
}


addcutstoallcuts <- function(allcuts, cuts.n = NULL, cuts.w = NULL){ #function save done cuts to allcuts
  if(is.null(allcuts)){ #nothing in allcuts
    if(!is.null(cuts.n)){ #if cuts were defined by numbers save vectyp n to row
      vectype <- rep("n",nrow(cuts.n))
      cuts.n <- cbind(cuts.n,vectype)
      allcuts <- cuts.n
    }
    if(!is.null(cuts.w)){ #if cuts were defined by wavelengths save vectyp w to row
      vectype <- rep("w",nrow(cuts.w))
      cuts.w <- cbind(cuts.w,vectype)
      allcuts <- cuts.w
    }
  }else{# allcuts already exist, so add new cuts to allcuts
    if(!is.null(cuts.n)){ #if cuts were defined by numbers save vectyp n to row
      vectype <- rep("n",nrow(cuts.n))
      cuts.n <- cbind(cuts.n,vectype)
      allcuts <- rbind(allcuts, cuts.n)
    }
    if(!is.null(cuts.w)){ #if cuts were defined by wavelengths save vectyp w to row
      vectype <- rep("w",nrow(cuts.w))
      cuts.w <- cbind(cuts.w,vectype)
      allcuts <- rbind(allcuts, cuts.w)
    }
  }
  return(allcuts)
}

cutspectrum <- function(data, #pass dataset of fread.dataprep.plsr()
                        printplots.TF = FALSE, #boolean to decide, whether the spectrum is going to be printed
                        cuts.n = NULL, #matrix with cuts as numbers
                        cuts.w = NULL, #matrix with cuts as wavelengths
                        interactive = FALSE, #enable interactive mode
                        plottype = "p", # plot datapoints in plots as points
                        plotpch = 20, #size of the font
                        plotcex = 0.3, #size of the datapoints
                        savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                        ...){
  cat(silver("cutspectrum started\n"))
  check.data(data = data)#function to check, if there was passed a dataset

  if(savedata.TF && ((data$directorymethoddone$is.methoddone("CARS")) || (data$directorymethoddone$is.methoddone("Procrustes")) || (data$directorymethoddone$is.methoddone("PCA.procrustes")))){ #prevent not senseful cut of the spectra after a variableselektion
    warning("it is not useful to cut the spectrum after the variableselection algorithm, it easier to first cut the spectrum!")
  }
  allcuts <- NULL #allcuts is at the beginning empty
  wavelengths <- data$wavelengths
  input <- data$prepdata$X #test,how data was passed and print errors
  if(printplots.TF){printplot.allspectrums(X=wavelengths, Y = input, name = "befor cuts", type = plottype, pch = plotpch, cex = plotcex, xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY())} #print all plots if activated
  old.start.input <- input #save original input
  old.start.wavelengths <- wavelengths #save original wavelengths
  keep.wavelengths <- rep(TRUE, length(wavelengths)) #keep all wavelengths at the beginning
  numbers <- 1:length(wavelengths) #numbers is a vector of all data points of one spectrum numbered serially


  repeat{ #repetition for interactive use
    last.keep.wavelengths <- keep.wavelengths #save last keep.wavelengths to undo last changes
    if(!is.null(cuts.n)){ #if cuts were passed via numbers
      if(!is.matrix(cuts.n)){stop("cuts.n is not matrix")} #test if cuts is saved as a matrix
      if(!is.null(cuts.w)){warning("both was passed cuts.n and cuts.w, only cuts.n will be used")} #warning if both methods were used to pass cuts, that only numbers will be used
      keep.wavelengths.interim <- last.keep.wavelengths * compare.cut(values = numbers, cuts.l = cuts.n) #multiply the kept wavelengths with the keep wavelengths output of compare cuts. if in one multiplicant the value is false, the result is FALSE
      keep.wavelengths <- as.logical(keep.wavelengths.interim) #because after the multiplication the values are saved as numeric, transfer to logical
      allcuts <- addcutstoallcuts(allcuts = allcuts, cuts.n = cuts.n) #save performed cuts to all cuts
      numoflastchanges <- nrow(cuts.n) #save how many cuts were performed at the last loop
    }else{
      if(!is.null(cuts.w)){#if cuts were passed via wavelengths
        if(!is.matrix(cuts.w)){stop("cuts.w is not matrix")} #test if cuts is saved as a matrix
        keep.wavelengths.interim <- last.keep.wavelengths * compare.cut(values = wavelengths, cuts.l = cuts.w)  #multiply the kept wavelengths with the keep wavelengths output of compare cuts. if in one multiplicant the value is false, the result is FALSE
        keep.wavelengths <- as.logical(keep.wavelengths.interim) #because after the multiplication the values are saved as numeric, transfer to logical
        allcuts <- addcutstoallcuts(allcuts = allcuts, cuts.w = cuts.w) #save performed cuts to all cuts
        numoflastchanges <- nrow(cuts.w) #save how many cuts were performed at the last loop
      }else{# if no cuts passed stop, if no interactive mode active
        if(!interactive){stop("no cuts passed and interactive mode is off")}
      }
    }
    #start interactive mode, if interactive = TRUE
    if(interactive){ #after last cuts were performed and interactive mode is active ...
      cuts.n <- NULL #set cuts to NULL, delete the last ones
      cuts.w <- NULL
      repeat{ #loop for menu
        #Output to inform user
        cat(yellow("\n\nInteractive mode has been choosen.\nBe careful that your cursor is active in the console, not in the script!!!\n"))
        cat(blue("Now you have the possibility to cut off parts of the spectrum.\n"))
        cat(blue("Press a number to choose an option and confirm with enter:\n"))
        cat(blue("\t0:\tNo more cuts necessary.\n"))
        cat(blue("\t1:\tReview last results\n"))
        cat(blue("\t2:\tAdd some cuts\n"))
        cat(blue("\t3:\tUndo last changes (only one step backwards possible)\n"))
        cat(blue("\t4:\tUndo all changes\n"))
        menu <- readline(prompt = "Selection: ") #recieve decision of the user

        # go on depending on the decision of the user
        switch(menu,
               # close interactive mode -> set interactive to FALSE
               "0" = {interactive = FALSE
               cat(yellow("\nInteractive mode closed.\n"))},

               # review the last results
               "1" = {#Output to inform user
                 cat(yellow("\nRewiew last results choosen.\n"))
                 cat(blue("What do you want to review?\n"))
                 cat(blue("\t1:\tSpectrums after cuts with lines\n"))
                 cat(blue("\t2:\tSpectrums after cuts with points\n"))
                 cat(blue("\t3:\tSpectrums befor last changes with lines\n"))
                 cat(blue("\t4:\tSpectrums befor last changes with points\n"))
                 cat(blue("\t5:\tSpectrums without changes with lines\n"))
                 cat(blue("\t6:\tSpectrums without changes with points\n"))
                 menu1 <- readline((prompt = "Selection: "))#recieve decision of the user

                 # go on depending on the decision of the user
                 switch(menu1, # print spectrums in the way described in the output above
                        "1" = printplot.allspectrums(X=wavelengths[keep.wavelengths], Y = input[,keep.wavelengths], name = "after latest cuts", type = "l", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY()),
                        "2" = printplot.allspectrums(X=wavelengths[keep.wavelengths], Y = input[,keep.wavelengths], name = "after latest cuts", type = "p", pch = plotpch, cex = plotcex, xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY()),
                        "3" = printplot.allspectrums(X=wavelengths[last.keep.wavelengths], Y = input[,last.keep.wavelengths], name = "befor latest cuts", type = "l", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY()),
                        "4" = printplot.allspectrums(X=wavelengths[last.keep.wavelengths], Y = input[,last.keep.wavelengths], name = "befor latest cuts", type = "p", pch = plotpch, cex = plotcex, xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY()),
                        "5" = printplot.allspectrums(X=wavelengths, Y = input, name = "without cuts", type = "l", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY()),
                        "6" = printplot.allspectrums(X=wavelengths, Y = input, name = "without cuts", type = "p", pch = plotpch, cex = plotcex, xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY()),
                        cat(red("No valid selection! Please try again\n"))
                 )
               },

               #add new cuts
               "2" = {#Output to inform user
                 cat(yellow("\nChange variables choosen.\n"))
                   cat(blue("How do you want to add some cuts\n"))
                   cat(blue("You can choose between the number of values and wavelengths to define the cut.\n"))
                   cat(blue("If you choose wavelengths, it is important to choose only exact the wavelengths, were data are available\n"))
                   cat(blue("You can type in 0 instead of the values, if you want to choose the first or the last values\n"))
                   cat(blue("\t0:\tNo cuts.\n"))
                   cat(blue("\t1:\tSet cut with numbers (buggy, if wavelengths is not sorted from small to big values)\n"))
                   cat(blue("\t2:\tSet cut with wavelengths (recommended)\n"))

                   menu2 <- readline((prompt = "Selection: "))#recieve decision of the user
                   # go on depending on the decision of the user
                   switch(menu2, #change values in the way described in the output above
                          "0" = {cat(yellow("\nMenu change-variables closed\nModel will be recalculated with new parameters.\n"))},
                          "1" = {cat(yellow("\nSet cut with numbers choosen\n"))

                            repeat{ #loop, if user want to add more than one cut
                              repeat{#loop to make sure that user input ist right
                                read.input <-readline((prompt = "The lower number for the cut (type -1 to show all numbers): ")) #read input
                                lcut <- suppressWarnings(try(as.numeric(read.input),silent = TRUE)) #save lcut as numeric, if input was no number NA will be saved
                                if((lcut == 0) | ((!(is.na(lcut))) & (lcut>=0) & (lcut<=length(numbers)))){break #test if the entry is valid
                                }else{
                                  if(lcut == -1){print(numbers)}else{cat(red("no valid entry\n"))}
                                }
                              }
                              repeat{#loop to make sure that user input ist right
                                read.input <-readline((prompt = "The higher number for the cut (type -1 to show all numbers): ")) #read input
                                hcut <- suppressWarnings(try(as.numeric(read.input),silent = TRUE)) #save lcut as numeric, if input was no number NA will be saved
                                if((hcut == 0) | ((!(is.na(hcut))) & (hcut>=0) & (hcut<=length(numbers)))){break #test if the entry is valid
                                }else{
                                  if(hcut == -1){print(numbers)}else{cat(red("no valid entry\n"))}
                                }
                              }
                              if(is.null(cuts.n)){
                                cuts.n <- matrix(c(lcut,hcut),ncol = 2, byrow = TRUE) #if no cuts exists, create a new matrix with the cuts defined befor
                              }else{
                                cuts.n <- rbind(cuts.n,matrix(c(lcut,hcut),ncol = 2, byrow = TRUE)) #if cuts ecists, add new row with the cuts defined above
                              }
                              cat(blue("Do you want to add a cut?\n"))
                              repeat{#loop to make sure that user input ist right
                                read.input <- readline((prompt = "Type 1 for YES and 0 for NO: ")) #read input
                                if(read.input == 1 | read.input == 0){break}else{cat(red("no valid entry\n"))} #test if the entry is valid
                              }
                              if(read.input == 0){break} #break if no more cuts should be added
                            }
                          },
                          "2" = {cat(yellow("\nSet cut with wavelengths choosen\n"))
                            repeat{ #loop, if user want to add more than one cut
                              repeat{ #loop to make sure that user input ist right
                                read.input <-readline((prompt = "The lower wavelength for the cut (type -1 to show all wavelengths): ")) #read input
                                lcut <- suppressWarnings(try(as.numeric(read.input),silent = TRUE)) #save lcut as numeric, if input was no number NA will be saved
                                if((lcut == 0) | ((!(is.na(lcut))) & (lcut>=min(wavelengths)) & (lcut<=max(wavelengths)))){break #test if the entry is valid
                                }else{
                                  if(lcut == -1){print(wavelengths)}else{cat(red("no valid entry\n"))}
                                }
                              }
                              repeat{
                                read.input <-readline((prompt = "The higher wavelength for the cut (type -1 to show all numbers): ")) #read input
                                hcut <- suppressWarnings(try(as.numeric(read.input),silent = TRUE)) #save lcut as numeric, if input was no number NA will be saved
                                if((hcut == 0) | ((!(is.na(hcut))) & (hcut>=min(wavelengths)) & (hcut<=max(wavelengths)))){break #test if the entry is valid
                                }else{
                                  if(hcut == -1){print(wavelengths)}else{cat(red("no valid entry\n"))}
                                }
                              }
                              if(is.null(cuts.w)){
                                cuts.w <- matrix(c(lcut,hcut),ncol = 2, byrow = TRUE) #if no cuts exists, create a new matrix with the cuts defined befor
                              }else{
                                cuts.w <- rbind(cuts.w,matrix(c(lcut,hcut),ncol = 2, byrow = TRUE)) #if cuts ecists, add new row with the cuts defined above
                              }
                              cat(blue("Do you want to add a cut?\n"))
                              repeat{
                                read.input <- readline((prompt = "Type 1 for YES and 0 for NO: ")) #read input
                                if(read.input == 1 | read.input == 0){break}else{cat(red("no valid entry\n"))} #test if the entry is valid
                              }
                              if(read.input == 0){break} #break if no more cuts should be added
                            }
                          },

                          cat(red("No valid selection! Please try again\n")) #case no valid entry
                   )
               },
               "3" = {cat(yellow("\nLast changes were undone.\n")) #undo last changes
                 keep.wavelengths <- last.keep.wavelengths
                 if(numoflastchanges > 0){ #test if there last changes exists
                   for(i in 1:numoflastchanges){ # for these purpose delete the last changed cuts in allcuts
                     delete.row <- nrow(allcuts) #delete row is the number of existing rows
                     allcuts <- allcuts[-delete.row,] #allcuts is allcuts without this row
                   }
                 }else{#else print a message
                   cat(red("no last changes\n"))
                 }
                 },
               "4" = {cat(yellow("\nAll changes were undone.\n")) #undo all changes
                 keep.wavelengths <- rep(TRUE, length(wavelengths)) #keep all cuts is completly TRUE
                 allcuts <- NULL #so allcuts is NULL, because no cuts will performed
                 },
               cat(red("No valid selection! Please try again\n")) #case no valid entry
        )
        if(menu == "0"|menu == "2"){break} #go on in case 0 and 2, not in 1 because maybe the user will see another plot or he will change values
      }
    }

    #condition to stop loop: interactive = FALSE
    #interactive is FALSE, if it was passed FALSE as a parameter of the function or the user stopped the interactive function, if baseline correction is good
    if(!interactive){break} #break condition of do-while loop
  } #end loop




  output <- input[,keep.wavelengths] #the output is only the part of the spectrum, defined in keep.wavelengths
  wavelengths <- wavelengths[keep.wavelengths] #the same applies to wavelengths



  if(printplots.TF){printplot.allspectrums(X=wavelengths, Y = output, name = "after cuts", type = plottype, pch = plotpch, cex = plotcex, xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY())}# if desired print plots of all spectra

  if(savedata.TF){ #always savedata should be performed, except the function is called in the predict function
    savedata <- list(databefor = old.start.input, dataafter = output, wavelengthsbefor = old.start.wavelengths, wavelengthsafter = wavelengths, allcuts = allcuts) #list of all information
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data$directorymethoddone$methoddone(whichmethod = "cutspectrum", data = savedata, data.info = data$data.info$clone(deep = TRUE)) #save the data to a new methoddone object in directorymethoddone
  }
  data$prepdata$X <- output #output is new X-value of dataprep
  data$wavelengths <- wavelengths #wavelengths als was changed
  cat(green("cutspectrum completed\n"))
  return(data)
}

#function to cut down variables (left variables calculated with variableselection (in future: also cut.speactrum (no time)))
cut.left.variables <- function(data, left.variables, savedata.TF = TRUE){
  check.data(data = data) #function to check, if there was passed a dataset

  data.input <- data
  data$prepdata$X <- data$prepdata$X[,left.variables] #shorten variables
  data$wavelengths <- data$wavelengths[left.variables] #shorten wavelenths

  if(savedata.TF){
    savedata <- list(databefor = data.input$prepdata$X, dataafter = data$prepdata$X, wavelengthsbefor = data.input$wavelengths , wavelengthsafter = data$wavelengths , left.variables = left.variables) #list of all information
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data$directorymethoddone$methoddone(whichmethod = "cut.left.variables", data = savedata, data.info = data$data.info$clone(deep = TRUE)) #save the data to a new methoddone object in directorymethoddone
  }

  return(data)
}
