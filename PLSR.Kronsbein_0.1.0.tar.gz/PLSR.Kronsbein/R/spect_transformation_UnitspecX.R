
#internal function for apply
wn_to_wl <- function(wn){
  wl <- (1/wn)*(10^7)
  return(wl)
}

#internal function for apply
wl_to_wn <- function(wl){
  wn <- (1/wl)*(10^7)
  return(wn)
}

#internal function, to perform the change of UnitspecX
general_change_UnitspecX <- function(data, wn_to_wl = FALSE, wl_to_wn = FALSE, savedata.TF = TRUE, printplots.TF = FALSE){
  cat(silver("general_change_UnitspecX started\n"))
  
  check.data(data = data) #function to check, if there was passed a dataset
  
  input <- as.matrix(data$wavelengths) #transfer to a matrix for the apply function
  
  #print error
  if((wn_to_wl&wl_to_wn)|(!wn_to_wl&!wl_to_wn)){stop("One of wn_to_wl or wl_to_wn have to be TRUE, not both or none!")}#prevent error, that both directions are choosen
  
  #do this for wavenumber to wavelength
  if(wn_to_wl){
    if(savedata.TF){
      if(data$data.info$check.UnitspecX("Wavenumber [cm^-1]")){ #check if the dataset has the right unit, else the function doesn't work
        data$data.info <- data$data.info$clone(deep = TRUE)
        data$data.info$change.UnitspecX("Wavelength [nm]") #change unit
      }else{
        stop(paste0("To perform Wavenumber_to_Wavelength() UnitspecX has to be \"Wavenumber [cm^-1]\".\nCurrent UnitspecX is ",data$data.info$read.UnitspecX() ,". Set this parameter in fread.dataprep()."))
      }
    }
    output <- apply(X = input, MARGIN = 1:2, FUN = wn_to_wl ) #call apply function with T_to_E to make this transformation with every single value (MARGIN = 1:2)
    
  }
  
  #do this for wavelength to wavenumber
  if(wl_to_wn){
    if(savedata.TF){
      if(data$data.info$check.UnitspecX("Wavelength [nm]")){ #check if the dataset has the right unit, else the function doesn't work
        data$data.info <- data$data.info$clone(deep = TRUE)
        data$data.info$change.UnitspecX("Wavenumber [cm^-1]") #change unit
      }else{
        stop(paste0("To perform Wavelength_to_Wavenumber() UnitspecX has to be \"Wavelength [nm]\".\nCurrent UnitspecX is ",data$data.info$read.UnitspecX() ,". Set this parameter in fread.dataprep()."))
      }
    }
    output <- apply(X = input, MARGIN = 1:2, FUN = wl_to_wn ) #call apply function with E_to_T to make this transformation with every single value (MARGIN = 1:2)
  }
  output <- as.vector(output) #transfer back to a vector
  if(is.null(data)){ #if input was wavelengths return the tranferred wavelengths
    cat(green("general_change_UnitspecX completed\n"))
    return(output)
  }
  
  #if input was data, then return complette dataset with original values and transferred values
  #$prepdata is going be changed
  if(printplots.TF){#if the plots should be printed, do this depending on the function 
    if(wn_to_wl){
      printplot.allspectrums(X = input, Y = data$prepdata$X, name = "Spectra Wavenumber", xlab = "Wavenumber [cm^-1]", ylab = data$data.info$read.UnitspecY(), type = "l")
      printplot.allspectrums(X = output, Y = data$prepdata$X, name = "Spectra Wavelength", xlab = "Wavelength [nm]", ylab = data$data.info$read.UnitspecY(), type = "l")
    }
    if(wl_to_wn){
      printplot.allspectrums(X = input, Y = data$prepdata$X, name = "Spectra Wavelength", xlab = "Wavelength [nm]", ylab = data$data.info$read.UnitspecY(), type = "l")
      printplot.allspectrums(X = output, Y = data$prepdata$X, name = "Spectra Wavenumber", xlab = "Wavenumber [cm^-1]", ylab = data$data.info$read.UnitspecY(), type = "l")
    }
  }
  if(savedata.TF){
    savedata <- list(data = data$prepdata$X, wavelengthsbefor = input, wavelengthsafter = output)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object activ is necessary
  }
  if(wn_to_wl){ #save data to the rigth directorymethoddone
    if(savedata.TF){data$directorymethoddone$methoddone(whichmethod = "Wavenumber_to_Wavelength", data = savedata, data.info = data$data.info$clone(deep = TRUE))}
    data$wavelengths <- output
  }
  if(wl_to_wn){ #save data to the rigth directorymethoddone
    if(savedata.TF){data$directorymethoddone$methoddone(whichmethod = "Wavelength_to_Wavenumber", data = savedata, data.info = data$data.info$clone(deep = TRUE))}
    data$wavelengths <- output
  }
  cat(green("general_change_UnitspecY completed\n"))
  return(data)
}

#function to call tranfer from Wavenumber_to_Wavelength
#function is going to call general_change_UnitspecX
Wavenumber_to_Wavelength <- function(data, savedata.TF = TRUE, printplots.TF = FALSE){
  cat(silver("Wavenumber_to_Wavelength started\n"))
  result <- (general_change_UnitspecX(data = data, wn_to_wl = TRUE, savedata.TF = savedata.TF, printplots.TF = printplots.TF))
  cat(green("Wavenumber_to_Wavelength completed\n"))
  return(result)
}

#function to call tranfer from Wavelength_to_Wavenumber
#function is going to call general_change_UnitspecX
Wavelength_to_Wavenumber <- function(data, savedata.TF = TRUE, printplots.TF = FALSE){
  cat(silver("Wavelength_to_Wavenumber started\n"))
  result <- (general_change_UnitspecX(data = data, wl_to_wn = TRUE, savedata.TF = savedata.TF, printplots.TF = printplots.TF))
  cat(green("Wavelength_to_Wavenumber completed\n"))
  return(result)
}