

#function to select variables to optimize the RMSEP
variableselection <- function(data, #prepared dataset for plsr
                              selectionalgorithm = "CARS",
                              #"CARS" -> select variables through the lowest RMSEP (CARS)
                              #"Procrustes" -> select variables through procrustes analysis
                              #"PCA.procrustes" <- select variables through PCA and procrustes analysis
                              direction = "backwards", #forwards or backwards variable selection
                              #"forwards" -> start with no variables and then add gradually variables
                              #"backwards" -> start with all variables and then delete gradually variables
                              validation = "LOO", #validation type
                              #"LOO" (leave one out) -> recommended method, reproducible, but really slow, especially for big datasets
                              #"CV" (cross validation) -> quicker than LOO, but not reproducible (leave out 10 variables at a time, randomly selected)
                              #"ex" (external validation) -> quickest, not reproducible (because everytime other test and train dataselection); danger of overfit for testdata, if there are to less testdata
                              PLS.method = "simpls", #pls algorithm: simpls, kernelpls, widekernelpls, oscorespls
                              break.up = "interactive",  #define breakupcriterion
                              # "specify.n.vari" -> this number of variables will be left
                              # "RMSEP.decrease.break" -> if the RMSEP decreases after one round break"
                              # "best.overall" -> delete or add all variables and look afterwards, when the RMSEP was the smallest
                              # "interactive" -> same like best.overall, except you can choose the number of variables yourself at the end
                              multithread = TRUE, #use all cores of the computer, to perform the calculations (recommended)
                              n.variables = NULL,
                              ncomp.PCA.PA = 1, #number of components, which will be used in  PCA.procrustes
                              centerX = FALSE, #center data for pls, PCA
                              standardizeX = FALSE, #scale data for pls, PCA
                              ncomp = NULL, #maximum calculated components, to speed up function, if it is clear, that not more are necessary
                              trainvalues.ratio = 0.75, #if external validation will be used, this variable defines the part of the data, that will be used to train the model
                              segments.CV = NULL, #define in how many segments the dataset should be splitted for CV, to pass a list is also possible (never tried), generate with cvsegments()
                              segments.type.CV = NULL, #defines the type, how to select the segments: "random", "consecutive", "interleaved"
                              repetitions = data$data.info$read.repetitions(), #the number of repetitions at one Datapoint
                              savedata.TF = TRUE, #savedata to directoryPLS.methoddone
                              printplots.TF = FALSE, #if TRUE print the spectrums
                              centeredY = data$data.info$read.centeredY(), #were the Y-variables centered, normally TRUE
                              ...){

  cat(silver("variableselection started\n"))

  check.data(data = data)

  data.input <- data #save input data as data.input

  #prevent error no valid break.up
  if(break.up != "RMSEP.decrease.break" && break.up != "specify.n.vari" && break.up != "best.overall" && break.up != "interactive"){
    stop("no valid break.up choosen. Use \"RMSEP.decrease.break\", \"specify.n.vari\", \"best.overall\" or \"interactive\" ")
  }

  #prevent error no valid selectionalgorithm
  if(selectionalgorithm != "CARS" && selectionalgorithm != "Procrustes" && selectionalgorithm != "PCA.procrustes"){
    stop("no valid selectionalgorithm choosen. Use \"CARS\", \"Procrustes\" or \"PCA.procrustes\" ")
  }
  if(break.up == "specify.n.vari"){ #prevent errors with "specify.n.vari
    if(is.null(n.variables)){stop("set n.variables")}
    if(!is.numeric(n.variables) | (n.variables < 1) | (n.variables > ncol(data$prepdata$X))){stop("n.variables has to be numeric and in the range of possible variables")}
  }

  if(PLS.method == "nipals"){PLS.method  = "oscorespls"} #change name, because it´s the same

  if(!is.null(repetitions)){ #send warning, if the wants to use LOO and the user specified that there are repetitions in the dataset
    if (validation == "LOO" & (repetitions > 1)){warning("Leave one out validation is insufficient with repetitions in the dataset. Please use Cross Validation")}
  }

  if(selectionalgorithm == "Procrustes" || selectionalgorithm == "PCA.procrustes"){ #for this two variableselectionalgorhithms it is useful to center the Xdata first
    if(savedata.TF && (!centerX && (!(data$directorymethoddone$is.methoddone("centerX"))))){ #give back a warning, if center function was not performed befor standardizing
      warning("It is useful to center the X-data first for procrustes Analysis")
    }
  }


  if(centerX){ #center X for this function
    data <- centerX(data = data)
  }

  if(standardizeX){ #standardize X for this function
    data <- standardizeX(data = data)
  }

  #if validation method is Cross validation create the segments, like specified in generate.segments function
  if(validation == "CV"){segments <- generate.segments(data = data, segments.CV = segments.CV, segments.type.CV = segments.type.CV, repetitions = repetitions)}


  n.Y <- ncol(data.input$prepdata$Y) #save the number of Y-variables
  if(direction == "backwards"){direc = FALSE}else{ #if direction is backwards, direc is FALSE (only make this comparison once)
    if(direction == "forwards"){direc = TRUE} #if direction is forwards, direc is TRUE
    else{stop("Invalid variable for direction (\"backwards\" and \"forwards\" is possible")} #error no valid direction
  }


  if(validation == "ex"){ #if external validation, split data with the following functions
    split <- generate.split.CARS(data = data, trainvalues.ratio = trainvalues.ratio, whichY = 1)
    data <- splitdata.externalvalidation.CARS(data = data, split = split)
  }


  if(printplots.TF){ #print the original spectra
    printplot.allspectrums(X = data.input$wavelengths, Y = data.input$prepdata$X, name = paste0("original spectrums befor ", selectionalgorithm), xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), type = "p") #print all spectrums of the original dataset in one plot

  }

  if(direc){ #depending on the direction, create left variables only with TRUEs (backwards) or FALSEs (forwards)
    left.variables <- rep(FALSE,ncol(data$prepdata$X))
  }else{
    left.variables <- rep(TRUE,ncol(data$prepdata$X))
  }




  #calculate the start RMSEP, for comparison with the result
  RMSEP <- plsr.RMSEP.variableselection(data = data, ncomp = ncomp, validation = validation, PLS.method = PLS.method, centeredY = centeredY, segments = segments, left.variables = NULL)

  if(n.Y == 1){ #if there is one Y.variable do this
    RMSEP.init <- min(RMSEP) #mininal RMSEP of all components
    #comp.init <- which.min(RMSEP)
  }else{ #if there is more than one Y.variable do this
    RMSEP.init <- min(apply(RMSEP, MARGIN = 2, sum)) #the same as with one Y.variable, except to sum up all RMSEP of one component, to observe all Y-variables
    #comp.init <- which.min(apply(RMSEP, MARGIN = 2, sum))
  }

  X.apply <- matrix(data = (1:ncol(data$prepdata$X)), ncol = 1) #create dataset for apply, which variable should be changed




  if(selectionalgorithm == "CARS"){ #create history in this way, if algorithm is CARS
    history <- matrix(NA, nrow = ncol(data$prepdata$X), ncol = 4) #create matrix for history data$prepdata
    if(n.Y ==1){ #if there is one Y.variable do this
      colnames(history) <- c("RMSEP", "RMSEP.reference", "changed_variable", "number_of_comp") #define colnames for history
    }else{ #if there is more than one Y.variable do this
      colnames(history) <- c("SUM_RMSEP", "SUM_RMSEP.reference", "changed_variable", "number_of_comp") #define colnames for history
    }
  }else{ #create history in this way, if algorithm is not CARS
    history <- matrix(NA, nrow = ncol(data$prepdata$X), ncol = 6) #create matrix for history data$prepdata
    if(n.Y ==1){ #if there is one Y.variable do this
      colnames(history) <- c("RMSEP", "RMSEP.reference", "changed_variable", "number_of_comp", "procrustes distance", "goodness of fit") #define colnames for history
    }else{ #if there is more than one Y.variable do this
      colnames(history) <- c("SUM_RMSEP", "SUM_RMSEP.reference", "changed_variable", "number_of_comp", "procrustes distance", "goodness of fit") #define colnames for history
    }
  }
  rownames(history) <- paste(rep("round", ncol(data$prepdata$X)),1:ncol(data$prepdata$X)) #define rownames for history


  counter.rep <- 1 #create counter variable for the rounds (every round there will be changed on variable)


  repeat{ #loop for the rounds (every round there will be changed on variable)
    #####define reference RMSEP
    if(counter.rep == 1){
      if(direc){#case first round and direction is forward, reference RMSEP is infinity, because no variable selected (workaround, but works fine), better use mean as model
        RMSEP.ref <- Inf
      }else{#case first round and direction is backwards, use the RMSEP of the model with all variables (the initial model)
        RMSEP.ref <- RMSEP.init
      }
    }else{#every other round use the last RMSEP
      RMSEP.ref <- RMSEP.c
    }

    if(selectionalgorithm == "CARS"){ #calculate leftvaribles in this way, if algorithm is CARS
      if(multithread){#multithreadsolution to test all possibilties in adding or deleting variables
        cores <- detectCores(logical = TRUE) #find out the number of threads the computer can handle
        cl <- makeCluster(cores) #create new instances of R, each instance of R uses one thread
        if(validation == "ex"){#export all important variables and functions to the new instances of R, depending on the validationmethod
          #enviroment() gives back the local enviroment
          clusterExport(cl= cl,envir = environment(), varlist = c('PLSR.int','plsr', 'externalvalidation.CARS', 'checkandpeform.changes.Y', 'centerY_scaleY_standardizeY', 'centerY', 'standardizeY', 'scaleY', 'test.dataorMatrixdata','apply.t','substract.spectrum', 'divide.spectrum', 'silver', 'green', 'yellow', 'data',  'direc', 'left.variables', 'validation', 'PLS.method', 'ncomp', 'centeredY', 'n.Y', 'segments',  'add.spectrum', 'rmserr'))
        }else{
          clusterExport(cl= cl,envir = environment(), varlist = c('PLSR.int','plsr', 'externalvalidation.CARS', 'checkandpeform.changes.Y', 'yellow', 'data',  'direc', 'left.variables', 'validation', 'PLS.method', 'ncomp', 'centeredY', 'n.Y', 'segments'))
        }
        #parApply, does the same as apply. It splits the work to the different instances of R, definded in cl.
        RMSEP_comp.all <- parApply(cl = cl,X = X.apply, MARGIN = 1, FUN = PLSR.int, data = data,  direc = direc, left.variables.l = left.variables, validation = validation, PLS.method = PLS.method,  ncomp = ncomp, centeredY = centeredY, n.Y = n.Y,segments =  segments)
        stopCluster(cl) #close the additional no more necessary instances of R
      }else{#singlethreadsolution to test all possibilties in adding or deleting variables
        #call PLSR.int for every variable with simple apply function
        RMSEP_comp.all <- apply(X = X.apply, MARGIN = 1, FUN = PLSR.int, data = data, direc = direc, left.variables.l = left.variables, validation = validation, PLS.method = PLS.method, ncomp = ncomp, centeredY = centeredY, n.Y = n.Y, segments =  segments)
      }



      #apply function gaves back only one matric, which includes the RMSEPs and the best number of components, split this matrix to the depending vectors
      RMSEP.all <- RMSEP_comp.all[1,]
      comp.all <- RMSEP_comp.all[2,]

      #pick out the lowest RMSEP, this variable will be changed eventually
      RMSEP.c <- min(RMSEP.all, na.rm = TRUE)
      change.variable <- which.min(RMSEP.all) #the variable with the lowest RMSEP will be changed permanently
      comp.c <- comp.all[change.variable]

      left.variables.t <- left.variables
      if(direc){#change one variable permanently, depending on the direction
        left.variables.t[change.variable] <- TRUE
      }else{
        left.variables.t[change.variable] <- FALSE
      }
    }else{ #calculate leftvaribles in this way, if algorithm is CARS not CARS
      if(counter.rep == 1 && direc){ #exceptiion for the first loop and direction is forwards, because procrustes doesn't work under this cirumstances
        left.variables.t <- left.variables
        change.variable <- round(mean(1:length(left.variables)),digits = 0) #changed variable is the middle variable
        procrus.dist.best <- NA
        procrus.GF.best <- NA
        left.variables.t[change.variable] <- TRUE

      }else{ #normally do this
        if(selectionalgorithm == "Procrustes"){#calculate leftvaribles in this way, if algorithm is Procrustes

          if(multithread){#multithreadsolution to test all possibilties in adding or deleting variables
            cores <- detectCores(logical = TRUE) #find out the number of threads the computer can handle
            cl <- makeCluster(cores) #create new instances of R, each instance of R uses one thread

            clusterExport(cl= cl,envir = environment(), varlist = c('procrustes.int','procrustes.own', 'data',  'direc', 'left.variables', 'Trace', 'yellow'))

            #parApply, does the same as apply. It splits the work to the different instances of R, definded in cl.
            procrus <- parApply(cl = cl,X = X.apply, MARGIN = 1, FUN = procrustes.int, data = data,  direc = direc, left.variables.l = left.variables)
            stopCluster(cl) #close the additional no more necessary instances of R
          }else{#singlethreadsolution to test all possibilties in adding or deleting variables
            #call PLSR.int for every variable with simple apply function
            procrus <- apply(X = X.apply, MARGIN = 1, FUN = procrustes.int, data = data, direc = direc, left.variables.l = left.variables)
          }
        }

        if(selectionalgorithm == "PCA.procrustes"){ #calculate leftvaribles in this way, if algorithm is PCA.procrustes
          prcomp.B <- prcomp(x = data$prepdata$X[,left.variables, drop = FALSE], center = FALSE, scale. = FALSE)
          scores.B <- predict(prcomp.B)
          if(multithread){#multithreadsolution to test all possibilties in adding or deleting variables
            cores <- detectCores(logical = TRUE) #find out the number of threads the computer can handle
            cl <- makeCluster(cores) #create new instances of R, each instance of R uses one thread

            clusterExport(cl = cl,envir = environment(), varlist = c('PCA.procrustes.int','procrustes.own','prcomp', 'predict', 'data',  'direc', 'left.variables', 'Trace', 'yellow', 'scores.B', 'ncomp.PCA.PA'))

            #parApply, does the same as apply. It splits the work to the different instances of R, definded in cl.
            procrus <- parApply(cl = cl,X = X.apply, MARGIN = 1, FUN = PCA.procrustes.int, data = data,  direc = direc, left.variables.l = left.variables, scores.B = scores.B, ncomp.PCA.PA = ncomp.PCA.PA)
            stopCluster(cl) #close the additional no more necessary instances of R
          }else{#singlethreadsolution to test all possibilties in adding or deleting variables
            #call PLSR.int for every variable with simple apply function
            procrus <- apply(X = X.apply, MARGIN = 1, FUN = PCA.procrustes.int, data = data, direc = direc, left.variables.l = left.variables, scores.B = scores.B, ncomp.PCA.PA = ncomp.PCA.PA)
          }

        }
        #save the values from procrus to single variables
        procrus.dist <- procrus[1,]
        procrus.GF <- procrus[2,]

        left.variables.t <- left.variables#copy of left.varibles for local calculations
        if(direc){#depending on the direction calculate values
          change.variable <- which.min(procrus.GF)
          procrus.GF.best <- min(procrus.GF, na.rm = TRUE)
          procrus.dist.best <- procrus.dist[change.variable]
          left.variables.t[change.variable] <- TRUE
        }else{
          change.variable <- which.max(procrus.GF)
          procrus.GF.best <- max(procrus.GF, na.rm = TRUE)
          procrus.dist.best <- procrus.dist[change.variable]
          left.variables.t[change.variable] <- FALSE
        }
      }




      #calculate the current RMSEP, for comparison with the last RMSEP
      RMSEP <- plsr.RMSEP.variableselection(data = data, ncomp = ncomp, validation = validation, PLS.method = PLS.method, centeredY = centeredY, segments = segments, left.variables = left.variables.t)


      if(n.Y == 1){ #if there is one Y.variable do this
        RMSEP.c <- min(RMSEP) #mininal RMSEP of all components
        comp.c <- which.min(RMSEP)
      }else{ #if there is more than one Y.variable do this
        RMSEP.c <- min(apply(RMSEP, MARGIN = 2, sum)) #the same as with one Y.variable, except to sum up all RMSEP of one component, to observe all Y-variables
        comp.c <- which.min(apply(RMSEP, MARGIN = 2, sum))
      }
    }







    if(break.up == "RMSEP.decrease.break"){ #use breakupcriterion a worser RMSEP, than in the last round, if break.up == "RMSEP.decrease.break"  is not defined
      if(!is.null(n.variables)){
        if(sum(left.variables)==n.variables){
          if(RMSEP.c > RMSEP.ref){ #if there is no better RMSEP in the last round, then the RMSEP of the last round is the final RMSEP
            RMSEP.fin <- RMSEP.ref
          }else{
            RMSEP.fin <- RMSEP.c
          }
          cat(green(paste0("completed\n")))
          break #stop loop
        }
      }
      #compare RMSEP.c with the reference (defined above)
      if(RMSEP.c > RMSEP.ref){ #if there is no better RMSEP in the last round, then the RMSEP of the last round is the final RMSEP
        RMSEP.fin <- RMSEP.ref
        cat(green(paste0("completed\n")))
        break
      } #stop loop
    }




    #save informations to history
    history[counter.rep,1] <- RMSEP.c
    history[counter.rep,2] <- RMSEP.ref
    history[counter.rep,3] <- change.variable
    history[counter.rep,4] <- comp.c

    if(selectionalgorithm == "Procrustes" || selectionalgorithm == "PCA.procrustes" ){#additional history for procrustes
      history[counter.rep,5] <- procrus.dist.best
      history[counter.rep,6] <- procrus.GF.best
    }

    left.variables <- left.variables.t

    #print some information to the Consol to show the user, that the programm is running
    cat(red(paste0("\nround",counter.rep,"\n")))
    if(selectionalgorithm == "Procrustes" || selectionalgorithm == "PCA.procrustes" ){
      print("procrus.GF.best")
      print(procrus.GF.best)
      print("procrus.dist.best")
      print(procrus.dist.best)
    }
    print("RMSEP.c")
    print(RMSEP.c)
    print("RMSEP.ref")
    print(RMSEP.ref)
    print("comp")
    print(comp.c)
    print("changed.variable")
    print(change.variable)


    if(break.up == "specify.n.vari"){#use specified number of left variables as a breakup criterion, if n.variables is defined and break.up = "specify.n.vari"
      if(sum(left.variables)==n.variables){
        RMSEP.fin <- RMSEP.c
        cat(green(paste0("completed\n")))
        break #stop loop
      }
    }

    if(break.up == "best.overall" | break.up =="interactive"){
      if(!is.null(n.variables)){#calculate until a speciefied number of vairable is reached
        if(sum(left.variables)==n.variables){
          RMSEP.fin <- RMSEP.c
          cat(green(paste0("completed\n")))
          break.crit = TRUE #break.crit TRUE to start selcetion of left.variables
        }else{break.crit = FALSE}
      }else{#calculate all loops until all variable has been changed
        if(direc){
          if(ncol(data$prepdata$X) == counter.rep){break.crit = TRUE}else{break.crit = FALSE}
        }else{
          if((ncol(data$prepdata$X)-1) == counter.rep){break.crit = TRUE}else{break.crit = FALSE}
        }
      }

      if(break.crit){
        if(break.up =="interactive"){#in interactive select the best number of varibles per hand
          print(history)

          if(direc){
            repeat{#loop for a valid entry
              n.change.var <- readline("How many variables should be choosen (type \"best\", if min RMSEP should be used): ")
              if(n.change.var == "best"){#if "best" make the same like with best.overall
                n.change.var <- which(min(history[,1], na.rm = TRUE)==history[,1])
                if(min(history[,1], na.rm = TRUE) > history[1,2]){ n.change.var <- 0}
                break
              }
              n.change.var <- suppressWarnings(try(as.numeric(n.change.var),silent = TRUE)) #use the number of changed variables
              if(is.null(n.change.var)| n.change.var <= 0 | n.change.var >  ncol(data$prepdata$X)){
                cat(red("no valid entry\n"))
              }else{
                break
              }
            }
          }else{
            repeat{ #loop for a valid entry
              n.change.var <- readline("How many variables should be deleted (type \"best\", if min RMSEP should be used): ")
              if(n.change.var == "best"){#if "best" make the same like with best.overall
                n.change.var <- which(min(history[,1], na.rm = TRUE)==history[,1])
                if(min(history[,1], na.rm = TRUE) > history[1,2]){ n.change.var <- 0}
                break
              }
              n.change.var <- suppressWarnings(try(as.numeric(n.change.var),silent = TRUE)) #use the number of changed variable
              if(is.null(n.change.var)| n.change.var < 0 | n.change.var >= ncol(data$prepdata$X)){
                cat(red("no valid entry\n"))
              }else{
                break
              }
            }
          }
        }

        if(break.up == "best.overall"){ #select the number of variables, in a way, so that the RMSEP is minimal
          n.change.var <- which(min(history[,1], na.rm = TRUE)==history[,1])
          if(min(history[,1], na.rm = TRUE) > history[1,2]){ n.change.var <- 0}
        }
        if(n.change.var != 0){all.change.variables <- history[1:n.change.var,3]}else{all.change.variables <- NULL}

        if(direc){ #depending on the direction, create left variables only with TRUEs (backwards) or FALSEs (forwards) and then change all, that should be deleted or added
          left.variables <- rep(FALSE,ncol(data$prepdata$X))
          if(n.change.var != 0){left.variables[all.change.variables] <- TRUE}

        }else{
          left.variables <- rep(TRUE,ncol(data$prepdata$X))
          if(n.change.var != 0){left.variables[all.change.variables] <- FALSE}

        }
        RMSEP.fin <- history[n.change.var, 1]
        cat(green(paste0("completed\n")))
        break
      }


    }

    counter.rep <- counter.rep +1 #count up counter for the rounds
  }
  #after the loop is finished, change the variables of the input data and save it as the output data
  data.output <- data.input
  data.output$prepdata$X <- data.input$prepdata$X[,left.variables, drop = FALSE] #change Variables (X)
  data.output$wavelengths <- data.input$wavelengths[left.variables, drop = FALSE] #change wavelengths

  if(printplots.TF){#print plots after variableselection
    printplot.allspectrums(X = data.output$wavelengths, Y = data.output$prepdata$X, name = paste0("spectrums after ", selectionalgorithm), xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), type = "p") #print all spectrums after CARS
  }

  if(savedata.TF){ #data will be saved always, except the function is performed in the predict function
    #save interesting data depending on the method
    if(validation == "CV"){
      CV.infos <- list(segments.CV = segments.CV, segments.type.CV = segments.type.CV, repetitions = repetitions, segments = segments)
    }else{
      CV.infos <- NULL
    }
    add.infos <- list(validation = validation, method = PLS.method, direction = direction, ncomp = ncomp, ncomp.PCA.PA = ncomp.PCA.PA, multithread = multithread, RMSEP.init = RMSEP.init, RMSEP.fin = RMSEP.fin, n.Y = n.Y, centerX = centerX, standardizeX = standardizeX)
    savedata <- list(databefor = data.input$prepdata$X, dataafter = data.output$prepdata$X, wavelengthsbefor = data.input$wavelengths ,wavelengthsafter = data.output$wavelengths, left.variables = left.variables, history = history, add.infos = add.infos, CV.infos = CV.infos, break.up = break.up, n.variables = n.variables)
    data.output$directorymethoddone <- data.input$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data.output$directorymethoddone$methoddone(whichmethod = selectionalgorithm, data = savedata, data.info = data$data.info$clone(deep=TRUE)) #save all savedata to directorymethoddone object
  }
  cat(green("variableselection completed\n"))
  return(data.output)

}
