CV.algo <- function(seg.n, data, model.calc, segments, ncomp){
  prepdata <- data$prepdata[ -segments[[seg.n]],, drop = FALSE]
  if(model.calc == "PCR"){
    model.plsr <- pcr(Y ~ X, data = prepdata, validation = "none", ncomp = ncomp, center = FALSE, scale = FALSE)
  }else{
    model.plsr <- plsr(Y ~ X, data = prepdata, validation = "none", method = model.calc, ncomp = ncomp, center = FALSE, scale = FALSE)
  }
  Y.pred <- predict(object = model.plsr, ncomp = 1:ncomp, newdata = data$prepdata$X[segments[[seg.n]],, drop = FALSE])
  return(Y.pred)
}

CV.algo.kpls <- function(seg.n, data,  segments, ncomp, kfun){
  newdata <- data$prepdata$X[segments[[seg.n]],, drop = FALSE]
  data$prepdata <- data$prepdata[ -segments[[seg.n]],, drop = FALSE]
  model <- kpls(data = data, ncomp = ncomp, kfun = kfun, savedata.TF = FALSE, fast = TRUE)
  Y.pred <- kpls.predict(model = model$model, which.comp = 1:ncomp, newdata = newdata)
  return(Y.pred)
}

#internal function to generate the right segments for CV
generate.segments <- function(data, segments.CV = NULL, segments.type.CV = NULL, repetitions = data$data.info$read.repetitions()){
  if(is.list(segments.CV)){return(segments.CV)} #if seqments.CV is already a list, then use this list
  N.data <- nrow(data$prepdata$Y) #length of the list for segments
  if(is.null(repetitions)){ #are there repetitions in the dataset
    if(is.null(segments.type.CV)){segments.type.CV = "interleaved"} #normaly interleaved is the best
    if(is.null(segments.CV)){segments.CV = 10} #standard value for segments is 10
    segments <- cvsegments(N = N.data, k = segments.CV, type = segments.type.CV) #function for the creation of the segments
  }else{
    if(is.null(segments.type.CV)){segments.type.CV = "consecutive"} #consecutive senseful for repetitions
    if(is.null(segments.CV)){segments.CV = N.data/repetitions} #if repetitions was specified, than create as much as possible with one segment with all repetitions
    segments <- cvsegments(N = N.data, k = segments.CV, type = segments.type.CV, nrep = repetitions)#function for the creation of the segments
  }
  return(segments)
}

crossvalidation <- function(model,
                            validation = "CV",
                            segments.CV = NULL,
                            segments.type.CV = NULL,
                            repetitions = model$data.info$read.repetitions(), #the number of repetitions at one Datapoint
                            savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                            centeredY = model$data.info$read.centeredY(), #Y should be always centered (TRUE), only change if you know what you do
                            which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                            ...){
  cat(silver("crossvalidation started\n"))

  check.data(data = model, model = TRUE)
  originalY <- model$data.info$read.originalY()

  if(validation != "CV" && validation != "LOO"){stop("validation has to be \"CV\" or \"LOO\".")}

  if(is.null(which.n.method)){
    which.n.method <- model$directorymethoddone$number.methoddone("plsr.ex")
  }
  name.method <- paste("plsr.ex",which.n.method, sep = "")
  input.l <- model$directorymethoddone$read.data("plsr.ex")[[name.method]]
  model.calc <- input.l$data$model.calc
  ncomp <- input.l$data$ncomp

  if(input.l$data$kpls){
    kfun <- input.l$data$model$kFUN
  }

  if(validation == "LOO"){
    if(!is.null(repetitions)){
      warning("LOO is not recommended with repetitions in the dataset!")
    }
    max.ncomp <- calc.max.comp(data = model, validation = validation, segments = segments)
    if(is.null(ncomp)){ncomp <- max.ncomp}
    if(ncomp > max.ncomp){
      ncomp <- max.ncomp
      warning(paste0("The number of components (ncomp) was set to ", max.ncomp, " ,because it is not possible to calculate more components"))
    }

    segments <- generate.segments(data = model, segments.CV = nrow(model$prepdata), segments.type.CV = "consecutive")
    #test <- CV.algo(seg.n = 1, data = model, model.calc = model.calc, segments = segments, ncomp = ncomp)
    #Y.pred.cent <- apply(X = segment.number, MARGIN = 1, FUN = CV.algo, data = model, model.calc = model.calc, segments = segments, ncomp = ncomp)
    Y.pred <- array(data = NA, dim = c(nrow(model$prepdata), ncol(model$prepdata$Y), ncomp), dimnames = list(rownames(model$prepdata), colnames(model$prepdata$Y), paste0("comp", 1:ncomp)))
    for(i in 1:length(segments)){
      if(input.l$data$kpls){
        Y.pred.l <- CV.algo.kpls(seg.n = i, data = model, segments = segments, ncomp = ncomp, kfun = kfun)
      }else{
        Y.pred.l <- CV.algo(seg.n = i, data = model, model.calc = model.calc, segments = segments, ncomp = ncomp)
      }
      Y.pred[segments[[i]],1:ncol(model$prepdata$Y),1:ncomp] <- Y.pred.l

    }

  }
  if(validation == "CV"){
    segments <- generate.segments(data = model, segments.CV = segments.CV, segments.type.CV = segments.type.CV, repetitions = repetitions)
    segment.number <- matrix(data = 1:length(segments), ncol = 1)

    max.ncomp <- calc.max.comp(data = model, validation = validation, segments = segments)
    if(is.null(ncomp)){ncomp <- max.ncomp}
    if(ncomp > max.ncomp){
      ncomp <- max.ncomp
      warning(paste0("The number of components (ncomp) was set to ", max.ncomp, " ,because it is not possible to calculate more components"))
    }

    Y.pred <- array(data = NA, dim = c(nrow(model$prepdata), ncol(model$prepdata$Y), ncomp), dimnames = list(rownames(model$prepdata), colnames(model$prepdata$Y), paste0("comp", 1:ncomp)))
    for(i in 1:length(segments)){
      if(input.l$data$kpls){
        Y.pred.l <- CV.algo.kpls(seg.n = i, data = model, segments = segments, ncomp = ncomp, kfun = kfun)
      }else{
        Y.pred.l <- CV.algo(seg.n = i, data = model, model.calc = model.calc, segments = segments, ncomp = ncomp)
      }
      Y.pred[segments[[i]],1:ncol(model$prepdata$Y),1:ncomp] <- Y.pred.l
    }
  }




  #because Y was centered usually, this centering has be undone
  if(centeredY == TRUE){
    Y.pred.cent <- Y.pred
    dim.Ypred <- dim(Y.pred.cent)
    Y.pred <- array(data = NA, dim = dim.Ypred, dimnames = dimnames(Y.pred.cent))
    for(i3 in 1:dim.Ypred[3]){ #loop, if there more than one component passed with ncomp, number of loop depends on the number of components (ncomp = 7 -> 1 loop; ncomp = 1:7 -> 7 loops)
      for(i2 in 1:dim.Ypred[2]){

        #crazy construct with the goal to transform an array into a matrix
        #drop function doesn´t work, because so a vector will be created
        Y.pred.i <- Y.pred.cent[,i2,i3, drop = FALSE]
        Y.pred.i <- as.matrix(Y.pred.i)

        #apply function, to add up the mean to the predicted Y-values

        Y.pred[,i2,i3] <- apply(Y.pred.i, MARGIN = 1, FUN = add.spectrum, mean.spec = model$oriY$Y.mean[i2])
      }
    }
  }


  if(originalY){
    Y.pred <- undo_corrections_Y(model = model, Ydata = Y.pred)
  }


  # measured.all <- input.l$data$directorymethoddone$read.this.data(input.l$data$directorymethoddone$names.donemethods()[1])$data$dataYori
  # measured.all <- checkandpeform.changes.Y(model = model, Ydata = measured.all, Ydata_transformation = TRUE, calc.meanspectra = TRUE, splitdata.exval = TRUE)
  #
  measured.all <- model$oriY$Y.values
  measured.all <- checkandpeform.changes.Y(model = model, Ydata = measured.all)
  if(originalY){
    measured.all <- undo_corrections_Y(model = model, Ydata = measured.all)
  }

  if(ncol(measured.all) != dim(Y.pred)[2] || nrow(measured.all) != dim(Y.pred)[1]){stop("predicted and measured values don't fit together")}




  model$model$RMSEP.CV <- parameter.calc(meas = measured.all, pred = Y.pred)
  if(savedata.TF){
    #save all important data to methoddone in directorymethoddone
    input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = model, whichfunc = "plsr.ex")
    savedata <- list(own.CV = TRUE, RMSEP.CV = model$model$RMSEP.CV, ncomp = ncomp, modelname = input.l$name.method, Y.pred = Y.pred, measured.all = measured.all, segments.CV = segments.CV, segments.type.CV = segments.type.CV, repetitions = repetitions, segments = segments)
    model$directorymethoddone <- model$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    model$directorymethoddone$methoddone(whichmethod = "crossvalidation", data = savedata, data.info = model$data.info$clone(deep = TRUE)) #save the data to a new methoddone object in directorymethoddone
  }

  cat(green("crossvalidation completed\n"))
  return(model)
}

