#internal function to calculate one step of the crossvalidation
CV.algo <- function(seg.n, data, model.calc, segments, ncomp){
  prepdata <- data$prepdata[ -segments[[seg.n]],, drop = FALSE]#left out one segment of the dataset
  if(model.calc == "PCR"){ #calculate model for the reduced dataset
    model.plsr <- pcr(Y ~ X, data = prepdata, validation = "none", ncomp = ncomp, center = FALSE, scale = FALSE)
  }else{
    model.plsr <- plsr(Y ~ X, data = prepdata, validation = "none", method = model.calc, ncomp = ncomp, center = FALSE, scale = FALSE)
  }
  #make predictions for the left out segment with the calculated model
  Y.pred <- predict(object = model.plsr, ncomp = 1:ncomp, newdata = data$prepdata$X[segments[[seg.n]],, drop = FALSE])
  return(Y.pred)
}

#internal function to calculate one step of the crossvalidation for a Kernel-PLS model
CV.algo.kpls <- function(seg.n, data,  segments, ncomp, kfun){
  newdata <- data$prepdata$X[segments[[seg.n]],, drop = FALSE]#safe the data, which should be left out, for the prediction
  data$prepdata <- data$prepdata[ -segments[[seg.n]],, drop = FALSE]#left out one segment of the dataset
  model <- kpls(data = data, ncomp = ncomp, kfun = kfun, savedata.TF = FALSE, fast = TRUE)#calculate Kernel-PLS Model for the reduced dataset
  Y.pred <- kpls.predict(model = model$model, which.comp = 1:ncomp, newdata = newdata) #make predictions for the left out segment, with the Kernel-PLS model
  return(Y.pred)
}

#internal function to generate the right segments for CV
generate.segments <- function(data, segments.CV = NULL, segments.type.CV = NULL, repetitions = data$data.info$read.repetitions()){
  if(is.list(segments.CV)){return(segments.CV)} #if seqments.CV is already a list, then use this list
  N.data <- nrow(data$prepdata$Y) #length of the list for segments
  if(is.null(repetitions)){ #are there repetitions in the dataset
    if(is.null(segments.type.CV)){segments.type.CV = "interleaved"} #normaly interleaved is the best
    if(is.null(segments.CV)){segments.CV = 10} #standard value for segments is 10
    segments <- cvsegments(N = N.data, k = segments.CV, type = segments.type.CV) #function for the creation of the segments
  }else{
    if(is.null(segments.type.CV)){segments.type.CV = "consecutive"} #consecutive senseful for repetitions
    if(is.null(segments.CV)){segments.CV = N.data/repetitions} #if repetitions was specified, than create as much as possible with one segment with all repetitions
    segments <- cvsegments(N = N.data, k = segments.CV, type = segments.type.CV, nrep = repetitions)#function for the creation of the segments
  }
  return(segments)
}

#function to perform a crossvalidation
crossvalidation <- function(model, #the dataset, which includes a model, that should be crossvalidated
                            validation = "CV", #the validationtype "CV" or "LOO"
                            segments.CV = NULL, #the number of segments for the crossvalidation, ot a complete segments list
                            segments.type.CV = NULL, #the type, how the segments should be splitted
                            repetitions = model$data.info$read.repetitions(), #the number of repetitions at one Datapoint
                            savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                            centeredY = model$data.info$read.centeredY(), #Y should be always centered (TRUE), only change if you know what you do
                            which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                            ...){
  cat(silver("crossvalidation started\n"))

  #first check the dataset
  check.data(data = model, model = TRUE)

  #read out, if the original values should be used
  originalY <- model$data.info$read.originalY()

  #check validation type
  if(validation != "CV" && validation != "LOO"){stop("validation has to be \"CV\" or \"LOO\".")}

  #read in model
  if(is.null(which.n.method)){
    which.n.method <- model$directorymethoddone$number.methoddone("plsr.ex")
  }
  name.method <- paste("plsr.ex",which.n.method, sep = "")
  input.l <- model$directorymethoddone$read.data("plsr.ex")[[name.method]]

  model.calc <- input.l$data$model.calc #method of the modelcalulation, NIPALS, SIMPLS and so on
  ncomp <- input.l$data$ncomp #the max number of components

  if(input.l$data$kpls){ #load Kernelfunction, if the model is a Kernel-PLS model
    kfun <- input.l$data$model$kFUN
  }

  if(validation == "LOO"){#do this for the leave one out Crossvaldiation
    if(!is.null(repetitions)){
      warning("LOO is not recommended with repetitions in the dataset!")
    }
    max.ncomp <- calc.max.comp(data = model, validation = validation, segments = segments)
    if(is.null(ncomp)){ncomp <- max.ncomp}
    if(ncomp > max.ncomp){ #change ncomp, if necessary
      ncomp <- max.ncomp
      warning(paste0("The number of components (ncomp) was set to ", max.ncomp, " ,because it is not possible to calculate more components"))
    }

    #create segments list, with only one datapoint, in each segment
    segments <- generate.segments(data = model, segments.CV = nrow(model$prepdata), segments.type.CV = "consecutive")

    #empty array fort the predcited values
    Y.pred <- array(data = NA, dim = c(nrow(model$prepdata), ncol(model$prepdata$Y), ncomp), dimnames = list(rownames(model$prepdata), colnames(model$prepdata$Y), paste0("comp", 1:ncomp)))

    #loop for the predictions for each segment
    for(i in 1:length(segments)){
      if(input.l$data$kpls){ #kernel-PLS or other model
        Y.pred.l <- CV.algo.kpls(seg.n = i, data = model, segments = segments, ncomp = ncomp, kfun = kfun)
      }else{
        Y.pred.l <- CV.algo(seg.n = i, data = model, model.calc = model.calc, segments = segments, ncomp = ncomp)
      }
      Y.pred[segments[[i]],1:ncol(model$prepdata$Y),1:ncomp] <- Y.pred.l

    }

  }
  if(validation == "CV"){#do this for the crossvaldiation with segments
    #create segments depending on the settings
    segments <- generate.segments(data = model, segments.CV = segments.CV, segments.type.CV = segments.type.CV, repetitions = repetitions)
    segment.number <- matrix(data = 1:length(segments), ncol = 1)

    max.ncomp <- calc.max.comp(data = model, validation = validation, segments = segments)
    if(is.null(ncomp)){ncomp <- max.ncomp}
    if(ncomp > max.ncomp){#change ncomp, if necessary
      ncomp <- max.ncomp
      warning(paste0("The number of components (ncomp) was set to ", max.ncomp, " ,because it is not possible to calculate more components"))
    }
    #empty array fort the predcited values
    Y.pred <- array(data = NA, dim = c(nrow(model$prepdata), ncol(model$prepdata$Y), ncomp), dimnames = list(rownames(model$prepdata), colnames(model$prepdata$Y), paste0("comp", 1:ncomp)))
    #loop for the predictions for each segment
    for(i in 1:length(segments)){
      if(input.l$data$kpls){#kernel-PLS or other model
        Y.pred.l <- CV.algo.kpls(seg.n = i, data = model, segments = segments, ncomp = ncomp, kfun = kfun)
      }else{
        Y.pred.l <- CV.algo(seg.n = i, data = model, model.calc = model.calc, segments = segments, ncomp = ncomp)
      }
      Y.pred[segments[[i]],1:ncol(model$prepdata$Y),1:ncomp] <- Y.pred.l
    }
  }




  #because Y was centered usually, this centering has be undone
  if(centeredY == TRUE){
    Y.pred.cent <- Y.pred
    dim.Ypred <- dim(Y.pred.cent)
    Y.pred <- array(data = NA, dim = dim.Ypred, dimnames = dimnames(Y.pred.cent))
    for(i3 in 1:dim.Ypred[3]){ #loop, if there more than one component passed with ncomp, number of loop depends on the number of components (ncomp = 7 -> 1 loop; ncomp = 1:7 -> 7 loops)
      for(i2 in 1:dim.Ypred[2]){

        #crazy construct with the goal to transform an array into a matrix
        #drop function doesn´t work, because so a vector will be created
        Y.pred.i <- Y.pred.cent[,i2,i3, drop = FALSE]
        Y.pred.i <- as.matrix(Y.pred.i)

        #apply function, to add up the mean to the predicted Y-values

        Y.pred[,i2,i3] <- apply(Y.pred.i, MARGIN = 1, FUN = add.spectrum, mean.spec = model$oriY$Y.mean[i2])
      }
    }
  }


  if(originalY){#recalculate orignal Y-values
    Y.pred <- undo_corrections_Y(model = model, Ydata = Y.pred)
  }

  #read the original measured Y-values
  measured.all <- model$oriY$Y.values
  #perform all changes for them, so they are compatible with the predicted ones
  measured.all <- checkandpeform.changes.Y(model = model, Ydata = measured.all)
  if(originalY){
    measured.all <- undo_corrections_Y(model = model, Ydata = measured.all)
  }

  if(ncol(measured.all) != dim(Y.pred)[2] || nrow(measured.all) != dim(Y.pred)[1]){stop("predicted and measured values don't fit together")}


  #calculate the valdiationparameters
  model$model$RMSEP.CV <- parameter.calc(meas = measured.all, pred = Y.pred)

  if(savedata.TF){
    #save all important data to methoddone in directorymethoddone
    input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = model, whichfunc = "plsr.ex")
    savedata <- list(own.CV = TRUE, RMSEP.CV = model$model$RMSEP.CV, ncomp = ncomp, modelname = input.l$name.method, Y.pred = Y.pred, measured.all = measured.all, segments.CV = segments.CV, segments.type.CV = segments.type.CV, repetitions = repetitions, segments = segments)
    model$directorymethoddone <- model$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    model$directorymethoddone$methoddone(whichmethod = "crossvalidation", data = savedata, data.info = model$data.info$clone(deep = TRUE)) #save the data to a new methoddone object in directorymethoddone
  }

  cat(green("crossvalidation completed\n"))
  return(model)
}

