
#this function will be called, if the package will be added to the library
.onAttach <- function(libname, pkgname){
  line1 <- "\n\nWelcome to my package \"PLSR.Kronsbein\"\n\n"
  line2 <- "If you need help, please use the manual in my bachelor thesis: \"FTNIR-Spektroskopie und multivariate Datenanalyse zur Qualitätskontrolle von Elektrophoresegelen\"\n"
  line3 <- "If you read it carefully and it still doesn't help you, you can contact me under: klaus.kronsbein97@gmail.com\n"
  packageStartupMessage(c(line1, line2, line3 ))

}


#general preparations
gener.prep <- function(digits = 4) #number of decimal places
{
  cat(silver("gener.prep started\n"))
  options(digits = digits) #set the number of decimal places
  options(max.print = .Machine$integer.max) #set max.print to the maximum
  cat(green("gener.prep completed\n"))
}

fread.csv.trycatch <- function(rfile, silent = FALSE)#local function to be sure, that an existing file in the right format was passed
{
  if(!silent) cat(silver("fread.csv.trycatch started\n"))
  tryCatch({data.read <- fread(rfile)},#try to read a file, if an error or warning occurs, then stop the programm and return a helpful message
           error = function(cond){
             stop("Please pass an existing .csv file in the american format.\nThe file has to be in the same directory, as the executed file.\n")
             return(NULL)},
           warning = function(cond){
             stop("Please pass an existing .csv file in the american format.\nThe file has to be in the same directory, as the executed file.\n")
             return(NULL)})
  if(!silent) cat(green("fread.csv.trycatch completed\n"))
  return(data.read)
}

# function to print all spectrums in a dataset into one plot
printplot.allspectrums <- function(X, #Values for X-axis
                                   Y, #Dataset of Values for Y-axis
                                   name="", #name of the plot
                                   xlab="", #label of the x-axis
                                   ylab="", #label of the y-axis
                                   type= "l", #type of datapoint lines or points
                                   pch = 20, #size of the font
                                   cex = 2, #size of the datapoints
                                   lwd = 1, #thickness of the lines
                                   ylim = NULL, #vector of length 2 for the limitations of the Y-axis
                                   xlim = NULL, #vector of length 2 for the limitations of the X-axis
                                   silent = FALSE, #if TRUE, no Console output
                                   col.p = NULL, #pass here the colours of each datapoint/variable
                                   col.l = NULL, #passe here the colours of each line/spectrum
                                   ...){
  if (!silent) {cat(silver("printplot.all started\n"))}
  #check which option was used to colour the plot
  if(is.null(col.p)){
    if(is.null(col.l)){
      col <- "black" #no colurs, everything is black
    }else{
      #colours for the lines
      if(!is.vector(Y) && length(col.l) < nrow(Y)){ #if the colour vector is not long enough, repeat it
        col.l <- rep(col.l, ceiling(nrow(Y)/length(col.l)))
      }
      col <- col.l[1] #first choose the first colour
    }
  }else{
    if(is.null(col.l)){ #colour the point was used
      col <-  col.p
    }else{
      stop("Choose only one col.l or col.p") #error if both isn´t NULL. It is not possible to use both
    }
  }
  #if not specified set the limitations of the axes to the minimum and maximum value
  if(is.null(ylim)){
    ylim <- c(min(Y),max(Y))
  }
  if(is.null(xlim)){
    xlim <- c(min(X),max(X))
  }
  if(is.vector(Y)){plot(x=X,y=Y, type = type, main = name, xlab = xlab, ylab = ylab, pch = pch, cex = cex, ylim = ylim, xlim = xlim, col = col, lwd = lwd)}
  else{
    for (i in 1:nrow(Y)){ #loop: one repetition for each spectrum
      Y.l <- Y[i,] #local Y-Values are the i-th row of the dataset
      if (i ==1){ # during first repetition create a new plot
        plot(x=X,y=Y.l, type = type, main = name, xlab = xlab, ylab = ylab, pch = pch, cex = cex, ylim = ylim, xlim = xlim, col = col, lwd = lwd)
      }else{ # in all the other repetitions add lines to these plots
        if(!is.null(col.l)){ #for each line go through the the col.l vector
          col <- col.l[i]
        }
        switch (type, #add the other data, depending on type
          "l" = lines(x=X,y=Y.l, col = col, lwd = lwd),
          "p" = points(x=X,y=Y.l, pch = pch, cex = cex, col = col, lwd = lwd),
          "b" = {lines(x=X,y=Y.l, col = col, lwd = lwd)
                 points(x=X,y=Y.l, pch = pch, cex = cex, col = col, lwd = lwd)}
        )

      }
    }
  }
  if(!silent){cat(green("printplot.all completed\n"))}
}


###internal function to catch errors with the tolerance in the solve function
###solve function is necessary to calculate an inverse matrix
solve.try.catch <- function(Matrix, tol, Feedback = TRUE){ #necessary parameters
  if(Feedback){cat(silver("solve.try.catch started\n"))}
  repeat{#a loop, that test if the solve function works. If not the tolerance will be decreased. For big matrices a lower tolerance is necessary
    inv.Matrix <- try(solve(Matrix, tol = tol),silent = TRUE) #try calculation of solve
    if(!(typeof(inv.Matrix) == "character")){break} #if calculation has passed stop the loop
    tol <- tol*1e-3 #decrease of tolerance
  }
  if(Feedback){cat(green("solve.try.catch completed\n"))}
  #print("tolerance")
  #print(tol)
  return(inv.Matrix) #return inverse matrix
}



#internal function, it return TRUE, if there is a proplem with degreeofsmoothing
false.degreeofsmoothing <- function(degreeofsmoothing){
  if(degreeofsmoothing < 3){return(TRUE)} #test if degreeofsmoothing is greater than 3
  modulorest1 <- degreeofsmoothing%%1 #modulo operator--> will return the rest of the division
  if (modulorest1 != 0){return(TRUE)} #test if degreofsmoothing is an interger, doesn´t have to be saved as an integer
  modulorest2 <- degreeofsmoothing%%2 #modulo operator--> will return the rest of the division
  if(modulorest2 == 0){return(TRUE)} #test if degreeofsmoothing is an odd number
  return(FALSE) #everything is okay with degreeofsmoothing
}

#internal function, which returns TRUE, if there is a proplem with model
false.model <- function(model){
  if(model < 0){return(TRUE)} #test if model is greater or equal than 0
  modulorest1 <- model%%1 #modulo operator--> will return the rest of the division
  if (modulorest1 != 0){return(TRUE)} #test if model is an interger, doesn´t have to be saved as an integer
  return(FALSE) #everything is okay with model
}

#function to print error messages, if something is wrong
#only one option of matrix or source should be used, so one of them should be NULL
sourceormatrix <- function(matrix, source){
  if(is.null(matrix) & is.null(source)){stop("data have to passed via a matrix or a sourcefile")}
  if((!is.null(matrix)) & (!is.null(source))){stop("please pass data only via one option as matrix or as sourcefile")}
  if((!is.null(matrix)) & ((!is.matrix(matrix)) | (!is.numeric(matrix)))){stop("matrix has to be a numeric matrix")}
  if((!is.null(source)) & (!is.character(source))){stop("source has to be a character with the name of the source file")}
}

#function to correct the buggy apply function:
#because apply transposes the matrix, if you use it with MARGIN 1, this function is necessary
#in addition the names are lost
#it is used, if the resultspectra of apply has not the same dimension like the input spectra
apply.t <- function(X, MARGIN = 1, FUN,  ...  ){
  output.t <- apply(X = X, MARGIN = MARGIN, FUN = FUN, ...)
  if(is.matrix(output.t)){#catch case, that not a matrix is returned
    output <- t(output.t) #transpose matrix
  }else{
    output <- as.matrix(output.t) #if its only a vector, a transpossion is not necessary
  }

  dimnames(output) <- dimnames(X) #change to the original dimnames
  return(output)
}

#function to sum up spectra, used in predict function
add.spectrum <- function(ori.spec, mean.spec){
  if (length(ori.spec) != length(mean.spec)){stop("ori.spec and mean.spec don´t have the same length!")}
  output <- ori.spec + mean.spec
  return(output)
}

#function to substract to spectra, used in center function
substract.spectrum <- function(ori.spec, mean.spec){#center spectra
  if (length(ori.spec) != length(mean.spec)){stop("ori.spec and mean.spec don´t have the same length!")}
  output <- ori.spec - mean.spec
  return(output)
}

#function to divide to spectra, used in scale and standardize function
divide.spectrum <- function(ori.spec, scale.spec){#scale and standardize spectra
  if (length(ori.spec) != length(scale.spec)){stop("ori.spec and scale.spec don´t have the same length!")}
  output <- ori.spec / scale.spec
  return(output)
}

multiply.spectrum <- function(ori.spec, scale.spec){
  if (length(ori.spec) != length(scale.spec)){stop("ori.spec and scale.spec don´t have the same length!")}
  output <- ori.spec * scale.spec
  return(output)
}


#function to convert a vector to a matrix with one row, only to this if x is no matrix
as.matrix.byrow <- function(x){
  if (is.matrix(x)){return(x)}
  else{
    x <- as.matrix(x)
    x <- t(x)
    return(x)
  }
}

#function to save a dataset (model)
save.dataset <- function(X, dir = NULL, ownname = NULL, complete.file = TRUE){#X is the dataset; dir is an optional parameter, if the dataset should be saved in another directory; with ownname it is possible to set a own name for the file
  if(!is.null(dir)){ #do this, if the dir was defined
    wd.current <- getwd() #save current directory
    if(!dir.exists(dir)){ #check if directory exists
      suppressWarnings(dir.create(dir))
    }
    setwd(dir) #sewt working directory to defined dir
  }
  if(is.null(ownname)){ #do this if there is no name defined

    filename <- paste0(as.character(substitute(X)),".RData") #add to the name of the dataset ".RData"
    if(file.exists(filename)){ #if this file exists already, change the name of the file
      i <- 1
      repeat{
        filename <- paste0(as.character(substitute(X)), i,".RData")
        if(!file.exists(filename)){break}
        i <- i + 1
      }
      warning(paste0("filename was changed to \"", filename, "\" because the other files with this name already exist."))
    }
  }else{ #do this, if ownname was defined
    if(is.character(ownname)){# check if ownname is a character
      if(complete.file && !grepl(".RData", ownname)){ #check if the end of the name is .RData, if not add it
        filename <- paste0(ownname, ".RData")
      }else{
        filename <- ownname
      }
      if(file.exists(filename)){stop("A file with this filename already exists!")} #test if fiel already exists and print an error
    }else{
      stop("filename is no character") # if ownname is no character, print an error
    }
  }
  save(X, file = filename) #use save() function to save data
  if(!is.null(dir)){ #if dir was defined, set wd back to the old wd
    setwd(wd.current)
  }
}

#function to load a dataset
load.dataset <- function(file, dir = NULL, complete.file = TRUE){#file is the name of the file, that should be loaded, dir is the optional directory of the file; complete.file is a boolean, if to the filename should be add .RData, if it not exists
  if(!is.character(file)){stop("file has to be a character!")} #file has to be a character
  if(!grepl(".RData",file) & complete.file){ #do this, if ".RData" is not in file and complete.file is TRUE
    file <- paste0(file,".RData") #add ".RData" to file
    message(".RData was add to the filename in load.dataset(); if this is not desired, set complete.file to FALSE")
  }
  if(!is.null(dir)){ #do this, if the dir was defined
    wd.current <- getwd() #save current directory
    setwd(dir) #sewt working directory to defined dir
  }
  load(file = file, envir = globalenv()) #use loadfunction to load the dataset, save the dataset to the global environment
  if(!is.null(dir)){ #if dir was defined, set wd back to the old wd
    setwd(wd.current)
  }
  return(X)
}

#function to calculate the length of a vector
length.vector. <- function(X){
  if(is.matrix(X)){
    if(sum(dim(X) == 1)>0){X <- as.vector(X)}
  }
  if(!is.vector(X)){stop("X has to be a vector or a matrix with one row or one column")}
  length.X <- (sum(X^2))^0.5
  return(length.X)
}

#function, that is used in PCA and PLSR evaluation
#the sense of this function is to pass the right dataset in both cases, if the fucntion was called inside a evaluation function or by the user
check.which.n.method_or_read <- function(which.n.method, #in a evalution function the dataset, which should be used is passed here. If the function is called by a user than specify with a number, which method should be evaluated, if not specified last one is going to be used.
                                         data, #dataset
                                         whichfunc, #specify which kind of dataset should be read "plsr.ex" or "PCA.calc"
                                         ...){
  if(!is.null(which.n.method)&& !is.numeric(which.n.method)){ #if there was passed a dataset with which.n.method return this dataset immediately (happens if called in evaluation function)
    return(which.n.method)
  }
  if(is.numeric(which.n.method)){ #if there was speciefed a repetition of the method use this
    n.method <- which.n.method
    if(n.method > data$directorymethoddone$number.methoddone(whichfunc) || n.method <=0 || (n.method%%1 != 0)){stop("invalid which.n.method!")}
  }else{#else use the last one
    n.method <- data$directorymethoddone$number.methoddone(whichfunc)
  }
  #read in the dataset
  name.method <- paste0(whichfunc, n.method)
  input <- data$directorymethoddone$read.data(whichfunc)
  input.l <- input[[name.method]]
  input.l$name.method <- name.method
  return(input.l)

}

#function to check if the plots should be safed to a directory, if TRUE do all and if necessary create the directory
check.set.create.directory <- function(saveplots, directory){
  actwd <- getwd() # save the current directory
  if(saveplots & !is.null(directory)){ #if the plots should be saved and there was specified a directory then do this
    if(!dir.exists(directory)){ #check if directory exists
      suppressWarnings(dir.create(directory))
    }
    setwd(directory) #if yes set working directory to directory
  }
  return(actwd)
}




#internalfunction to create a colour ramp, used in evaluation functions
Colourramp.sorted.for.Y <- function(data, input.l, Ycol = 1, n.colours = 10000, colours = c("red", "yellow", "green", "blue", "black")){

  Y <- input.l$data$oriY$Y.values #extract Y data of dataset
  if(ncol(Y) < Ycol){stop("this Ycol is not available!")} #check whether Ycol is available
  Y <- Y[,Ycol, drop = TRUE] #use the Ymatrix and choose the specified Ycol for the colour scale

  pal <- colorRampPalette(colours)#choose colours for colour ramp
  col.all <- pal(n.colours) #create colour ramp, it doesn't fit to the order of the Ydata
  Y.sort <- 1:length(Y) #sortvector
  col <- rep(NA, length(Y)) #empty colourvector
  Y.dt <- data.table(cbind(Y, Y.sort, col), key = "Y") #combine the Y-data, the Sortvector and the colourvector to a datatable and sort the rows, depending at the Y-values

  i <- 1
  repeat{#do while loop for the different Y-values
    #first only the one Y-value will be used
    i.max <- i
    i.min <- i
    while(i.max < nrow(Y.dt) && Y.dt$Y[i.max] == Y.dt$Y[i.max+1]){#check if there similar Y-values
      i.max <- i.max+1 #increase i.max value
    }
    #mean value of i.max and i.min, rounded up
    i.mean <- round(mean(c(i.max,i.min)),digits = 0)

    #set colours depending of the Y.value (the same colour for similar Y.values)
    Y.dt$col[i.min:i.max] <- col.all[round((i.mean/nrow(Y.dt))*n.colours)]

    #set i to i.max, so only one loop for repeated Y-values will be performed
    i <- i.max
    if(i == nrow(Y.dt)){break}
    i <- i+1
  }
  Y.dt <- Y.dt[order(Y.dt$Y.sort)] #sort the datatable depending on the sortvector

  return(Y.dt$col)#return colourvector
}

#function to check if the dataset is correct
check.data <- function(data, #dataset
                       prepdata = TRUE, #check if prepdata exists
                       model = FALSE, #check if model exists
                       PCA = FALSE, #check if PCA exists
                       ...){
  if(!is.list(data)){stop("data or model has to be a list generated with dataprep.plsr() or another dataprep function.")}
  if(prepdata == TRUE &&is.null(data$prepdata)){stop("there is no prepdata in data")}
  if(model == TRUE && is.null(data$model)){stop("this function needs a model in the dataset")}
  if(PCA == TRUE && is.null(data$PCA)){stop("this function needs a PCA-dataset in the dataset")}
}

#function to calculate the max number of components in plsr.ex
calc.max.comp <- function(data,
                          validation,
                          segments,
                          ...){
  switch(validation, #calculate depending on the validation, how many rows are not available for the number of components
         "none" = {sub.ncomp <- 1},
         "ex" = {sub.ncomp <- 1},
         "LOO" = {sub.ncomp <- 2},
         "CV" = {values.per.segment.max <- 1
                 for(i in 1:length(segments)){
                 if(values.per.segment.max < length(segments[[i]])){values.per.segment.max <- length(segments[[i]])}
                 }
                 sub.ncomp <-  1 + values.per.segment.max
                },
         stop("invalid validation"))
  if(ncol(data$prepdata$X) <= (nrow(data$prepdata$X) - sub.ncomp)){ #depending on the validation and the dimensions of the X-axis the max number of components is calculated
    max.ncomp <- ncol(data$prepdata$X)
  }else{max.ncomp <- (nrow(data$prepdata$X) - sub.ncomp)}
  return(max.ncomp)
}

#function to repeat each value in a vector: example: 1,2,3 rep 2 --> 1,1,2,2,3,3
repeat.each.value.vector <- function(vector, rep){
  vec.i <- rep(vector,rep)
  vec.i <- (matrix(data = vec.i, ncol = length(vector), byrow = TRUE))
  vector <- as.vector(vec.i)
  return(vector)
}

#calculate the qualtityparameters of a calibration or a validation
parameter.calc <- function(meas, pred){
  rownames.comp <- paste0("comp", 1:dim(pred)[3])
  RMSE <- matrix(NA, nrow = dim(pred)[3], ncol = dim(pred)[2])#create an empty matrix with the right size
  BIAS <- matrix(NA, nrow = dim(pred)[3], ncol = dim(pred)[2])#create an empty matrix with the right size
  SE <- matrix(NA, nrow = dim(pred)[3], ncol = dim(pred)[2])#create an empty matrix with the right size
  R2 <- matrix(NA, nrow = dim(pred)[3], ncol = dim(pred)[2])#create an empty matrix with the right size

  mean <- apply(X = meas, MARGIN = 2, FUN = mean)
  for(i3 in 1:dim(pred)[3]){
    for(i2 in 1:dim(pred)[2]){
      RMSE[i3,i2] <- rmserr(meas[,i2], pred[,i2,i3])$rmse #calculate RMSE
      BIAS[i3,i2] <- sum(meas[,i2]- pred[,i2,i3])/length(meas[,i2]) #calculate BIAS
      SE[i3,i2] <- ((sum((meas[,i2] -  pred[,i2,i3] - rep(BIAS[i3,i2], length(meas[,i2])))^2))/(length(meas[,i2])-1))^0.5 #calcualte stadnarderror

      ex.var <- sum((pred[,i2 ,i3] - mean[i2])^2) #calculate explained variance
      tot.var <- sum((meas[,i2] - mean[i2])^2) #calculate total variance
      R2[i3, i2] <- ex.var/tot.var #R-squared is the explained variance devided by the total variance
    }
  }
  res <- list(RMSE = RMSE, BIAS = BIAS, SE = SE, R2 = R2) #return results as a list
  return(res)
}


