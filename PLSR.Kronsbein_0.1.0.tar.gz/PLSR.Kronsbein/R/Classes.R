library(R6)

# class for objects, that are administrated of an object of directorymethoddone
# an object of this class contains a number for the order of the methoderationmethods and a list "data" with all relevant data of this method for the evaluation
# additional it contains a copy of a data.info object, to know the Units
methoddone <- R6Class("methoddone",
  public = list(
    initialize = function(counterpreps.pass){ #generate a new object of this class with the counter and data is empty
      private$counterpreps <- counterpreps.pass
      private$data <- NULL
    },


    set.data = function(data, data.info){ # setter function for data, to save the datalist to this object
      private$data <- data
      private$data.info <- data.info
    },

    get.all = function(){ #function to get all saved datas of this object as a list
      list(counterpreps = private$counterpreps, data = private$data, data.info = private$data.info)
    },

    get.counterpreps = function(){ #function to get the number of this done method
      return(private$counterpreps)
    }
  ),

  private = list(

    counterpreps = 0 , #variable to save the order number of the methods
    data = NULL, #list for all saved data
    data.info = NULL #object with the Units and other infos


  )

)

#administration class for the objects of methoddone, it contains all methoddone objects
directorymethoddone <- R6Class("directorymethoddone",
  public = list(
    initialize = function(){#generate a new object with counterpreps is 0 and allmethods with an empty list
      cat(silver("directorymethoddone$initialize started\n"))
      private$counterpreps <- 0 #counter for all done methods, start 0 because method done
      private$allmethods <- list() #and empty list for the data, because no method done
      cat(green("directorymethoddone$initialize completed\n"))
    },

    methoddone = function(whichmethod, data = NULL, data.info = NULL){ #function to call, if one methodmethod was done
      cat(silver("directorymethoddone$methoddone started\n"))
      #whichmethod is the type of the done methoderation, data is the generated data
      if(!is.character(whichmethod)){stop("Whichmethod is no character!")}
      i <- 0
      repeat{ #loop to check if this method was done befor
        i <- i+1
        name <- paste(whichmethod, i, sep= "") #generate preliminary name
        test.l <- name == names(private$allmethods) #test if preliminary already exists
        if(is.null(test.l) | sum(test.l) == 0){
          cat(green("directorymethoddone$methoddone completed\n"))
          break
          } #if it exists repeat loop, if not break loop and go on
      }
      private$counterpreps <- private$counterpreps + 1 #count up the the counter for the done methodmethods
      private$allmethods[[name]] <- methoddone$new(counterpreps.pass = private$counterpreps) #generate a new object of methoddone
      private$allmethods[[name]]$set.data(data = data, data.info = data.info) #save the data to the object of methoddone
      cat(green("directorymethoddone$methoddone completed\n"))
    },

    is.methoddone = function(whichmethod, silent = TRUE){ #function to test if method was done; returns TRUE if it was done, else FALSE
      if(!silent){cat(silver("directorymethoddone$is.methoddone started\n"))}
      testmethodexists <- grepl(whichmethod, names(private$allmethods))#test if the name "whichmethod" is existing as an object of methoddone, returns a vector
      sum.testmethodexists <- sum(testmethodexists) #sum up all TRUEs
      if(!silent){cat(green("directorymethoddone$is.methoddone completed\n"))}
      if(sum.testmethodexists == 0){return(FALSE)}else{return(TRUE)} #return TRUE or FALSE, depending it was performed or not
    },

    number.methoddone = function(whichmethod){#function to test, how often this methodmethod was performed
      cat(silver("directorymethoddone$number.methoddone started\n"))
      testmethodexists <- grepl(whichmethod, names(private$allmethods))#test if the name "whichmethod" is existing as an object of methoddone, returns a vector
      sum.testmethodexists <- sum(testmethodexists) #sum up all TRUEs
      cat(green("directorymethoddone$number.methoddone completed\n"))
      return(sum.testmethodexists) #return how often the method was performed
    },

    read.data = function(whichmethod, silent = FALSE){ #function to read all data of an methodmethod for the evaluation
      if(!silent) cat(silver("directorymethoddone$read.data started\n"))
      testmethodexists <- grepl(whichmethod, names(private$allmethods)) #test if the name "whichmethod" is existing as an object of methoddone, returns a vector
      sum.testmethodexists <- sum(testmethodexists)#sum up all TRUEs
      output = list() #create an empty output list
      if(sum.testmethodexists == 0){
        if(!silent) cat(green("directorymethoddone$read.data completed\n"))
        return(NULL)
        } #if there is no data return NULL
      for (i in 1:sum.testmethodexists){ #loop for each preperation of the same type
        name.output <- paste(whichmethod, i, sep= "") #set the right name in the list for the output
        output[[name.output]] <- private$allmethods[[name.output]]$get.all() #save all data to the output
        #names(output)[i] <- name.output
      }
      if(!silent) cat(green("directorymethoddone$read.data completed\n"))
      return(output)
    },

    read.this.data = function(name.method, silent = TRUE){ #function to get the data of one exact methodmethod (with number)
      if(!silent) cat(silver("directorymethoddone$read.this.data started\n"))
      output <- private$allmethods[[name.method]]$get.all() #call function get.all of the named methoddone object
      if(!silent) cat(green("directorymethoddone$read.this.data completed\n"))
      return(output)
    },

    read.counter.directory = function(name.method){ #function to read out the counterprep of the donemethod object
      Foldernumber <- private$allmethods[[name.method]]$get.counterpreps()
      if(Foldernumber >= 100){warning("Foldernumber is bigger or equal than 100, so the numeration of the folders is not beautiful anymore.")}
      if(Foldernumber < 10){return(paste0("0",as.character(Foldernumber)))}else{return(as.character(Foldernumber))}
      return(Foldernumber)
    },

    names.donemethods = function(){ #function to give back all names of the performed methodmethods saved in allmethods
      output <- names(private$allmethods)
      return(output)
    }

  ),

  private = list(
    counterpreps = NULL, #counter for all methodmethods, that were done
    allmethods = list() #list for all methoddone objects
  )

)

#class for objects of data.info
#this objects contain informations about the Unit, the number of repetitions of each datapoint and if the Y data were centered
data.info <- R6Class("data.info",
                      public = list(
                        initialize = function(centeredY, originalY, repetitions, UnitspecY, UnitspecX){ #generate a new object of this class and check if all inputs are correct
                          if(!is.logical(centeredY)){stop("centeredY has to be a logical value.")}
                          if(!is.logical(originalY)){stop("originalY has to be a logical value.")}
                          if(!is.character(UnitspecY)){stop("UnitspecY has to be a character")}
                          if(!is.character(UnitspecX)){stop("UnitspecX has to be a character")}
                          if(!is.null(repetitions)){
                            if(!is.numeric(repetitions) & (repetitions <= 1) & ((repetitions %% 1) != 0)){stop("repetitions has to be a whole number and greater than 1.\n If there are no Repetitions, don't set repetitions or set repetitions to NULL. ")}
                          }
                          private$centeredY <- centeredY
                          private$originalY <- originalY
                          private$repetitions <- repetitions
                          private$UnitspecY <- UnitspecY
                          private$UnitspecX <- UnitspecX
                        },

                        read.centeredY = function(){ #read, if Y was centered, returns the boolean
                          return(private$centeredY)
                        },


                        change.centeredY = function(X){ #change centeredY if necessary, happens in centerY() function
                          if(!is.logical(X)){stop("X has to be logical")}
                          private$centeredY <- X
                        },

                        read.originalY = function(){ #read, if Y was centered, returns the boolean
                          return(private$originalY)
                        },


                        change.originalY = function(X){ #change centeredY if necessary, happens in centerY() function
                          if(!is.logical(X)){stop("X has to be logical")}
                          private$originalY <- X
                        },

                        read.repetitions = function(){ #give back the number of repetitions in the dataset
                          return(private$repetitions)
                        },

                        change.repetitions = function(repetitions){ #function, to change the number of repetitions
                          private$repetitions <- repetitions
                        },

                        check.UnitspecY = function(UnitspecY){ #check if the unit of the dataset is the same, like the unit passed as parameter
                          if(UnitspecY == private$UnitspecY){return(TRUE)}else{return(FALSE)}
                        },

                        read.UnitspecY = function(){ #give back the Unit of Y
                          return(private$UnitspecY)
                        },

                        change.UnitspecY = function(UnitspecY){ #change the Unit to a new unit passed as parameter
                          if(!is.character(UnitspecY)){stop("UnitspecY has to be a character")}
                          private$UnitspecY <- UnitspecY
                        },

                        check.UnitspecX = function(UnitspecX){ #check if the unit of the dataset is the same, like the unit passed as parameter
                          if(UnitspecX == private$UnitspecX){return(TRUE)}else{return(FALSE)}
                        },

                        read.UnitspecX = function(){ #give back the Unit of X
                          return(private$UnitspecX)
                        },

                        change.UnitspecX = function(UnitspecX){ #change the Unit to a new unit passed as parameter
                          if(!is.character(UnitspecX)){stop("UnitspecX has to be a character")}
                          private$UnitspecX <- UnitspecX
                        }



                      ),

                      private = list(
                        centeredY = FALSE, #boolean, whether Y was centered in dataprep.plsr() or not
                        originalY = TRUE, #boolean, whether the original Y-values should be used for the evaluation or not
                        repetitions = NULL, #the number of replicates of each datapoint
                        UnitspecY = "", #Unit of the Y data
                        UnitspecX = "" #Unit of the X data

                      )

)
