
#internal function, calculate the smoothed spectrum of on spectrum --> apply for dataset
smo.spect.mean <- function(spect, degreeofsmoothing){
  smo.spect <- rep(NA,length(spect)) #create an empty vector of the size of one spectrum
  for(i in 1:length(spect)){
    #the first or the last values, that can´t be smoothed, doesn´t change and go on with the next values
    if((i <= (degreeofsmoothing %/% 2)) | (i > (length(spect) - (degreeofsmoothing %/% 2)))){# %/% => dividing without a rest, these values can´t be changed
      smo.spect[i] <- spect[i] #take over the value from spect
      next #go on with the next value
    }
    up.val <- i + (degreeofsmoothing %/% 2) #define upper border of the averaged area
    low.val <- i - (degreeofsmoothing %/% 2) #define lower border of the averaged area
    partofspec <- spect[low.val:up.val] #define the part of the spectrum, that is going to be averaged
    smo.spect[i] <- mean(partofspec) #calculate the average of the part of the spectrum and save it at the right place of the new smoothed spectrum
  }
  return(smo.spect) #return the smoothed spectrum
  }



#function to smooth a spectrum by calculating the mean of a part of the spectrum
smoothspectrums.mean <- function(data, #parameter to pass a complete dataset prepared with fread.dataprep.plsr()
                                 degreeofsmoothing = 3, #parameter, that describes how many values are going to be averaged to claculate the datapoint of the spectrum, has to be an odd integer equal or bigger than 3
                                 printplots.TF = FALSE, #boolean to decide, whether the spectrum is going to be printed or not
                                 savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                                 ...){
  cat(silver("smoothspectrums.mean started\n"))

  check.data(data = data) #function to check, if there was passed a dataset

  #function to test, whether degreeofsmoothing is an odd integer equal or bigger than 3
  if(false.degreeofsmoothing(degreeofsmoothing)){stop("The degreeofsmothing has to be an odd integer equal or greater than 3!")}
  input <- data$prepdata$X
  wavelengths <- data$wavelengths

  if(printplots.TF){ #print all original spectrums, if boolean is TRUE
    printplot.allspectrums(X = wavelengths, Y = input, name = "original spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY())
  }

  # call the function smo.spect.mean with the apply function for every single spectrum and save it as output
  # attention: output of the apply function was transposed, because apply function transposed it. I don´t know why.
  output.t <- apply(X = input, MARGIN = 1, FUN = smo.spect.mean, degreeofsmoothing = degreeofsmoothing)
  output <- t(output.t)
  if(printplots.TF){ #print all smoothed spectrums, if boolean is TRUE
    printplot.allspectrums(X = wavelengths, Y = output, name = "smoothed spectra")
  }

  # if data was passed with data, return a complete dataset, where prepdat$X was changed to the smoothed spectra
  # in addition save the original and the smoothed spectra
  dimnames(output) <- dimnames(input) #change the names from output to the right names


  if(savedata.TF){ #save all data to the directorymethoddoneobject
    infos <- list(degreeofsmoothing = degreeofsmoothing, model = 0, derivation = 0, useownfunction = FALSE, repeatfirstderivation = FALSE)
    savedata <- list(databefor = input, dataafter = output, wavelengthsbefor = wavelengths, wavelengthsafter = wavelengths, infos = infos)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data$directorymethoddone$methoddone(whichmethod = "smoothing.mean", data = savedata, data.info = data$data.info$clone(deep = TRUE))
  }
  data$prepdata$X <- output
  cat(green("smoothspectrums.mean completed\n"))
  return(data)

}




