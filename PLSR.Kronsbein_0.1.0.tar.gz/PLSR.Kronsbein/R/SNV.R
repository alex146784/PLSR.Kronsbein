#internal function to calculate the SNV corrected spectrum
SNV.single <- function(spectrum){
  spec.sd <- sd(spectrum)#calculate standard deviation
  spec.mean <- mean(spectrum) #calculate mean
  spec.SNV <- (spectrum-spec.mean)/spec.sd #calculate SNV corrected spectrum
  return(spec.SNV)
}

#function to calculate SNV corrected spectra of a dataset of spectra
SNV <- function(data, #pass dataset of fread.dataprep.plsr()
                printplots.TF = FALSE, #boolean to decide, whether the spectrum is going to be printed
                savedata.TF = TRUE, #only set false in predict function, to perform method to new data
                ...){
  cat(silver("SNV started\n"))

  check.data(data = data) #function to check, if there was passed a dataset

  wavelengths <- data$wavelengths
  spectrums.orig <- data$prepdata$X
  if(printplots.TF){printplot.allspectrums(X = wavelengths, Y = spectrums.orig, name = "original spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), silent = TRUE)} #print all original plots, if this option was choosen

  #call SNV.single function for each row of the dataset. apply.t used, because normal apply function will calculate the transposed matrix (bug)
  output <- apply.t(spectrums.orig, MARGIN = 1, FUN = SNV.single)


  if(printplots.TF){printplot.allspectrums(X = wavelengths, Y = output, name = "SNV corrected spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), silent = TRUE)} #print all edited plots, if this option was choosen

  if(savedata.TF){ #data will be saved always, except the function is performed in the predict function
    #save interesting data depending on the method
    savedata <- list(databefor = spectrums.orig, dataafter = output, wavelengths = wavelengths)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data$directorymethoddone$methoddone(whichmethod = "SNV", data = savedata, data.info = data$data.info$clone(deep = TRUE)) #save all savedata to directorymethoddone object
  }
  data$prepdata$X <- output #save edited spectra to dataset
  cat(green("SNV completed\n"))
  return(data)


}
