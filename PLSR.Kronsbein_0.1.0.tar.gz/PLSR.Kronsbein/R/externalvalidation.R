#function to perform a external validation
externalvalidation <- function(model = NULL, #model dataset of plsr.ex
                               testdata = NULL, #if there are no testdata in data, you can pass a matrix with testdata
                               Ytestdata = NULL, #if there are no testYdata in data, you can pass a matrix with Ydata
                               testdata.source = NULL, #if there are no testdata in data, you can pass the data via a csv file
                               Ytestdata.source = NULL, #if there are no testYdata in data, you can pass a matrix with Ydata.source
                               savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                               centeredY = model$data.info$read.centeredY(), #Y should be always centered (TRUE), only change if you know what you do
                               which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                               ...){
  cat(silver("externalvalidation started\n"))

  check.data(data = model, model = TRUE)
  originalY <- model$data.info$read.originalY()

  ncomp.pred <- 1:dim(model$model$coefficients)[3] #create a vector with all used components
  split.used <- is.null(testdata) & is.null(testdata.source) & is.null(Ytestdata) & is.null(Ytestdata.source) #test if there were data passed, then use these

  model.methodnames <- model$directorymethoddone$names.donemethods()

  if(split.used){
    if(sum(grepl("splitdata.exval", model.methodnames))==0){stop("please pass a testdataset wit testdata and Ytestdata or split the dataset into a train and test set with generate.split_and_splitdata.externalvalidation()")}
    n.splitdata.exval <- length(which(grepl("splitdata.exval", model.methodnames))) #use the last splitdata.exval
    data.split <- model$directorymethoddone$read.this.data(paste0("splitdata.exval", n.splitdata.exval)) #read the data of splitdata
    newdata <- data.split$data$test.X #read of splitdata the newdata for X
    newYdata <- as.matrix(data.split$data$test.orig.Y) #read of splitdata the newdata for Y
  }else{
    sourceormatrix(matrix = testdata, source = testdata.source) #test for errors
    sourceormatrix(matrix = Ytestdata, source = Ytestdata.source) #test for errors
    if(!is.null(testdata)){ #read data from a matrix or from a file
      newdata <- testdata
    }else{
      newdata <- as.matrix(fread.csv.trycatch(testdata.source))
    }
    if(!is.null(Ytestdata)){ #read Ytestdata from a matrix or from a file
      newYdata <- Ytestdata
    }else{
      newYdata <- as.matrix(fread.csv.trycatch(Ytestdata.source))
    }

    #check if everything is right with the data
    if(nrow(newdata) != nrow(newYdata)){stop("testdata and Ytestdata don't match")}
    n.dataprep.plsr <- length(which(grepl("dataprep.plsr", model.methodnames))) #use the last dataprep.plsr
    if(ncol(newdata) != ncol(model$directorymethoddone$read.this.data(paste0("dataprep.plsr", n.dataprep.plsr))$data$dataX)){stop("testdata has not the right number of variables for X")}
  }

  if(savedata.TF && (model$directorymethoddone$is.methoddone("reduce.calibrationrange"))){
    new.dataset <- list(prepdata = data.frame(Y = I(newYdata),X = I(newdata)), oriY = list(Y.values = newYdata))
    redcalrange.data <- model$directorymethoddone$read.this.data("reduce.calibrationrange1")
    new.dataset <- reduce.calibrationrange(data = new.dataset, newcalrange = redcalrange.data$data$newcalrange, Ycol = redcalrange.data$data$Ycol, savedata.TF = FALSE, centeredY = FALSE)
    newdata <- new.dataset$prepdata$X
    newYdata <- new.dataset$oriY$Y.values
  }

  #predict the Y values with the model and the new Xdata
  Ypred <- predict.ex(model = model, newdata = newdata, ncomp = ncomp.pred, centeredY = centeredY, which.n.method = which.n.method, savedata.TF = FALSE)



  # if(savedata.TF && (model$directorymethoddone$is.methoddone("calc.meanspectra"))){#correct newdata, if calc.meanspectra was used
  #   dataset.new <- list(prepdata = data.frame(X = I(newdata)))
  #   dataset.new <- calc.meanspectra(data = dataset.new, mean.n.spectra = model$directorymethoddone$read.this.data(paste0("calc.meanspectra", 1))$data$mean.n.spectra, repetitions = NULL, savedata.TF = FALSE, called.with.predict = TRUE)
  #   newdata <- dataset.new$prepdata$X
  # }

  newYdata <- checkandpeform.changes.Y(model = model, Ydata = newYdata, Ydata_transformation = TRUE, calc.meanspectra = TRUE)
  if(originalY){
    newYdata <- undo_corrections_Y(model = model, Ydata = newYdata)
  }

  if(ncol(newYdata) != dim(Ypred)[2] || nrow(newYdata) != dim(Ypred)[1]){stop("predicted and measured values don't fit together")}


  model$model$RMSEP.ex <- parameter.calc(meas = newYdata, pred = Ypred)


  if(savedata.TF){
    #save all important data to methoddone in directorymethoddone
    input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = model, whichfunc = "plsr.ex")
    savedata <- list(RMSEP.ex = model$model$RMSEP.ex, whichcomp = ncomp.pred, modelname = input.l$name.method, newdata = newdata, newYdata = newYdata, Ypred = Ypred)
    model$directorymethoddone <- model$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    model$directorymethoddone$methoddone(whichmethod = "externalvalidation", data = savedata, data.info = model$data.info$clone(deep = TRUE)) #save the data to a new methoddone object in directorymethoddone
  }

  cat(green("externalvalidation completed\n"))
  return(model)
}
