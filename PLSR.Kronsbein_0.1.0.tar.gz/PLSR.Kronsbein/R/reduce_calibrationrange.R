
reduce.calibrationrange <- function(data, #pass dataset of fread.dataprep.plsr()
                                    newcalrange = NULL, #vector of length two, to set the min and max of the calibrationrange
                                    Ycol = 1,#which Y.col should be used to define the calibrationrange
                                    whichY = NULL, #used in internal functions
                                    pred = FALSE, #used in internal functions
                                    centeredY = data$data.info$read.centeredY(), #Y should be always centered (TRUE), only change if you know what you do
                                    printplots.TF = FALSE, #boolean to decide, whether the spectrum is going to be printed
                                    savedata.TF = TRUE, #only set false in predict function, to perform method to new data
                                    ...){
  cat(silver("reduce.calibrationrange started\n"))
  check.data(data = data) #function to check, if there was passed a dataset

  #use this function only once
  if(savedata.TF && (data$directorymethoddone$is.methoddone("reduce.calibrationrange"))){
    stop("It is not allowed to use reduce.calibrationrange more than once")
  }

  if(!pred && (length(newcalrange) != 2)){stop("newcalrange has to be a vector of the length 2. First value is the lower limit for the Y-values, the second is the upper limit for the Y-values.")}

  if(printplots.TF){printplot.allspectrums(X = data$wavelengths, Y = data$prepdata$X, name = "original spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), silent = TRUE)} #print all original plots, if this option was choosen
  data.befor <- data
  if(is.null(whichY)){
    Y <- data$oriY$Y.values[,Ycol]
    upperY <- Y >= min(newcalrange)
    lowerY <- Y <= max(newcalrange)

    whichY <- as.logical(upperY * lowerY)
  }
  if(pred){
    newX <- data$prepdata$X[whichY,,drop = FALSE]
    data$prepdata <- data.frame(X = I(newX))
  }else{
    neworiY <- data$oriY$Y.values[whichY,,drop = FALSE]
    newX <- data$prepdata$X[whichY,,drop = FALSE]

    #center Y-values, to prevent mistakes in plsr function
    if(centeredY){
      newY.mean <- apply(neworiY, MARGIN = 2, FUN = mean) #calculate means of the Responseparameters
      newY <- apply.t(neworiY, MARGIN = 1, FUN = substract.spectrum, mean.spec = newY.mean)#misused function, y values are not spectra, but it works in the same way

      data$prepdata <- data.frame(Y = I(newY),X = I(newX))
      data$oriY$Y.values <- neworiY
      data$oriY$Y.mean <- newY.mean
    }else{
      newY <- neworiY
      data$prepdata <- data.frame(Y = I(newY),X = I(newX))
      data$oriY$Y.values <- neworiY
    }
  }


  if(printplots.TF){printplot.allspectrums(X = data$wavelengths, Y = data$prepdata$X, name = "choosen spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), silent = TRUE)} #print all edited plots, if this option was choosen


  if(savedata.TF){ #data will be saved always, except the function is performed in the predict function
    #save interesting data depending on the method
    savedata <- list(newcalrange = newcalrange, Ycol = Ycol, whichY = whichY, databefor = data.befor$prepdata$X, dataafter = data$prepdata$X, wavelengths = data$wavelengths, oriYbefor = data.befor$oriY$Y.values, oriYafter = data$oriY$Y.values)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data$directorymethoddone$methoddone(whichmethod = "reduce.calibrationrange", data = savedata, data.info = data$data.info$clone(deep = TRUE)) #save all savedata to directorymethoddone object
  }

  cat(green("reduce.calibrationrange completed\n"))
  return(data)

}
