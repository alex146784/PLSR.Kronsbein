#function to generate a list of vectors, which will be used in splitdata.externalvalidation.CARS
generate.split.CARS <- function(data = NULL, #datainput in CARS
                           trainvalues.ratio = 0.75, #the part of the values, which should be used for the training of the model
                           whichY = 1, #if there are more than one Y-value, then use that one, with this column number, to select train and test
                           ...){
  if(!(trainvalues.ratio >=0 | trainvalues.ratio <= 1)){stop("trainvalues.ratio has to be between 0 and 1")}
  #create a vector of the indizes, which values should be used to train the model
  split.vec <- createDataPartition(y = data$prepdata$Y[,whichY], p = trainvalues.ratio, list = FALSE)
  train <- rep(FALSE, nrow(data$prepdata$Y)) #the logical vector for training is first completly filled with FALSEs
  train[split.vec] <- TRUE#then set the values which were defined in split.vec to TRUE, so this values will be used for the training
  test <- !train #all values which were FALSE in train are TRUE in test, these are the test values
  output <- list(train = train, test = test) #output is a list with all important data
  return(output)
}

#function to split the data into train and test data for the externalvalidation in CARS
splitdata.externalvalidation.CARS <- function(data = NULL, split = NULL){
  #split the dataset with split$...
  data$test$X <- data$prepdata$X[split$test,]
  data$test$orig.Y <- data$oriY$Y.values[split$test,]
  #data$test$orig.Y.center <- data$prepdata$Y[split$test,]
  data$prepdata <- data$prepdata[split$train,]
  data$oriY$Y.values <- data$oriY$Y.values[split$train,]
  return(data)
}



# shortened function of externalvalidation for the CARS algorythm
externalvalidation.CARS <- function(data = NULL, #input data (model)
                                    add.data = NULL, #necessary additional data (for PLS prepared Dataset)
                                    left.variables, #current left variables
                                    centeredY, #was Y data centered? normally TRUE
                               ...){
  
  ncomp.pred <- 1:dim(data$coefficients)[3] #create a vector with all used components

  newdata <- add.data$test$X[,left.variables, drop = FALSE] #read of add.data the newdata for X
  newYdata <- as.matrix(add.data$test$orig.Y) #read of add.data the newdata for Y, as reference
  newYdata <- checkandpeform.changes.Y(model = list(prepdata = add.data), Ydata = newYdata)
  
  #predict the Y values with the model and the new Xdata
  Ypred <- predict(object = data, ncomp = ncomp.pred, newdata = newdata)
  
  # if Ypred are centered Data,then undo centering
  if(centeredY == TRUE){
   Ypred.cent <- Ypred 
    dim.Ypred <- dim(Ypred)
    output<- array(data = NA, dim = dim.Ypred)
    for(i3 in 1:dim.Ypred[3]){ #loop, if there more than one component passed with ncomp, number of loop depends on the number of components (ncomp = 7 -> 1 loop; ncomp = 1:7 -> 7 loops)
      for(i2 in 1:dim.Ypred[2]){
        #crazy construct with the goal to transform an array into a matrix
        #drop function doesn´t work, because so a vector will be created
        Ypred.i1 <- Ypred.cent[,i2,i3, drop = FALSE]
        Ypred.i1 <- as.matrix(Ypred.i1)
        
        #apply function, to add up the meanspectrum to the predicted centered Y-values
        Ypred[,i2,i3] <- apply(Ypred.i1, MARGIN = 1, FUN = add.spectrum, mean.spec = add.data$oriY$Y.mean[i2])
      }
    }
  }
  
  RMSEP.ex <- matrix(NA, nrow = dim(Ypred)[3], ncol = dim(Ypred)[2])#create an empty matrix with the right size
  #go through the rows and columns of the matrix and fill it with the the right RMSE values
  #the columns are the different Reponsevalues and the rows are the number of components
  for(i3 in 1:dim(Ypred)[3]){ #go through the components
    for(i2 in 1:dim(Ypred)[2]){ #go through the different Y-variables
      test1 <- newYdata[,i2]
      test2 <- Ypred[,i2,i3]
      RMSEP.ex[i3,i2] <- rmserr(test1,test2)$rmse
    }
  }
  
  return(RMSEP.ex)
}