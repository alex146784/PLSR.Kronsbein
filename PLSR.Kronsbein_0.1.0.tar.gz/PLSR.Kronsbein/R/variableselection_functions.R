
#save left.variables from a performed variable selection to use it later, without the long calculationtime
save.variableselection <- function(data, #dataset
                                    selectionalgorithm, #which one was used
                                    #"CARS" -> select variables through the lowest RMSEP (CARS)
                                    #"Procrustes" -> select variables through procrustes analysis
                                    #"PCA.procrustes" <- select variables through PCA and procrustes analysis
                                    which.n.method = NULL, #parameter which repetition of a function should be evaluated (integer)
                                    directory = NULL, #directory to safe the file
                                    filename = "selectedvariables.RData", #name of the file
                                    ...){
  cat(silver("save.variableselection started\n"))
  check.data(data = data) #function to know if the dataset is correct

  #prevent errors no valid selectionalgorithm
  if(selectionalgorithm != "CARS" && selectionalgorithm != "Procrustes" && selectionalgorithm != "PCA.procrustes"){
    stop("no valid selectionalgorithm choosen. Use \"CARS\", \"Procrustes\" or \"PCA.procrustes\" ")
  }
  if(!((data$directorymethoddone$is.methoddone(selectionalgorithm)))){
    stop("it is necessary to perform the variableselection befor this function, make sure to select the right one")
  }

  #read necessary data
  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = selectionalgorithm)#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  if(!is.null(directory)){#if directory was specified, else it is going to be saved to the current working directory
    actwd <- getwd() # save the current directory
    if(!dir.exists(directory)){ #check if directory exists
      suppressWarnings(dir.create(directory))
    }
    setwd(directory) #if yes set working directory to directory
  }

  if(!grepl(".RData", filename)){ #check if the end of the name is .RData, if not add it
    filename <- paste0(filename, ".RData")
  }

  data.variableselection <- list(left.variables = input.l$data$left.variables, history = input.l$data$history, direction = input.l$data$add.infos$direction, whichorigmethod = input.l$name.method)


  if(file.exists(filename)){#test if fiel already exists and print an error
    if(!is.null(directory)){#go back to original working directory
      setwd(actwd)
    }
    stop("A file with this filename already exists!")
    }

  save(data.variableselection, file = filename) #use save() function to save data



  if(!is.null(directory)){#go back to original working directory
    setwd(actwd)
  }
  cat(green("save.variableselection completed\n"))
}


#function to load a performed variable selection and select variables with the old left.variables vector
load.variableselection <- function(data, #dataset
                                   newNumberofchangedVariables = NULL,
                                   directory = NULL, #directory to load the file
                                   filename = "selectedvariables.RData", #name of the file
                                   savedata.TF = TRUE, #always save date, except predict function
                                   ...){
  cat(silver("load.variableselection started\n"))
  check.data(data = data) #function to know if the dataset is correct

  data.input <- data #save input data

  if(!grepl(".RData", filename)){ #check if the end of the name is .RData, if not add it
    filename <- paste0(filename, ".RData")
  }

  if(!is.null(directory)){#if directory was specified, else it is going be loaded to the current working directory
    actwd <- getwd() # save the current directory
    if(!dir.exists(directory)){ #check if directory exists
      stop("the specified directory doesn't exist")
    }
    setwd(directory) #if yes set working directory to directory
  }

  if(!file.exists(filename)){stop("specified file doesn't exists")} #test if fiel already exists and print an error


  load(file = filename, envir = environment()) #use loadfunction to load the dataset, save the dataset to the global environment

  #check if X.values and leftvariables match
  if(ncol(data$prepdata$X) != length(data.variableselection$left.variables)){stop("the dataset and left.variables don't match")}


  if(!is.null(newNumberofchangedVariables)){
    if(newNumberofchangedVariables != 0){all.change.variables <- data.variableselection$history[1:newNumberofchangedVariables,3]}

    if(data.variableselection$direction == "forwards"){ #depending on the direction, create left variables only with TRUEs (backwards) or FALSEs (forwards) and then change all, that should be deleted or added
      left.variables <- rep(FALSE,ncol(data$prepdata$X))
      if(newNumberofchangedVariables != 0){left.variables[all.change.variables] <- TRUE}
    }else{
      left.variables <- rep(TRUE,ncol(data$prepdata$X))
      if(newNumberofchangedVariables != 0){left.variables[all.change.variables] <- FALSE}
    }
  }else{
    left.variables <- data.variableselection$left.variables
    }

  data <- cut.left.variables(data = data, left.variables = left.variables, savedata.TF = FALSE)#performs cuts, specified in the file and save it to directorymethoddone

  if(!is.null(directory)){#go back to original working directory
    setwd(actwd)
  }

  if(savedata.TF){
    savedata <- list(databefor = data.input$prepdata$X, dataafter = data$prepdata$X, wavelengthsbefor = data.input$wavelengths , wavelengthsafter = data$wavelengths , left.variables = left.variables, data.variableselection = data.variableselection) #list of all information
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data$directorymethoddone$methoddone(whichmethod = "load.variableselection", data = savedata, data.info = data$data.info$clone(deep = TRUE)) #save the data to a new methoddone object in directorymethoddone
  }

  cat(green("load.variableselection completed\n"))
  return(data)

}

#internal function to perform plsr during variable selection
plsr.RMSEP.variableselection <- function(data, ncomp, validation, PLS.method, center = FALSE, scale = FALSE, centeredY, segments, left.variables = NULL){
  if(!is.null(left.variables)){
    data$prepdata$X <- data$prepdata$X[,left.variables, drop = FALSE]
  }else{
    left.variables <- rep(TRUE,ncol(data$prepdata$X))
  }

  if(is.null(ncomp) || ncomp >= ncol(data$prepdata$X)){ #do this if ncomp, was not set or it is not possible to calculate as much components
    if(validation == "ex"){ #do this for external validation
      plsr.gas.t <- plsr(Y ~ X, data = data$prepdata, validation = "none", method = PLS.method, center = center, scale = scale)
      RMSEP <- externalvalidation.CARS(data = plsr.gas.t, add.data = data, left.variables = left.variables, centeredY = centeredY)
    }else{ #do this for other validations
      if(validation == "CV"){
        plsr.gas.t <- plsr(Y ~ X, data = data$prepdata, validation = validation, method = PLS.method, center = center, scale = scale, segments =  segments) #plsr is the normal function to calculate a model of the package PLS
      }else{
        plsr.gas.t <- plsr(Y ~ X, data = data$prepdata, validation = validation, method = PLS.method, center = center, scale = scale)
      }
      RMSEP <- (plsr.gas.t$validation$PRESS/nrow(plsr.gas.t$model$X))^(0.5)
    }

  }else{ #do this to calculate a defined number of components
    if(validation == "ex"){ #do this for external validation
      plsr.gas.t <- plsr(Y ~ X, data = data$prepdata, validation = "none", method = PLS.method, center = center, scale = scale, ncomp = ncomp)
      RMSEP <- externalvalidation.CARS(data = plsr.gas.t, add.data = data, left.variables = left.variables, centeredY = centeredY)
    }else{ #do this for other validations
      if(validation == "CV"){
        plsr.gas.t <- plsr(Y ~ X, data = data$prepdata, validation = validation, method = PLS.method, center = center, scale = scale, ncomp = ncomp, segments =  segments) #plsr is the normal function to calculate a model of the package PLS
      }else{
        plsr.gas.t <- plsr(Y ~ X, data = data$prepdata, validation = validation, method = PLS.method, center = center, scale = scale, ncomp = ncomp)
      }
      RMSEP <- (plsr.gas.t$validation$PRESS/nrow(plsr.gas.t$model$X))^(0.5)
    }
  }

  return(RMSEP)
}

#own procrustes calculation internal function
procrustes.own <- function(A, B) {
  stopifnot(is.numeric(A), is.numeric(B))
  if (!is.matrix(A) || !is.matrix(B))
    stop("Arguments 'A' and 'B' must be numeric matrices.")
  if (any(dim(A) != dim(B)))
    stop("Matrices 'A' and 'B' must be of the same size.")


  Svd <- svd(t(B) %*% A)                       # singular value decomposition

  Q <- Svd$u %*% t(Svd$v) #calculate rotationmatrix
  P <- B %*% Q #rotatetd P Values

  R <- A - P; #difference Rotated B and A Matrix
  #r <- sqrt(Trace(t(R) %*% R))        # Frobenius norm: Norm(A - P)


  E <- (Trace(A %*%t(A))) - (((Trace(A %*% t(P)))^2)/(Trace(B %*%t(B)))) #procrustes distance
  GF <- 1 - (E/(Trace(A %*%t(A))))
  if(is.na(E)){E <- Inf}
  return(list(P = P, Q = Q, E = E, GF = GF))
}


#internal function to calculate Procrustes distance for all variables
procrustes.int <- function(test.change ,data, direc, left.variables.l){
  result <- matrix(NA, nrow = 1, ncol = 2) #create result matrix, to save the procrustes distance

  if(direc){ #do this if direction is forwards
    if(left.variables.l[test.change] == TRUE){return(result)} #break function, if this variable has already been added
    left.variables.l[test.change] <- TRUE #change this variable
    correction.test.change <-  test.change - sum(left.variables.l[1:test.change])
    A <- data$prepdata$X[,left.variables.l, drop = FALSE]
    B <- data$prepdata$X[,left.variables.l, drop = FALSE]
    B[,(test.change-correction.test.change)] <- 0
  }else{ #do this if direction is backwards
    if(left.variables.l[test.change] == FALSE){return(result)} #break function, if this variable has already been deleted
    correction.test.change <- test.change - sum(left.variables.l[1:test.change])
    A <- data$prepdata$X[,left.variables.l, drop = FALSE]
    B <- data$prepdata$X[,left.variables.l, drop = FALSE]
    B[,(test.change-correction.test.change)] <- 0
  }

  #perform procrustes with the X.values
  procrustes.result <- procrustes.own(A = A, B = B)
  result[1,1] <- procrustes.result$E
  result[1,2] <- procrustes.result$GF

  cat(yellow(paste0(test.change," "))) #print progress, don´t work with parApply
  return(result)
}

#internal function to calculate Procrustes distance for all variables
PCA.procrustes.int <- function(test.change ,data, direc, left.variables.l, scores.B, ncomp.PCA.PA, center = FALSE, scale = FALSE){
  result <- matrix(NA, nrow = 1, ncol = 2) #create result matrix, to save the procrustes distance


  if(direc){ #do this if direction is forwards
    if(left.variables.l[test.change] == TRUE){return(result)} #break function, if this variable has already been added
    left.variables.l[test.change] <- TRUE #change this variable
  }else{ #do this if direction is backwards
    if(left.variables.l[test.change] == FALSE){return(result)} #break function, if this variable has already been deleted
    left.variables.l[test.change] <- FALSE #change this variable
  }

  data$prepdata$X <- data$prepdata$X[,left.variables.l, drop = FALSE] #reduce dataset depending to left.variables


  prcomp.A <- prcomp(x = data$prepdata$X, center = center, scale. = scale)
  scores.A <- predict(prcomp.A)
  if(ncomp.PCA.PA > ncol(scores.A) || ncomp.PCA.PA > ncol(scores.B)){
    if(ncol(scores.A) <= ncol(scores.B)){ncomp.PCA.PA <- ncol(scores.A)}else{ncomp.PCA.PA <- ncol(scores.B)}
  }
  A <- scores.A[,1:ncomp.PCA.PA, drop = FALSE]
  B <- scores.B[,1:ncomp.PCA.PA, drop = FALSE]

  #perform procruste with the scores
  procrustes.result <- procrustes.own(A = A, B = B)
  result[1,1] <- procrustes.result$E
  result[1,2] <- procrustes.result$GF


  cat(yellow(paste0(test.change," "))) #print progress, don´t work with parApply
  return(result)
}

#internal function to calculate all RMSEP for every changed variable (deleted or added) with apply
PLSR.int <- function(test.change ,data, direc, left.variables.l, validation, PLS.method , center = FALSE , scale = FALSE, ncomp, centeredY, n.Y, segments ){
  result <- matrix(NA, nrow = 2, ncol = 1) #create result matrix, to save the minRMSEP and the right number of components
  if(direc){ #do this if direction is forwards
    if(left.variables.l[test.change] == TRUE){return(result)} #break function, if this variable has already been added
    left.variables.l[test.change] <- TRUE #change this variable
  }else{ #do this if direction is backwards
    if(left.variables.l[test.change] == FALSE){return(result)} #break function, if this variable has already been deleted
    left.variables.l[test.change] <- FALSE #change this variable
  }

  data$prepdata$X <- data$prepdata$X[,left.variables.l, drop = FALSE] #reduce dataset depending to left.variables
  if(is.null(ncomp) || ncomp >= ncol(data$prepdata$X)){ #do this if ncomp, was not set or it is not possible to calculate as much components
    if(validation == "ex"){ #do this for external validation
      plsr.gas <- plsr(Y ~ X, data = data$prepdata, validation = "none", method = PLS.method, center = center, scale = scale) #calculate pls model
      RMSEP.l <- externalvalidation.CARS(data = plsr.gas, add.data = data, left.variables = left.variables.l, centeredY = centeredY) #perform external validation
    }else{ #do this for all other kinds of validation
      if(validation == "CV"){
        plsr.gas <- plsr(Y ~ X, data = data$prepdata, validation = validation, method = PLS.method, center = center, scale = scale, segments =  segments) #calculate pls model
      }else{
        plsr.gas <- plsr(Y ~ X, data = data$prepdata, validation = validation, method = PLS.method, center = center, scale = scale) #calculate pls model
      }

      #calculate pls model
      RMSEP.l <- (plsr.gas$validation$PRESS/nrow(plsr.gas$model$X))^(0.5) #calculate RMSEP with the PRESS, calculated with plsr
    }

  }else{ #do this to calculate a defined number of components
    if(validation == "ex"){
      plsr.gas <- plsr(Y ~ X, data = data$prepdata, validation = "none", method = PLS.method, center = center, scale = scale, ncomp = ncomp) #calculate pls model
      RMSEP.l <- externalvalidation.CARS(data = plsr.gas, add.data = data, left.variables = left.variables.l, centeredY = centeredY) #perform external validation
    }else{
      if(validation == "CV"){
        plsr.gas <- plsr(Y ~ X, data = data$prepdata, validation = validation, method = PLS.method, center = center, scale = scale, segments =  segments, ncomp = ncomp) #calculate pls model
      }else{
        plsr.gas <- plsr(Y ~ X, data = data$prepdata, validation = validation, method = PLS.method, center = center, scale = scale, ncomp = ncomp) #calculate pls model
      }
      RMSEP.l <- (plsr.gas$validation$PRESS/nrow(plsr.gas$model$X))^(0.5) #calculate RMSEP with the PRESS, calculated with plsr
    }
  }

  if(n.Y == 1){ #if there is one Y.variable do this
    result[1,1] <- min(RMSEP.l) #mininal RMSEP of all components
    result[2,1] <- which.min(RMSEP.l) #the number of components with the minimal RMSEP
  }else{ #if there is more than one Y.variable do this
    result[1,1] <- min(apply(RMSEP.l, MARGIN = 2, sum)) #the same as with one Y.variable, except to sum up all RMSEP of one component, to observe all Y-variables
    result[2,1] <- which.min(apply(RMSEP.l, MARGIN = 2, sum))
  }


  cat(yellow(paste0(test.change," "))) #print progress, don´t work with parApply
  return(result)
}
