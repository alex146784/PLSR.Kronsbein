#general internal function to perform centerY(), scaleY(), standardizeY()
centerY_scaleY_standardizeY <- function(data, #pass dataset of fread.dataprep.plsr()
                                     method, #which method choosen, center, scale, standardize
                                     scales = NULL, #if scale choosen as method, pass here the the scales
                                     savedata.TF = TRUE, #only set false in predict function, to perform method to new data
                                     referencedata = NULL, #referencedata of initially centering/standardisation, to perform method in the same way in the predict function
                                     silent = FALSE, #if TRUE -> no outputs in the console
                                     ...){
  if(!silent) cat(silver("centerY_scaleY_standardizeY started\n"))

  check.data(data = data) #function to check, if there was passed a dataset

  spectrums.orig <- data$prepdata$Y#save Y-variables to this variable, because most of the code was copied (suboptimal)

  if(method == "centerY"){#make this if method is center
    if(savedata.TF){#prevent error with normal centeredY. (all Ydata were centered, because of the plsr function.)
      if(data$data.info$read.centeredY()){ #check if Y was centered regularly
        message("In dataprep.plsr centerY was TRUE, this changes were undone, to use the normal centerY function")
        data$data.info <- data$data.info$clone(deep = TRUE)
        data$data.info$change.centeredY(FALSE)
        data$prepdata$Y <- data$oriY$Y.values #undo centeredY to perform normal centerY(), the difference is, that all outputs will be centered
        spectrums.orig <- data$prepdata$Y
      }
    }

    if(is.null(referencedata)){#normal execution of center function
      spectrum.mean <- apply(spectrums.orig, MARGIN = 2, FUN = mean) #calculate the mean values. function apply replaces a loop through each column (MARGIN = 2)
      output <- apply.t(spectrums.orig, MARGIN = 1, FUN = substract.spectrum, mean.spec = spectrum.mean) #substract the meanspectrum of each spectrum to center the spectrum. apply.t is a corrected version of apply(MARGIN = 2)
    }else{#excecution for predict function. Mean spectrum of initial center function will be used
      output <- apply.t(spectrums.orig, MARGIN = 1, FUN = substract.spectrum, mean.spec = referencedata) #substract the meanspectrum of each spectrum to center the spectrum. apply.t is a corrected version of apply(MARGIN = 2)
    }

  }

  if(method == "scaleY"){ #make this if method is scale
    #no split for initial and predict function, because for predict, the same scale could be used
    if(is.null(scales)){stop("to scale a spectrum, the scales have to be passed")} #test if scale was passed
    output <- apply.t(spectrums.orig, MARGIN = 1, FUN = divide.spectrum, scale.spec = 1/scales) #divide spectrum through reference spectrum. apply.t is a corrected version of apply(MARGIN = 2)
  }

  if(method == "standardizeY"){ #make this if method is standardize
    if(savedata.TF){ #in the other case there is no directorymethoddone object
      if(savedata.TF && !(data$directorymethoddone$is.methoddone("centerY"))){ #give back a warning, if center function was not performed befor standardizing
        warning("It is useful to center the data first, befor to standardize them! Without centering it could cause errors!!!")
      }
    }
    if(is.null(referencedata)){#normal execution of standardize function
      spectrum.sd <- apply(spectrums.orig, MARGIN = 2, FUN = sd)# calculate standard deviation spectrum
      output <- apply.t(spectrums.orig, MARGIN = 1, FUN = divide.spectrum, scale.spec = spectrum.sd) #divide spectrum through reference spectrum. apply.t is a corrected version of apply(MARGIN = 2)
    }else{#excecution for predict function. Mean spectrum of initial center function will be used
      output <- apply.t(spectrums.orig, MARGIN = 1, FUN = divide.spectrum, scale.spec = referencedata) #divide spectrum through reference spectrum. apply.t is a corrected version of apply(MARGIN = 2)
    }
  }


  if(savedata.TF){ #data will be saved always, except the function is performed in the predict function
    #save interesting data depending on the method
    if(method == "centerY"){savedata <- list(databefor = spectrums.orig, dataafter = output, meanspectrum = spectrum.mean)}
    if(method == "scaleY"){savedata <- list(databefor = spectrums.orig, dataafter = output,  scales = scales)}
    if(method == "standardizeY"){savedata <- list(databefor = spectrums.orig, dataafter = output, sdspectrum = spectrum.sd)}
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data$directorymethoddone$methoddone(whichmethod = method, data = savedata) #save all savedata to directorymethoddone object
  }
  data$prepdata$Y <- output #save edited spectra to dataset
  if(!silent) cat(green("centerY_scaleY_standardizeY completed\n"))
  return(data)


}

centerY <- function(data, #pass dataset of fread.dataprep.plsr()
                   savedata.TF = TRUE, #only set false in predict function, to perform method to new data
                   referencedata = NULL, #referencedata of initially centering/standardisation, to perform method in the same way in the predict function
                   silent = FALSE, #if TRUE -> no outputs in the console
                   ...){
  output <- centerY_scaleY_standardizeY(data = data, method = "centerY", savedata.TF = savedata.TF, referencedata = referencedata, silent = silent)
  return(output)
}

scaleY <- function(data , #pass dataset of fread.dataprep.plsr()
                  scales = NULL, #vector with scales for the spectrum
                  savedata.TF = TRUE, #only set false in predict function, to perform method to new data
                  silent = FALSE, #if TRUE -> no outputs in the console
                  ...){
  output <- centerY_scaleY_standardizeY(data = data, scales = scales, method = "scaleY", savedata.TF = savedata.TF, silent = silent)
  return(output)
}

standardizeY <- function(data , #pass dataset of fread.dataprep.plsr()
                        savedata.TF = TRUE, #only set false in predict function, to perform method to new data
                        referencedata = NULL, #referencedata of initially centering/standardisation, to perform method in the same way in the predict function
                        silent = FALSE, #if TRUE -> no outputs in the console
                        ...){
  output <- centerY_scaleY_standardizeY(data = data, method = "standardizeY", savedata.TF = savedata.TF, referencedata = referencedata, silent = silent)
  return(output)
}
