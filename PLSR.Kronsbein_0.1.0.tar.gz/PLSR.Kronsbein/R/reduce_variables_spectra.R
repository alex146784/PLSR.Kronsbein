


reduce_variables_spectra <- function(data, #necessary dataset of dataprep.plsr()
                                     degreeofreduction = 2,#only every degreeofreduction-th variable will be left
                                     printplots.TF = FALSE, #plotted spectrums desired?
                                     savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                                     ...){
  cat(silver("reduce_variables_spectra started\n"))

  check.data(data = data) #function to check, if there was passed a dataset

  #check if smoothing functions were performed, if not then print a warning
  if(savedata.TF && !(data$directorymethoddone$is.methoddone("smoothing.mean")) && !(data$directorymethoddone$is.methoddone("smoothing.sg")) ){ #prevent not senseful cut of the spectra after a variableselektion
    warning("It is recommended first to smooth the spectra, befor to reduce the variables")
  }

  #copy important variables
  X.values <- data$prepdata$X
  wavelengths <- data$wavelengths

  if(printplots.TF){printplot.allspectrums(X = wavelengths, Y = X.values, name = "original spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), silent = TRUE)} #print all original plots, if this option was choosen

  left.variables <- rep(FALSE, degreeofreduction)#create a vector with FALSEs of the length of degreeofreduction
  mean.variable <- round(degreeofreduction/2) #use the middle variable
  left.variables[mean.variable] <- TRUE #the middle variable is TRUE, this will be the left variable

  left.variables <- rep(left.variables, ceiling(ncol(X.values)/degreeofreduction)) #repeat left.variables, so that it is as long or longer than the number of variables

  if(length(left.variables) != ncol(X.values)){ #if the length of left.varibles is different to the number of variables the shorten left.variables
    left.variables <- left.variables[1:ncol(X.values)]
  }

  new.X <- X.values[,left.variables] #select subset
  new.wl <- wavelengths[left.variables] #select subset


  if(printplots.TF){printplot.allspectrums(X = new.wl, Y = new.X, name = "spectra after variable reduction", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), silent = TRUE)} #print all edited plots, if this option was choosen

  if(savedata.TF){ #data will be saved always, except the function is performed in the predict function
    #save interesting data depending on the method
    savedata <- list(databefor = data$prepdata$X, dataafter = new.X, wavelengthsbefor = data$wavelengths, wavelengthsafter = new.wl, degreeofreduction = degreeofreduction, left.variables = left.variables)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data$directorymethoddone$methoddone(whichmethod = "reduce_variables_spectra", data = savedata, data.info = data$data.info$clone(deep = TRUE)) #save all savedata to directorymethoddone object
  }

  data$prepdata$X <- new.X
  data$wavelengths <- new.wl

  cat(green("reduce_variables_spectra completed\n"))
  return(data)
}
