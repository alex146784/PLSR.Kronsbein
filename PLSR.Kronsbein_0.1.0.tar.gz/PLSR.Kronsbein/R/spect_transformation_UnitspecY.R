
#internal function, to tranfer one value from Extinction to Transmission
E_to_T <- function(Ex){
  Tr <- 10^(-Ex)
  return(Tr)
}

#internal function, to tranfer one value from Transmission to Exctionction
T_to_E <- function(Tr){
  Ex <- -log10(Tr)
}




#internal function, to perform the change of UnitspecY
general_change_UnitspecY <- function(data = NULL, TtoE = FALSE, EtoT = FALSE, savedata.TF = TRUE, printplots.TF = FALSE){
  cat(silver("general_change_UnitspecY started\n"))
  
  check.data(data = data) #function to check, if there was passed a dataset
  
  input <- data$prepdata$X
  #print error
  if((TtoE&EtoT)|(!TtoE&!EtoT)){stop("One of TtoE or EtoT have to be TRUE, not both or none!")}#prevent error, that both directions are choosen
  
  #do this for transmission to extinction
  if(TtoE){
    if(!is.null(data)&savedata.TF){
      if(data$data.info$check.UnitspecY("Transmission")){
        data$data.info <- data$data.info$clone(deep = TRUE)
        data$data.info$change.UnitspecY("Extinction")
      }else{
        stop(paste0("To perform Transmission_to_Extinction() UnitspecY has to be \"Transmission\".\nCurrent UnitspecY is ",data$data.info$read.UnitspecY() ,". Set this parameter in fread.dataprep()."))
      }
    }
    output <- apply(X = input, MARGIN = 1:2, FUN = T_to_E ) #call apply function with T_to_E to make this transformation with every single value (MARGIN = 1:2)
    
  }
  
  #do this for extinction to transmission
  if(EtoT){
    if(!is.null(data)&savedata.TF){
      if(data$data.info$check.UnitspecY("Extinction")){
        data$data.info <- data$data.info$clone(deep = TRUE)
        data$data.info$change.UnitspecY("Transmission")
      }else{
        stop(paste0("To perform Extinction_to_Transmission() UnitspecY has to be \"Extinction\".\nCurrent UnitspecY is ",data$data.info$read.UnitspecY() ,". Set this parameter in fread.dataprep()."))
      }
    }
    output <- apply(X = input, MARGIN = 1:2, FUN = E_to_T ) #call apply function with E_to_T to make this transformation with every single value (MARGIN = 1:2)
  }
  if(is.null(data)){ #if input was Matrixdata return the tranferred matrix
    cat(green("general_change_UnitspecY completed\n"))
    return(output)
    }
  
  #if input was data, then return complette dataset with original values and transferred values
  #$prepdata is going be changed
  if(printplots.TF){
    if(TtoE){
      printplot.allspectrums(X = data$wavelengths, Y = input, name = "Spectra Transmission", xlab = data$data.info$read.UnitspecX(), ylab = "Transmission", type = "l")
      printplot.allspectrums(X = data$wavelengths, Y = output, name = "Spectra Extinction", xlab = data$data.info$read.UnitspecX(), ylab = "Extinction", type = "l")
    }
    if(EtoT){
      printplot.allspectrums(X = data$wavelengths, Y = input, name = "Spectra Extinction", xlab = data$data.info$read.UnitspecX(), ylab = "Extinction", type = "l")
      printplot.allspectrums(X = data$wavelengths, Y = output, name = "Spectra Transmission", xlab = data$data.info$read.UnitspecX(), ylab = "Transmission", type = "l")
    }
  }
  if(savedata.TF){
    savedata <- list(databefor = input, dataafter = output, wavelengths = data$wavelengths)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object activ is necessary
  }
  if(TtoE){ #save data to the rigth directorymethoddone
    if(savedata.TF){data$directorymethoddone$methoddone(whichmethod = "Transmission_to_Extinction", data = savedata, data.info = data$data.info$clone(deep = TRUE))}
    data$prepdata$X <- output
  }
  if(EtoT){ #save data to the rigth directorymethoddone
    if(savedata.TF){data$directorymethoddone$methoddone(whichmethod = "Extinction_to_Transmission", data = savedata, data.info = data$data.info$clone(deep = TRUE))}
    data$prepdata$X <- output
  }
  cat(green("general_change_UnitspecY completed\n"))
  return(data)
}

#function to call tranfer from Transmission to Extinction
#function is going to call general_change_UnitspecY
Transmission_to_Extinction <- function(data, savedata.TF = TRUE, printplots.TF = FALSE){
  cat(silver("Transmission_to_Extinction started\n"))
  result <- (general_change_UnitspecY(data = data,  TtoE = TRUE, savedata.TF = savedata.TF, printplots.TF = printplots.TF))
  cat(green("Transmission_to_Extinction completed\n"))
  return(result)
}

#function to call tranfer from Extinction to Transmission
#function is going to call general_change_UnitspecY
Extinction_to_Transmission <- function(data, savedata.TF = TRUE, printplots.TF = FALSE){
  cat(silver("Extinction_to_Transmission started\n"))
  result <- (general_change_UnitspecY(data = data, EtoT = TRUE, savedata.TF = savedata.TF, printplots.TF = printplots.TF))
  cat(green("Extinction_to_Transmission completed\n"))
  return(result)
}


