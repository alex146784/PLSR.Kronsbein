#public function to smooth spectrums with the savitzky golay algorhythm
smoothspectrums.polynomial<- function(data, #parameter to pass a complete dataset prepared with fread.dataprep.plsr()
                                      degreeofsmoothing = 5, #parameter, that describes how many values are going to be averaged to claculate the datapoint of the spectrum, has to be an odd integer equal or bigger than 3
                                      model = 2, #pass the polynomial grad of the model
                                      printplots.TF = FALSE, #boolean to decide, whether the spectrum is going to be printed or not
                                      savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                                      ...){
  cat(silver("derivatespectrums started\n"))
  #call general function savitzkygolay-smoothing.derivation with the right parameters
  output <-savitzkygolay.smoothing.derivation(data = data,
                                    degreeofsmoothing = degreeofsmoothing,
                                    model = model,
                                    printplots.TF = printplots.TF,
                                    tolerancesolve = 0,
                                    derivation = 0,
                                    savedata.TF = savedata.TF
                                    )
  cat(green("derivatespectrums completed\n"))
  return(output)
}


derivatespectrums <- function(data, #parameter to pass a complete dataset prepared with fread.dataprep.plsr()
                              degreeofsmoothing = 5, #parameter, that describes how many values are going to be averaged to claculate the datapoint of the spectrum, has to be an odd integer equal or bigger than 3
                              model = 2, #pass the polynomial grad of the model
                              derivation = 1, #the grade of the derivation
                              repeatfirstderivation.TF = FALSE, #BSP 3.derivation: FALSE-> calculate 3.derivation; TRUE -> calculate three times the 1.derivation
                              printplots.TF = FALSE, #boolean to decide, whether the spectrum is going to be printed or not
                              savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                              ...){
  cat(silver("derivatespectrums started\n"))
  #call general function savitzkygolay-smoothing.derivation with the right parameters
  output <- savitzkygolay.smoothing.derivation(data = data,
                                      degreeofsmoothing = degreeofsmoothing,
                                      model = model,
                                      printplots.TF = printplots.TF,
                                      tolerancesolve = tolerancesolve,
                                      derivation = derivation,
                                      repeatfirstderivation.TF = repeatfirstderivation.TF,
                                      savedata.TF = savedata.TF)

  cat(green("derivatespectrums completed\n"))
  return(output)
}

#internal function, that is called for the polynomial smoothing or derivation functions
savitzkygolay.smoothing.derivation <- function(data, #parameter to pass a complete dataset prepared with fread.dataprep.plsr()
                                               degreeofsmoothing = 5, #parameter, that describes how many values are going to be averaged to claculate the datapoint of the spectrum, has to be an odd integer equal or bigger than 3
                                               model = 2, #pass the polynomial grad of the model
                                               derivation = 0, #the grade of the derivation
                                               printplots.TF = FALSE, #boolean to decide, whether the spectrum is going to be printed or not
                                               tolerancesolve = 0, #value to change the tolerance of the solve function
                                               repeatfirstderivation.TF = FALSE, #BSP 3.derivation: FALSE-> calculate 3.derivation; TRUE -> calculate three times the 1.derivation
                                               savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                                               ...){

  cat(silver("savitzkygolay.smoothing.derivation started\n"))

  check.data(data = data) #function to check, if there was passed a dataset

  #function to test, whether degreeofsmoothing is an odd integer equal or bigger than 3
  if(false.degreeofsmoothing(degreeofsmoothing)){stop("The degreeofsmothing has to be an odd integer equal or greater than 3!")}
  #function to test, whether model is an integer an equal or bigger than 0
  if(false.model(model)){stop("The model has to be an integer equal or bigger than 0!")}
  if(model >= degreeofsmoothing){stop("degreeofsmoothing has to be bigger than model, because degreeofsmoothing determine the basis for the regression!")}
  if(!repeatfirstderivation.TF & derivation >= model & derivation > 0){stop("model has to be bigger than derivation, because otherwise it isn´t useful to calculate the derivation!")}
  wavelengths <- data$wavelengths
  input <- data$prepdata$X


  if(printplots.TF){ #print all original spectrums, if boolean is TRUE
    printplot.allspectrums(X = wavelengths, Y = input, name = "original spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY())
  }

  # call the function smo.spect.polynomial with the apply function for every single spectrum and save it as output
  # attention: output of the apply function was transposed, because apply function transposed it. I don´t know why.
  if(repeatfirstderivation.TF){#possibilty to calculate higher derivation, through repeating the calculating of the first derivation
    repeatfirstderivation <- derivation #set number of loops for the 1. derivation
    input.l <- input #copy input to a local input variable
    for(i in 1:repeatfirstderivation){#loop for the derivation grade
      output <- savitzkyGolay(X = input.l, m = 1, p = model, w = degreeofsmoothing)
      input.l <- output #output of the previous loop is the the new local input
    }
    #because the svitzlyGolay function cuts off the values, were a smoothing is impossible, the wavelengthsvector has to be shortened--> indicators for the left values
    leftvalues <- (((degreeofsmoothing %/% 2)*repeatfirstderivation+1):(length(wavelengths) - (degreeofsmoothing %/% 2)*repeatfirstderivation))
  }else{#calculate normal the derivation
    output <- savitzkyGolay(X = input, m = derivation, p = model, w = degreeofsmoothing)
    #because the svitzlyGolay function cuts off the values, were a smoothing is impossible, the wavelengthsvector has to be shortened--> indicators for the left values
    leftvalues <- ((degreeofsmoothing %/% 2)+1):(length(wavelengths) - (degreeofsmoothing %/% 2))
  }

  wavelengths <- wavelengths[leftvalues]#shortening of wavelengths, depending on the choosen method and so the resulting left values
  if(printplots.TF){ #print all smoothed/derivated spectrums, if boolean is TRUE
    if(derivation == 0){
      printplot.allspectrums(X = wavelengths, Y = output, name = "smoothed spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY())
    }else{
      printplot.allspectrums(X = wavelengths, Y = output, name = "derivated spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY())
    }
  }
  names.out <- dimnames(input[,leftvalues])
  dimnames(output) <- names.out #change the names from output to the right names

  if(savedata.TF){
    infos <- list(degreeofsmoothing = degreeofsmoothing, model = model, derivation = derivation, repeatfirstderivation = repeatfirstderivation.TF)
    savedata <- list(databefor = input, dataafter = output, wavelengthsbefor = data$wavelengths, wavelengthsafter = wavelengths, infos = infos)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
  }


  # if data was passed with data, return a complete dataset, where prepdat$X was changed to the smoothed spectra
  # in addition save the original and the smoothed spectra
  if(derivation == 0){#save all produced data to data, depending on the method smoothed or derivated
    if(savedata.TF){
      #cloning happens above!
      data$directorymethoddone$methoddone(whichmethod = "smoothing.sg", data = savedata, data.info = data$data.info$clone(deep = TRUE))
    }
    data$prepdata$X <- output
    data$wavelengths <- wavelengths
  }else{
    if(savedata.TF){
      data$data.info <- data$data.info$clone(deep = TRUE)
      data$data.info$change.UnitspecY("derivated")
      #cloning happens above!
      data$directorymethoddone$methoddone(whichmethod = "derivation.sg", data = savedata, data.info = data$data.info$clone(deep = TRUE))
    }
    data$prepdata$X <- output
    data$wavelengths <- wavelengths
  }
  cat(green("savitzkygolay.smoothing.derivation completed\n"))
  return(data)

}




