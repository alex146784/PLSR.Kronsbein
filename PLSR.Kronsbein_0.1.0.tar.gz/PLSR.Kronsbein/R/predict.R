
#function to predict the response with a new spectrum.
#all dataprep, which was done to create the model, will be perform to the new data
predict.ex <- function(model, #created model with plsr.ex
                       ncomp = NULL, #which components should be used to predict the new repsonses
                       newdata = NULL, #spectra as a matrix, for which the prediction should be performed
                       newdata.source = NULL, #spectra as a csv file, for which the prediction should be performed
                       centeredY = model$data.info$read.centeredY(), #Y should be always centered (TRUE), only change if you know what you do
                       savedata.TF = TRUE, #savedata to directoryPLS.methoddone
                       which.n.method = NULL, #parameter which repetition of a function should be evaluated (integer)
                       ...){
  cat(silver("predict.ex started\n"))


  check.data(data = model, prepdata = FALSE, model = TRUE) #function to check, if there was passed a dataset. prepdata is not necessary but no problem if passed
  originalY <- model$data.info$read.originalY()

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = model, whichfunc = "plsr.ex")

  if(is.null(ncomp)){
    ncomp <- input.l$data$ncomp
  }
  if(max(ncomp) > input.l$data$ncomp){
    if(length(ncomp) > 1){
      delete.not <- (ncomp <= input.l$data$ncomp)
      ncomp <- ncomp[delete.not]
    }else{
      ncomp <- input.l$data$ncomp
    }

    warning(paste0("ncomp was to high, it was set to the max calculated number of components ", input.l$data$ncomp))
  }
  # give back errors if anything is not okay with the newdata
  if((!is.null(newdata)) && (!is.null(newdata.source))){stop("please pass data only via one option asa matrix vie newdata or as sourcefile via newdata.source")}
  if((!is.null(newdata)) && ((!is.matrix(newdata)) || (!is.numeric(newdata)))){stop("newdata has to be a numeric matrix")}
  if((!is.null(newdata.source)) && (!is.character(newdata.source))){stop("newdata.source has to be a character with the name of the source file")}



  model.methodnames <- input.l$data$directorymethoddone$names.donemethods() #read the names of all methods

  #use the original wavelengths of the model, befor any datapreperation was done
  wavelengths <- input.l$data$directorymethoddone$read.this.data(model.methodnames[1])$data$wavelengths

  if(is.null(newdata) && is.null(newdata.source)){
    newdata.l <- input.l$data$directorymethoddone$read.this.data(model.methodnames[1])$data$dataX
    cal.data.pred <- TRUE
  }else{
    if(!is.null(newdata.source)){newdata.l <- fread.csv.trycatch(rfile = newdata.source)} #if it was newdata.source, then read the data
    if(!is.null(newdata)){newdata.l <- newdata} #if it was newdata, copy the data
    cal.data.pred <- FALSE
  }

  #check if there are the same parameters(datapoints) in predict and train data
  check.col.oritraindata <- input.l$data$directorymethoddone$read.this.data(model.methodnames[1])$data$dataX
  if(ncol(newdata.l) != ncol(check.col.oritraindata)){stop("There must be the same number of columns (parameters) in the train and the predict data")}


  #create a similar dataconstruct, like created through fread.dataprep.plsr --> easier datapreperation with existing functions
  data <- list(prepdata = list(X = newdata.l),wavelengths = wavelengths)



  for(i in 1:length(model.methodnames)){#loop to go through all performed dataprep methods (which were performed befor the last call of plsr.ex())saved in the model and perform them on the new data
    data.methodmethod <- input.l$data$directorymethoddone$read.this.data(model.methodnames[i]) #read all saved information of the done dataprepmethod

    #following there are all dataprepmethods listed. If one of them is equal to name of the already performed dataprepmethod, then perform this method and go to the next method in the list (model.dataprepnames)

    if(grepl("dataprep.plsr", model.methodnames[i])){
      next()
      #nothing happens
    }

    if(grepl("PCA.calc", model.methodnames[i])){
      next()
      #nothing happens
    }

    if(grepl("plsr.ex", model.methodnames[i])){
      next()
      #nothing happens
    }

    if(grepl("validation", model.methodnames[i])){ #all validationmethods are unimportant for the predict function
      next()
      #nothing happens
    }


    if(grepl("splitdata.exval", model.methodnames[i])){
      next()
      #nothing happens
    }



    if(grepl("Transmission_to_Extinction", model.methodnames[i])){
      data <- Transmission_to_Extinction(data = data, savedata.TF = FALSE)
      next()
    }

    if(grepl("Extinction_to_Transmission", model.methodnames[i])){
      data <- Extinction_to_Transmission(data = data, savedata.TF = FALSE)
      next()
    }

    if(grepl("Wavenumber_to_Wavelength", model.methodnames[i])){
      data <- Wavenumber_to_Wavelength(data = data, savedata.TF = FALSE)
      next()
    }

    if(grepl("Wavelength_to_Wavenumber", model.methodnames[i])){
      data <- Wavelength_to_Wavenumber(data = data, savedata.TF = FALSE)
      next()
    }

    if(grepl("cutspectrum", model.methodnames[i])){
      #perform the cuts depending, how they was performed during the dataprep for the model
      allcuts <- data.methodmethod$data$allcuts
      #sort the cuts into two groups: wavelengths and numbers
      which.n <- allcuts[,3] == "n"
      which.w <- allcuts[,3] == "w"
      #use cutspectrum with right cuts, defined in allcuts with w or n
      if(sum(which.n)>0){
        cuts.n <- allcuts[which.n,1:2]
        mode(cuts.n) <- 'numeric'
        cuts.n <- as.matrix.byrow(cuts.n) #function to convert vector into matrix with one row, only do this if input is no matrix
        data <- cutspectrum(data = data, cuts.n = cuts.n, savedata.TF = FALSE)
      }
      if(sum(which.w)>0){
        cuts.w <- allcuts[which.w,1:2]
        mode(cuts.w) <- 'numeric'
        cuts.w <- as.matrix.byrow(cuts.w) #function to convert vector into matrix with one row, only do this if input is no matrix
        data <- cutspectrum(data = data, cuts.w = cuts.w, savedata.TF = FALSE)
      }
      next()
    }

    if(grepl("MSC", model.methodnames[i])){
      data <- msc.adapted(data = data, own.reference = data.methodmethod$data$referencespectrum ,savedata.TF = FALSE)
      next()
    }

    if(grepl("pbc", model.methodnames[i])){
      data <- polynomial_baseline_correction(data = data, model = data.methodmethod$data$model, threshold = data.methodmethod$data$threshold, multithread = data.methodmethod$data$multithread, savedata.TF = FALSE)
      next()
    }

    if(grepl("smoothing.mean", model.methodnames[i])){
      data <- smoothspectrums.mean(data = data, degreeofsmoothing = data.methodmethod$data$infos$degreeofsmoothing, savedata.TF = FALSE)
      next()
    }

    if(grepl("smoothing.sg", model.methodnames[i])){
      data <- smoothspectrums.polynomial(data = data, degreeofsmoothing = data.methodmethod$data$infos$degreeofsmoothing, model = data.methodmethod$data$infos$model, savedata.TF = FALSE)
      next()
    }

    if(grepl("derivation.sg", model.methodnames[i])){
      data <- derivatespectrums(data = data, degreeofsmoothing = data.methodmethod$data$infos$degreeofsmoothing, model = data.methodmethod$data$infos$model, derivation = data.methodmethod$data$infos$derivation, repeatfirstderivation.TF =  data.methodmethod$data$infos$repeatfirstderivation, savedata.TF = FALSE)
      next()
    }

    if(grepl("centerX", model.methodnames[i])){
      data <- centerX(data = data, referencedata = data.methodmethod$data$meanspectrum, savedata.TF = FALSE)
      next()
    }

    if(grepl("scaleX", model.methodnames[i])){
      data <- scaleX(data = data, scales = data.methodmethod$data$scales, savedata.TF = FALSE)
      next()
    }

    if(grepl("standardizeX", model.methodnames[i])){
      data <- standardizeX(data = data, referencedata = data.methodmethod$data$sdspectrum, savedata.TF = FALSE)
      next()
    }

    if(grepl("centerY", model.methodnames[i])){
      #data <- centerY(data = data, referencedata = data.methodmethod$data$meanspectrum, savedata.TF = FALSE)
      next()
    }

    if(grepl("scaleY", model.methodnames[i])){
      #data <- scaleY(data = data, scales = data.methodmethod$data$scales, savedata.TF = FALSE)
      next()
    }

    if(grepl("standardizeY", model.methodnames[i])){
      #data <- standardizeY(data = data, referencedata = data.methodmethod$data$meanspectrum, savedata.TF = FALSE)
      next()
    }

    if(grepl("SNV", model.methodnames[i])){
      data <- SNV(data = data, savedata.TF = FALSE)
      next()
    }

    if(grepl("CARS", model.methodnames[i])){
      data <- cut.left.variables(data = data, left.variables = data.methodmethod$data$left.variables, savedata.TF = FALSE)
      #cut.left.variables, because the left values was calculated befor with CARS. Only necessary to cut down the variables
      next()
    }

    if(grepl("Procrustes", model.methodnames[i])){
      data <- cut.left.variables(data = data, left.variables = data.methodmethod$data$left.variables, savedata.TF = FALSE)
      #cut.left.variables, because the left values was calculated befor with Procrustes. Only necessary to cut down the variables
      next()
    }

    if(grepl("PCA.procrustes", model.methodnames[i])){
      data <- cut.left.variables(data = data, left.variables = data.methodmethod$data$left.variables, savedata.TF = FALSE)
      #cut.left.variables, because the left values was calculated befor with "PCA.procrustes". Only necessary to cut down the variables
      next()
    }

    if(grepl("cut.left.variables", model.methodnames[i])){
      data <- cut.left.variables(data = data, left.variables = data.methodmethod$data$left.variables, savedata.TF = FALSE)
      #cut.left.variables, because the left values was calculated befor with CARS. Only necessary to cut down the variables
      next()
    }

    if(grepl("load.variableselection", model.methodnames[i])){
      data <- cut.left.variables(data = data, left.variables = data.methodmethod$data$left.variables, savedata.TF = FALSE)
      #cut.left.variables, because the left values was calculated befor with CARS. Only necessary to cut down the variables
      next()
    }

    if(grepl("reduce_variables_spectra", model.methodnames[i])){
      data <- reduce_variables_spectra(data = data, degreeofreduction = data.methodmethod$data$degreeofreduction, savedata.TF = FALSE)
      next()
    }

    if(grepl("calc.meanspectra", model.methodnames[i])){
      data <- calc.meanspectra(data = data, mean.n.spectra = data.methodmethod$data$mean.n.spectra, repetitions = NULL, savedata.TF = FALSE, called.with.predict = TRUE)
      next()
    }

    if(grepl("IIR.correction", model.methodnames[i])){
      data <- IIR.correction.pred(data = data, P.simple = data.methodmethod$data$P.simple, X.simple.mean = data.methodmethod$data$X.simple.mean)
      next()
    }

    if(grepl("Ydata_transformation", model.methodnames[i])){
      next()
    }

    if(grep("reduce.calibrationrange", model.methodnames[i]) && cal.data.pred){
      data <- reduce.calibrationrange(data = data, whichY = data.methodmethod$data$whichY, pred = TRUE, savedata.TF = FALSE, Ycol = data.methodmethod$data$Ycol)
      next()
    }

  }

  #use existing predict function to calculate the result
  if(input.l$data$kpls){
    output <- kpls.predict(model = input.l$data$model, which.comp = ncomp, newdata = data$prepdata$X)
  }else{
    output <- predict(object = input.l$data$model, ncomp = ncomp, newdata = data$prepdata$X)
  }


  #add dimnames to output
  name.3 <- rep("comp ", length(ncomp))
  name.3 <- paste0(name.3, ncomp)
  dim.names.output <- list("1" = rownames(data$prepdata$X), "2" = colnames(model$prepdata$Y), "3" = name.3)
  dimnames(output) <- dim.names.output


  #because Y was centered usually, this centering has to make undone
  if(centeredY == TRUE){
    output.interim <- output
    dim.output <- dim(output)
    output<- array(data = NA, dim = dim.output, dimnames = dimnames(output))
    for(i3 in 1:dim.output[3]){ #loop, if there more than one component passed with ncomp, number of loop depends on the number of components (ncomp = 7 -> 1 loop; ncomp = 1:7 -> 7 loops)
      for(i2 in 1:dim.output[2]){

        #crazy construct with the goal to transform an array into a matrix
        #drop function doesn´t work, because so a vector will be created
        output.i1 <- output.interim[,i2,i3, drop = FALSE]
        output.i1 <- as.matrix(output.i1)

        #apply function, to add up the mean to the predicted Y-values
        output[,i2,i3] <- apply(output.i1, MARGIN = 1, FUN = add.spectrum, mean.spec = input.l$data$oriY$Y.mean[i2])
      }
    }
  }

  if(originalY){#if originalY than calculate RMSEC for the original Y values
    output <- undo_corrections_Y(model = model, Ydata = output)
  }

  if(savedata.TF){
    model$predictions <- list(newdata = newdata, predictions = output)
    savedata <- list(modelname = input.l$name.method, ncomp = ncomp, newdata = newdata, predictions = output)
    model$directorymethoddone <- model$directorymethoddone$clone(deep = TRUE) #clone object activ is necessary
    model$directorymethoddone$methoddone(whichmethod = "prediction", data = savedata, data.info = model$data.info$clone(deep = TRUE))
    cat(green("predict.ex completed\n"))
    return(model)
  }
  cat(green("predict.ex completed\n"))
  return(output)
}


#function to perform done changes for new data, if a RMSE should be calculated
checkandpeform.changes.Y <- function(model, Ydata, Ydata_transformation = FALSE, calc.meanspectra = FALSE, splitdata.exval = FALSE){
  model.methodnames <- model$directorymethoddone$names.donemethods() #read the names of all methods
  if((sum((grepl("centerY", model.methodnames) + grepl("scaleY", model.methodnames) + grepl("standardizeY", model.methodnames) + (grepl("Ydata_transformation", model.methodnames)))))>0){
    #create a similar dataconstruct, like created through fread.dataprep.plsr --> easier datapreperation with existing functions
    data <- list(prepdata = data.frame(Y = I(Ydata),X = I(Ydata)), oriY = list(Y.values = Ydata))


    for(i in 1:length(model.methodnames)){#loop to go through all performed dataprep methods saved in the model and perform them on the new data
      data.methodmethod <- model$directorymethoddone$read.this.data(model.methodnames[i]) #read all saved information of the done dataprepmethod

      #following there are all dataprepmethods listed. If one of them is equal to name of the already performed dataprepmethod, then perform this method and go to the next method in the list (model.dataprepnames)

      if(grepl("centerY", model.methodnames[i])){
        data <- centerY(data = data, referencedata = data.methodmethod$data$meanspectrum, savedata.TF = FALSE, silent = TRUE)
        next()
      }

      if(grepl("scaleY", model.methodnames[i])){
        data <- scaleY(data = data, scales = data.methodmethod$data$scales, savedata.TF = FALSE, silent = TRUE)
        next()
      }

      if(grepl("standardizeY", model.methodnames[i])){
        data <- standardizeY(data = data, referencedata = data.methodmethod$data$sdspectrum, savedata.TF = FALSE, silent = TRUE)
        next()
      }

      if(Ydata_transformation && grepl("Ydata_transformation", model.methodnames[i])){
        data <- Ydata_transformation(data = data, transformationFUN = data.methodmethod$data$transformationFUN, whichYvalues = data.methodmethod$data$whichYvalues, centeredY = FALSE, othermean_for_centerY = data.methodmethod$data$data.centerY$newYdata.mean, savedata.TF = FALSE, silent = TRUE)
        next()
      }

      if(calc.meanspectra && grepl("calc.meanspectra", model.methodnames[i])){
        dataset.new <- list(prepdata = data.frame(X = I(Ydata)))
        dataset.new <- calc.meanspectra(data = dataset.new, mean.n.spectra = model$directorymethoddone$read.this.data(paste0("calc.meanspectra", 1))$data$mean.n.spectra, repetitions = NULL, savedata.TF = FALSE, called.with.predict = TRUE)
        Ydata <- dataset.new$prepdata$X
        data <- list(prepdata = data.frame(Y = I(Ydata),X = I(Ydata)), oriY = list(Y.values = Ydata))
        next()
      }

      if(splitdata.exval && grepl("splitdata.exval", model.methodnames[i])){
        data <- splitdata.externalvalidation(data = data, split = model$directorymethoddone$read.this.data(paste0("splitdata.exval", 1))$data$split, savedata.TF = FALSE)
      }



    }
    Ydata <- data$prepdata$Y

  }
  return(Ydata)


}
