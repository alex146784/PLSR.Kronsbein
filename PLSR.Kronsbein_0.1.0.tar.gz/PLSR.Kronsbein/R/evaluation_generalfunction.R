

evaluation <- function(data = NULL, # Dataset, which is necessary
                       last.of.this.method = NULL, #if only this method should be evaluated, specify it here
                       directory = NULL, # directory, where the data will be saved
                       projectname = NULL, #name of the project
                       decision.dir.exists = NULL, #decision whether existing data should be overwritten
                       which.comp = NULL, #which comp should be evaluated, default are all possible components; MAX 25 comp
                       save.dataset.TF = TRUE, #save the whole datset as .RData
                       ...){
  cat(silver("evaluation started\n"))

  check.data(data = data)

  #Check if data was passed
  if(is.null(data)){stop("Please add the data, which you recieved from the plsr.ex function")}


  if(data$directorymethoddone$is.methoddone("plsr.ex")){
    #Check if there is an indication which components should be choosen. If not then use all the components, which are available
    if (is.null(which.comp)){
      which.comp = 1:(dim(data$model$coefficients)[3])
    }
    if((length(which.comp))>25){#prevent later error, scatterplots of more than 25 components impossible
      stop("To much components choosen! Please choose at the maximum 25 components.")
    }
    if(max(which.comp) > max(dim(data$model$coefficients)[3])){
      which.comp <- 1:dim(data$model$coefficients)[3]
    }
  }

  if(data$directorymethoddone$is.methoddone("PCA.calc")){
    #Check if there is an indication which components should be choosen. If not then use all the components, which are available
    if (is.null(which.comp)){
      which.comp = 1
      warning("no which.comp used, so it was set to 1. It was not possible to extract which.comp out of a PLS model.")
    }
  }


  #Check if directory was passed
  if(is.null(directory)){
    message("no directory to save the files was specified!")
    directory <- readline(prompt = "Please write down name of the directory: ")
  }

  #Check if directory already exists, if not create it new and set directory as working directory
  #If directory already exists, it will be overwritten
  if(dir.exists(directory)){
    # if the directory already exists, ask if it should be overwritten
    if(is.null(decision.dir.exists)){ #look up, if there was done a decision in the call of function how to deal with the case of an existing directory
      message("Directory already exists! All existing data will be overwritten!")
      decision.dir.exists.user <- as.logical(as.numeric((readline(prompt = "Should existing directory be deleted? Type: 1 (Yes) or 0 (NO): "))))
      #ask user, if he will overwrite the existing data
      if(!(is.na(decision.dir.exists.user))) {decision.dir.exists <- decision.dir.exists.user}
      else {
        warning("no valid entry")
        decision.dir.exists <- FALSE
      }#check if decision is a valid entry, if not then it will handled as FALSE

    }

    if(!decision.dir.exists){stop("programm was stopped, directory will not be deleted")} # if decision is false stop the program, because data shouldn´t be overwritten
    unlink(directory, recursive = TRUE) # if decision is TRUE, then delete existing directory
    #dir.create(directory)
    #setwd(directory)
    warning("Directory already exists! All existing data was overwritten")
  }
  suppressWarnings(dir.create(directory))# create the new directory. The warning is suppressed, because it isn´t a problem if it is existing already (happens sometimes)
  setwd(directory)#change working directory

  infofile.eval(data = data, directory = directory, projectname = projectname, ...)

  #check if plsr.ex was performed and than call the corresponding function. If last.of.this.method was set do this only if it is the right method
  if(data$directorymethoddone$is.methoddone("plsr.ex") && (is.null(last.of.this.method) || last.of.this.method == "plsr.ex")){
    PLSR.eval(data = data, which.comp = which.comp, ...)
  }

  if(data$directorymethoddone$is.methoddone("PCA.calc") && (is.null(last.of.this.method) || last.of.this.method == "PCA.calc")){
    PCA.eval(data = data, which.comp = which.comp, ...)
  }

  if(data$directorymethoddone$is.methoddone("externalvalidation") && (is.null(last.of.this.method) || last.of.this.method == "externalvalidation")){
    externalvalidation.eval(data = data, which.comp = which.comp, ...)
  }#save all data of standardize

  if(data$directorymethoddone$is.methoddone("crossvalidation") && (is.null(last.of.this.method) || last.of.this.method == "crossvalidation")){
    crossvalidation.eval(data = data, which.comp = which.comp, ...)
  }#save all data of standardize

  if(data$directorymethoddone$is.methoddone("dataprep.plsr") && (is.null(last.of.this.method) || last.of.this.method == "dataprep.plsr")){
    dataprep.plsr.eval(data = data, ...)
  }#save all data of dataprep.plsr

  if(data$directorymethoddone$is.methoddone("splitdata.exval") && (is.null(last.of.this.method) || last.of.this.method == "splitdata.exval")){
    splitdata.exval.eval(data = data, ...)
  }#save all data of splitdata.externalvalidation

  if(data$directorymethoddone$is.methoddone("Transmission_to_Extinction") && (is.null(last.of.this.method) || last.of.this.method == "Transmission_to_Extinction")){
    EtoT_TtoE.eval(data = data, TtoE = TRUE, ...)
  }#save all data of Transmission_to_Extinction

  if(data$directorymethoddone$is.methoddone("Extinction_to_Transmission") && (is.null(last.of.this.method) || last.of.this.method == "Extinction_to_Transmission")){
    EtoT_TtoE.eval(data = data, EtoT = TRUE, ...)
  }#save all data of Extinction_to_Transmission

  if(data$directorymethoddone$is.methoddone("Wavenumber_to_Wavelength") && (is.null(last.of.this.method) || last.of.this.method == "Wavenumber_to_Wavelength")){
    wn_to_wl__wl_to_wn.eval(data = data, wn_to_wl = TRUE, ...)
  }#save all data of Wavenumber_to_Wavelength

  if(data$directorymethoddone$is.methoddone("Wavelength_to_Wavenumber") && (is.null(last.of.this.method) || last.of.this.method == "Wavelength_to_Wavenumber")){
    wn_to_wl__wl_to_wn.eval(data = data, wl_to_wn = TRUE, ...)
  }#save all data of Wavelength_to_Wavenumber

  if(data$directorymethoddone$is.methoddone("cutspectrum") && (is.null(last.of.this.method) || last.of.this.method == "cutspectrum")){
    cutspectrum.eval(data = data, ...)
  }#save all data of cutspectrum

  if(data$directorymethoddone$is.methoddone("MSC") && (is.null(last.of.this.method) || last.of.this.method == "MSC")){
    MSC.adapted.eval(data = data, ...)
  }#save all data of MSC

  if(data$directorymethoddone$is.methoddone("pbc") && (is.null(last.of.this.method) || last.of.this.method == "pbc")){
    pbc.eval(data = data, ...)
  }#save all data of pbc

  if(data$directorymethoddone$is.methoddone("smoothing.mean") && (is.null(last.of.this.method) || last.of.this.method == "smoothing.mean")){
    smoothing_derivation.eval(data = data, smoothing.mean = TRUE, ...)
  }#save all data of smoothing.mean

  if(data$directorymethoddone$is.methoddone("smoothing.sg") && (is.null(last.of.this.method) || last.of.this.method == "smoothing.sg")){
    smoothing_derivation.eval(data = data, smoothing.sg = TRUE, ...)
  }#save all data of smoothing.sg

  if(data$directorymethoddone$is.methoddone("derivation.sg") && (is.null(last.of.this.method) || last.of.this.method == "derivation.sg")){
    smoothing_derivation.eval(data = data, derivation.sg = TRUE, ...)
  }#save all data of derivation.sg

  if(data$directorymethoddone$is.methoddone("centerX") && (is.null(last.of.this.method) || last.of.this.method == "centerX")){
    centerX_scaleX_standardizeX.eval(data = data, center = TRUE, ...)
  }#save all data of centerX

  if(data$directorymethoddone$is.methoddone("scaleX") && (is.null(last.of.this.method) || last.of.this.method == "scaleX")){
    centerX_scaleX_standardizeX.eval(data = data, scale = TRUE,...)
  }#save all data of scaleX

  if(data$directorymethoddone$is.methoddone("standardizeX") && (is.null(last.of.this.method) || last.of.this.method == "standardizeX")){
    centerX_scaleX_standardizeX.eval(data = data, standardize = TRUE, ...)
  }#save all data of standardizeX

  if(data$directorymethoddone$is.methoddone("centerY") && (is.null(last.of.this.method) || last.of.this.method == "centerY")){
    centerY_scaleY_standardizeY.eval(data = data, center = TRUE, ...)
  }#save all data of centerY

  if(data$directorymethoddone$is.methoddone("scaleY") && (is.null(last.of.this.method) || last.of.this.method == "scaleY")){
    centerY_scaleY_standardizeY.eval(data = data, scale = TRUE,...)
  }#save all data of scaleY

  if(data$directorymethoddone$is.methoddone("standardizeY") && (is.null(last.of.this.method) || last.of.this.method == "standardizeY")){
    centerY_scaleY_standardizeY.eval(data = data, standardize = TRUE, ...)
  }#save all data of standardizeY

  if(data$directorymethoddone$is.methoddone("SNV") && (is.null(last.of.this.method) || last.of.this.method == "SNV")){
    SNV.eval(data = data, ...)
  }#save all data of SNV

  if(data$directorymethoddone$is.methoddone("CARS") && (is.null(last.of.this.method) || last.of.this.method == "CARS")){
    variableselection.eval(data = data ,whichfunc = "CARS", ...)
  }#save all data of CARS

  if(data$directorymethoddone$is.methoddone("Procrustes") && (is.null(last.of.this.method) || last.of.this.method == "Procrustes")){
    variableselection.eval(data = data, whichfunc = "Procrustes", ...)
  }

  if(data$directorymethoddone$is.methoddone("PCA.procrustes") && (is.null(last.of.this.method) || last.of.this.method == "PCA.procrustes")){
    variableselection.eval(data = data, whichfunc = "PCA.procrustes", ...)
  }

  if(data$directorymethoddone$is.methoddone("cut.left.variables") && (is.null(last.of.this.method) || last.of.this.method == "cut.left.variables")){
    cut.left.variables.eval(data = data, ...)
  }

  if(data$directorymethoddone$is.methoddone("load.variableselection") && (is.null(last.of.this.method) || last.of.this.method == "load.variableselection")){
    load.variableselection.eval(data = data, ...)
  }

  if(data$directorymethoddone$is.methoddone("reduce_variables_spectra") && (is.null(last.of.this.method) || last.of.this.method == "reduce_variables_spectra")){
    reduce_variables_spectra.eval(data = data, ...)
  }

  if(data$directorymethoddone$is.methoddone("prediction") && (is.null(last.of.this.method) || last.of.this.method == "prediction")){
    prediction.eval(data = data, ...)
  }

  if(data$directorymethoddone$is.methoddone("calc.meanspectra") && (is.null(last.of.this.method) || last.of.this.method == "calc.meanspectra")){
    calc.meanspectra.eval(data = data, ...)
  }

  if(data$directorymethoddone$is.methoddone("IIR.correction") && (is.null(last.of.this.method) || last.of.this.method == "IIR.correction")){
    IIR.correction.eval(data = data, ...)
  }

  if(data$directorymethoddone$is.methoddone("Ydata_transformation") && (is.null(last.of.this.method) || last.of.this.method == "Ydata_transformation")){
    Ydata_transformation.eval(data = data, ...)
  }

  if(data$directorymethoddone$is.methoddone("reduce.calibrationrange") && (is.null(last.of.this.method) || last.of.this.method == "reduce.calibrationrange")){
    reduce.calibrationrange.eval(data = data, ...)
  }

  if(save.dataset.TF){
    save.dataset(X = data)
  }


  setwd("..") #return to the main working directory
  cat(green("evaluation completed\n"))
}

#function, that creates an infofile with an overview what have been done
infofile.eval <- function(data, #necessary dataset
                          projectname = NULL, # name of the project/dataset for informationfile
                          directory = directory, #directory, where the data will be safed
                          ...){
  cat(silver("infofile.eval started\n"))
  if(is.null(projectname)){projectname <- directory} #if no projectname is given, then us
  sink("infofile.txt") # safe all in this file
  cat("Projectname is: ") #print this into the file
  print(projectname)
  cat("\n")
  cat("date ")
  print(format(Sys.time(), '%F %H:%M')) #this command prints the current time and date
  cat("\n\n")

  cat("List of all done methods:\n")
  names.donemethods <- data$directorymethoddone$names.donemethods()
  if(length(names.donemethods)>0){
    for(i in 1:length(names.donemethods)){
      cat(paste0("\t", i, ":\t", names.donemethods[i], "\n"))
    }
  }
  sink() #stop safing things to a file
  cat(green("infofile.eval completed\n"))
}


