



#expanded plsr function, where additional data is collected
plsr.ex <- function(data = NULL, #dataset for plsr, Important: create dataset with fread.dataprep.plsr function
                    validation = "none", #choose validation: none -> no validation; LOO -> leave on out validation; CV -> Cross Validation (leave on out with 10 samples at a time); ex -> external validation
                    ncomp = NULL, #number of components, which should be evaluated
                    model.calc = "simpls", #plsr algorythm: "simpls"; "nipals", "kernelpls", "widekernelpls" or PCR "PCR"
                    centeredY = data$data.info$read.centeredY(), #Y should be always centered (TRUE), only change if you know what you do
                    originalY = data$data.info$read.originalY(), #should be used for all evaluations the originalY values, for the model there will be used the preparated Yvalues
                    segments.CV = NULL, #define in how many segments the dataset should be splitted for CV, to pass a list is also possible (never tried), generate with cvsegments()
                    segments.type.CV = NULL, #defines the type, how to select the segments: "random", "consecutive", "interleaved"
                    repetitions = data$data.info$read.repetitions(), #the number of repetitions at one Datapoint
                    savedata.TF = TRUE, #should the data be safed to directorymethoddone. Always TRUE, only in predict function FALSE
                    ...) {
  cat(silver("plsr.ex started\n"))
  originalY <- data$data.info$read.originalY()
  if(validation == "ex"){#if the validationtype is external, set validation to none and set the boolean for externalvalidation TRUE
    validation <- "none"
    externalvalidation <- TRUE
  }else{
    externalvalidation <- FALSE
  }

  if(originalY && (validation == "CV" || validation == "LOO")){
    validation <- "none"
    crossvalidation <- TRUE
  }else{
    crossvalidation <- FALSE
  }

  if(!is.null(repetitions)){ #send warning, if the wants to use LOO and the user specified that there are repetitions in the dataset
    if (validation == "LOO" & (repetitions > 1)){warning("Leave one out validation is insufficient with repetitions in the dataset. Please use Cross Validation")}
  }
  #if validation method is Cross validation create the segments, like specified in generate.segments function
  if(validation == "CV"){segments <- generate.segments(data = data, segments.CV = segments.CV, segments.type.CV = segments.type.CV, repetitions = repetitions)}else{segments = NULL}

  if(model.calc == "nipals"){model.calc = "oscorespls"} #change name, because it´s the same

  max.ncomp <- calc.max.comp(data = data, validation = validation, segments = segments)
  if(is.null(ncomp)){ncomp <- max.ncomp}
  if(ncomp > max.ncomp){
    ncomp <- max.ncomp
    warning(paste0("The number of components (ncomp) was set to ", max.ncomp, " ,because it is not possible to calculate more components"))
  }
  # perform model claculation depending on Crossvalidation or not and PCR or PLSR
  if(validation == "CV"){
    if(model.calc == "PCR"){
      model.plsr <- pcr(Y ~ X, data = data$prepdata, validation = validation, ncomp = ncomp, center = FALSE, scale = FALSE, segments =  segments)
    }else{
      model.plsr <- plsr(Y ~ X, data = data$prepdata, validation = validation, method = model.calc, ncomp = ncomp, center = FALSE, scale = FALSE, segments =  segments)
    }
  }else{
    if(model.calc == "PCR"){
      model.plsr <- pcr(Y ~ X, data = data$prepdata, validation = validation, ncomp = ncomp, center = FALSE, scale = FALSE)
    }else{
      model.plsr <- plsr(Y ~ X, data = data$prepdata, validation = validation, method = model.calc, ncomp = ncomp, center = FALSE, scale = FALSE)
    }
  }

  # calculate different types of the explained variance and save them
  var <- model.plsr$Xvar
  part.var <- model.plsr$Xvar / model.plsr$Xtotvar
  part.cum.var <- rep(NA, length(part.var))
  for(i in 1:length(part.var)){
    part.cum.var[i] <- sum(part.var[1:i])
  }
  model.plsr$var <- var
  model.plsr$part.var <- part.var
  model.plsr$part.cum.var <- part.cum.var


  ###calculate RMSEC
  ncomp.pred <- 1:dim(model.plsr$coefficients)[3] #create a vector with all used components

  #calculate the predicted values for the RMSEC
  Y.pred.cent <- predict(object = model.plsr, ncomp = ncomp.pred, newdata = data$prepdata$X)#calculate predictet Y values with the generated model

  #because Y was centered usually, this centering has be undone
  if(centeredY == TRUE){
    dim.Ypred <- dim(Y.pred.cent)
    Ypred <- array(data = NA, dim = dim.Ypred)
    for(i3 in 1:dim.Ypred[3]){ #loop, if there more than one component passed with ncomp, number of loop depends on the number of components (ncomp = 7 -> 1 loop; ncomp = 1:7 -> 7 loops)
      for(i2 in 1:dim.Ypred[2]){

        #crazy construct with the goal to transform an array into a matrix
        #drop function doesn´t work, because so a vector will be created
        Ypred.i <- Y.pred.cent[,i2,i3, drop = FALSE]
        Ypred.i <- as.matrix(Ypred.i)

        #apply function, to add up the mean to the predicted Y-values

        Ypred[,i2,i3] <- apply(Ypred.i, MARGIN = 1, FUN = add.spectrum, mean.spec = data$oriY$Y.mean[i2])
      }
    }
  }else{
    Ypred <- Y.pred.cent #not necessary to correct values, because not centered
  }



  #RMSEC <- matrix(NA, nrow = dim(Ypred)[3], ncol = dim(Ypred)[2])#create an empty matrix with the right size
  #go through the rows and columns of the matrix and fill it with the the right RMSE values
  #the columns are the different Reponsevaluese and the rows are the number of components
  corr.ori.Yvalues <- checkandpeform.changes.Y(model = data, Ydata = data$oriY$Y.values)

  if(originalY){#if originalY than calculate RMSEC for the original Y values
    corr.ori.Yvalues <- undo_corrections_Y(model = data, Ydata = corr.ori.Yvalues)
    Ypred <- undo_corrections_Y(model = data, Ydata = Ypred)
  }

  # for(i3 in 1:dim(Ypred)[3]){
  #   for(i2 in 1:dim(Ypred)[2]){
  #     Y.measured <- corr.ori.Yvalues[,i2]
  #     Y.predicted <- Ypred[,i2,i3]
  #     RMSEC[i3,i2] <- rmserr(Y.measured,Y.predicted)$rmse
  #   }
  # }


  model.plsr$RMSEC <- parameter.calc(meas = corr.ori.Yvalues, pred = Ypred)


  data.output <- data
  data.output$model <- model.plsr



  if(savedata.TF){
    savedata <- list(kpls = FALSE, inputdata = data$prepdata, oriY = data$oriY, wavelengths = data$wavelengths, model = model.plsr, validation = validation, ncomp = ncomp, model.calc = model.calc, directorymethoddone = data.output$directorymethoddone$clone(deep = TRUE))
    data.output$directorymethoddone <- data.output$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data.output$directorymethoddone$methoddone(whichmethod = "plsr.ex", data = savedata, data.info = data.output$data.info$clone(deep = TRUE)) #save the data to a new methoddone object in directorymethoddone

  }

  #perform externalvalidation if required
  if(externalvalidation){
    data.output <- externalvalidation(model = data.output, savedata.TF = savedata.TF) #perform the external validation
  }

  if(validation == "CV" && savedata.TF){
    #save all important data to methoddone in directorymethoddone
    savedata <- list(own.CV = FALSE, segments.CV = segments.CV, segments.type.CV = segments.type.CV, repetitions = repetitions, segments = segments)
    data.output$directorymethoddone <- data.output$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data.output$directorymethoddone$methoddone(whichmethod = "crossvalidation", data = savedata, data.info = data$data.info$clone(deep = TRUE)) #save the data to a new methoddone object in directorymethoddone
  }

  cat(green("plsr.ex completed\n"))
  return(data.output)
}






