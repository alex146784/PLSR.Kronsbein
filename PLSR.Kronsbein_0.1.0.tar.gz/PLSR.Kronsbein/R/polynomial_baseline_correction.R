# calculation based on this Paper:
# title: Baseline correction by improved iterative polynomial fitting with automatic threshold
# autors: Feng Gan *, Guihua Ruan, Jinyuan Mo
# publisher: ELSEVIER



###internal function to calculate the baselines of a dataset of spectrums
pbc_algo <- function(Y.orig, #matrix of Intensities of the original spectums
                     X, #Vector of the values of the X-axis of the spectrums
                     model, #integer for the power of the used model: 0 -> Y-Intercept; 1 -> linear; 2 -> quadratic; and so on
                     threshold, #condition to stop the iteration, when baseline is good enough
                     tolerance = 1e-17, #varaible for solve function, don´t change, if you don´t know what you do
                     progress = FALSE, #show progress of the calculation, sometimes helpful for big calculations
                     multithread = FALSE, #use all cores of the computer, to perform the calculations (recommended for big datasets)
                     ...){
  cat(silver("pbc_algo started\n"))
  #Calculation of the X-Matrix
  X.matrix <- matrix(NA, nrow = length(X), ncol = (model+1)) #create an empty X-matrix
  for (i in 0:model){ #fill the X-matrix
    X.matrix[,(i+1)] <- X^i
  }
  # do greatest part of the calculation of b, to save computing time. Not necessary to to this iterativ
  interim.result.b <- X.matrix %*% (solve.try.catch((t(X.matrix) %*% X.matrix),tol = tolerance)) %*% t(X.matrix)

  baseline <- matrix(NA, nrow = nrow(Y.orig), ncol = ncol(Y.orig)) #create a empty matrix for the baseline
  if(multithread){
    Y.orig <- as.matrix(Y.orig)
    cores <- detectCores(logical = FALSE) #find out the number of threads the computer can handle
    cl <- makeCluster(cores) #create new instances of R, each instance of R uses one thread
    clusterExport(cl = cl,envir = environment(), varlist = c('Y.orig', 'threshold', 'pbc.apply', 'interim.result.b', 'length.vector.'))
    baseline <- parApply(cl = cl, X = Y.orig, MARGIN = 1, FUN = pbc.apply, threshold = threshold, interim.result.b = interim.result.b)
    stopCluster(cl) #close the additional no more necessary instances of R
    baseline <- t(baseline)
  }else{
    baseline <- matrix(NA, nrow = nrow(Y.orig), ncol = ncol(Y.orig)) #create a empty matrix for the baseline
    for(n.spec in 1:nrow(Y.orig)){ #loop to calculate the baseline of each spectrum
      #start of the algorhythm
      Y.matrix.old <- b.old <-  as.matrix(Y.orig[n.spec, ]) #Select one spectrum in each loop. This are the start values
      repeat{
        b.new <- interim.result.b %*% Y.matrix.old #calculation of b, greatest part of the calculation happened befor the loop to save computing time
        Y.bigger <- Y.matrix.old>b.new #compare the old Y matrix and the new b matrix and remember, if Y was bigger
        Y.matrix.new <- Y.bigger*b.new + (!Y.bigger)*Y.matrix.old #the values of the new Y-matrix are the smaller values of Y-matrix old and b.new

        p <- length.vector.(b.new - b.old)/length.vector.(b.old) #calculate p Values
        if(p <= threshold){break} #stop criterion

        b.old <- b.new # for the next iteration save the new b as old b
        Y.matrix.old <- Y.matrix.new # for the next iteration save the new Y.matrix as old Y.matrix
      }
      baseline[n.spec, ] <- Y.matrix.new #the final new Y-matrix of the algoryhtm is the baseline. save all baselines in a matrix
      if(progress){cat(green(paste("Spectrum Nr.", n.spec, " calculated\n",sep = "")))} #if progress was choosen as TRUE, the progress will be shown to see how many spectrums were calculated
    }
  }

  cat(green("pbc_algo completed\n"))
  return(baseline) #return the matrix with all baselines
}

#internal function for apply() in pbc.algo
pbc.apply <- function(Y.matrix.old, threshold, interim.result.b){
  Y.matrix.old <- as.matrix(Y.matrix.old)
  b.old <- Y.matrix.old
  repeat{
    b.new <- interim.result.b %*% Y.matrix.old #calculation of b, greatest part of the calculation happened befor the loop to save computing time
    Y.bigger <- Y.matrix.old > b.new #compare the old Y matrix and the new b matrix and remember, if Y was bigger
    Y.matrix.new <- Y.bigger*b.new + (!Y.bigger)*Y.matrix.old #the values of the new Y-matrix are the smaller values of Y-matrix old and b.new

    p <- length.vector.(b.new - b.old)/length.vector.(b.old) #calculate p Values
    if(p <= threshold){break} #stop criterion

    b.old <- b.new # for the next iteration save the new b as old b
    Y.matrix.old <- Y.matrix.new # for the next iteration save the new Y.matrix as old Y.matrix
  }
  return(Y.matrix.new) #the final new Y-matrix of the algoryhtm is the baseline. save all baselines in a matrix
}

###Function to calculate baseline corrected spectrums.
polynomial_baseline_correction <- function(data , #pass dataset of dataprep.plsr()
                                           model = 0, #choose the used model (possible values 0-10): 0 -> Y-Intercept; 1 -> linear; 2 -> quadratic; and so on
                                           threshold = 0.001, #parameter to choose the quality of the baselineadjustment. The lower the value, the better the adjustment and higher the computation time
                                           interactive = FALSE, #Activate this mode, to change the parameters model and threshold interactively
                                           savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                                           printplots.TF = FALSE, #plotted spectrums desired?
                                           multithread = FALSE, #use all cores of the computer, to perform the calculations (recommended for big datasets)
                                           ...){
  #Datapreperation
  cat(silver("polynomial_baseline_correction started\n"))

  check.data(data = data) #function to check, if there was passed a dataset

  X <- data$wavelengths #wavelengths are the Xdata of a spectrum
  Y.orig <- data$prepdata$X #Xdata of the PLSR are the Ydata of a spectrum

  #Send errors and warnings for possible scenarios to prevent mistakes
  if(false.model(model)){stop("The model has to be an integer equal or bigger than 0!")}

  #prevent the usage of other not senseful functions befor the usage of the polynomial baseline correction
  if(savedata.TF && (data$directorymethoddone$is.methoddone("centerX"))){
    stop("polynomial baselinecorrection is not senseful with centered spectra, don't use centerX() befor polynomial baseline correction")
  }
  if(savedata.TF && (data$directorymethoddone$is.methoddone("derivation.sg"))){
    stop("polynomial baselinecorrection is not senseful with derivated spectra, don't use derivatespectrums() befor polynomial baseline correction")
  }
  if(savedata.TF && ((data$directorymethoddone$is.methoddone("CARS")) || (data$directorymethoddone$is.methoddone("Procrustes")) || (data$directorymethoddone$is.methoddone("PCA.procrustes")) || (data$directorymethoddone$is.methoddone("cut.left.variables")))){
    stop("polynomial baselinecorrection is not senseful without the full spectrum, don't use variableselection() befor polynomial baseline correction")
  }
  #if(savedata.TF && (data$directorymethoddone$is.methoddone("cutspectrum"))){
  #  warning("polynomial baselinecorrection is often not senseful without the full spectrum, don't use cutspectrum() befor polynomial baseline correction")
  #}


  if(printplots.TF){ #print all original spectrums, if boolean is TRUE
    printplot.allspectrums(X = X, Y = Y.orig, name = "original", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY())
  }

  #loop for interactive mode, only one iteration will be performed, if iterative = FALSE
  repeat{  #do-while loop with conditional break command at the end of the loop
    #calculation of the baseline with the pbc_algo function. All necessary parameters passed
    baseline <- pbc_algo(Y.orig = Y.orig, X = X, model = model, threshold = threshold, multithread = multithread)

    #calculate baseline corrected spectrums by substrcting the baselines from the spctrums
    Y.corrected <- Y.orig - baseline

    #start interactive mode, if interactive = TRUE
    if(interactive){
      repeat{ #loop for menu
        #Output to inform user
        cat(yellow("\n\nInteractive mode has been choosen.\nBe patient for your cursor to be active in the console, not in the script!!!\n"))
        cat(blue("You have the possibility to change some varaibles of the polynomial baseline correction or to review the results of the last run.\n"))
        cat(blue("Press a number to choose an option and confirm with enter:\n"))
        cat(blue("\t0:\tStatisfied with polynomial baseline correction and close the interactive mode\n"))
        cat(blue("\t1:\tReview last results\n"))
        cat(blue("\t2:\tChange Variables\n"))
        menu <- readline(prompt = "Selection: ") #recieve decision of the user

        # go on depending on the decision of the user
        switch(menu,
               # close interactive mode -> set interactive to FALSE
               "0" = {interactive = FALSE
                      cat(yellow("\nInteractive mode closed.\n"))},

               # review the last results
               "1" = {#Output to inform user
                      cat(yellow("\nRewiew last results choosen.\n"))
                      cat(blue("What do you want to review?\n"))
                      cat(blue("\t1:\tAll original spectrums and the underground\n"))
                      cat(blue("\t2:\tAll underground corrected spectrums\n"))
                      cat(blue("\t3:\tOnly the first original spectrum and the underground\n"))
                      cat(blue("\t4:\tOnly the first underground corrected spectrum\n"))
                      menu1 <- readline((prompt = "Selection: "))#recieve decision of the user

                      # go on depending on the decision of the user
                      switch(menu1, # print spectrums in the way described in the output above
                             "1" = printplot.allspectrums(X= X, Y = (rbind(Y.orig, baseline)), xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), name = "original spectrum + baseline"),
                             "2" = printplot.allspectrums(X = X, Y = Y.corrected, xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), name = "corrected spectrum"),
                             "3" = printplot.allspectrums(X= X, Y = (rbind(Y.orig[1,,drop= FALSE], baseline[1,,drop= FALSE])), xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), name = "original spectrum + baseline"),
                             "4" = printplot.allspectrums(X = X, Y = Y.corrected[1,,drop= FALSE], xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), name = "corrected spectrum"),
                             cat(red("No valid selection! Please try again\n"))
                             )
                      },

               #change parameters of the calculation
               "2" = {#Output to inform user
                      cat(yellow("\nChange variables choosen.\n"))
                      repeat{
                        cat(blue("What do you want to change?\n"))
                        cat(blue("The shape of the baseline depends on the model.\n"))
                        cat(blue("The quality of the beasline depends on the threshold.\n"))
                        cat(blue("The smaller the threshold, the better the baseline, but be careful the computing time will increase also.\n"))
                        cat(blue("\t0:\tAll changes done\n"))
                        cat(blue("\t1:\tChange model\n"))
                        cat(blue("\t2:\tChange threshold\n"))

                        menu2 <- readline((prompt = "Selection: "))#recieve decision of the user
                        # go on depending on the decision of the user
                        switch(menu2, #change values in the way described in the output above
                               "0" = {cat(yellow("\nMenu change-variables closed\nModel will be recalculated with new parameters.\n"))},
                               "1" = {cat(yellow("\nChange model choosen\n"))
                                      repeat{ #loop to make sure that user input ist right
                                        input <-readline((prompt = "New value for model (possible values: 0-10): "))
                                        model <- suppressWarnings(try(as.numeric(input),silent = TRUE))
                                        if((!(is.na(model))) & (model>=0) & (model<=10)){break
                                        }else{
                                          cat(red("no valid value for model\n"))
                                        }
                                      }
                                      },
                               "2" = {cat(yellow("\nChange threshold choosen\n"))
                                       repeat{ #loop to make sure that user input ist right
                                         input <-readline((prompt = "New value for threshold: "))
                                         threshold <- suppressWarnings(try(as.numeric(input),silent = TRUE))
                                         if(!(is.na(threshold))){break
                                         }else{
                                           cat(red("no valid value for model\n"))
                                         }
                                       }
                                      },

                               cat(red("No valid selection! Please try again\n"))
                        )
                        if(menu2 == 0){break}
                     }
                     },
               cat(red("No valid selection! Please try again\n"))
               )
        if(menu == "0"|menu == "2"){break} #go on in case 0 and 2, not in 1 because maybe the user will see another plot or he will change values
      }
    }

    #condition to stop loop: interactive = FALSE
    #interactive is FALSE, if it was passed FALSE as a parameter of the function or the user stopped the interactive function, if baseline correction is good
    if(!interactive){break} #break condition of do-while loop
  }

  if(printplots.TF){ #print all original spectrums, if boolean is TRUE
    printplot.allspectrums(X = X, Y = Y.corrected, name = "pbc corrected", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY())
  }

  # return data, depending how the function was called
  if(savedata.TF){
    savedata <- list(databefor = Y.orig, dataafter = Y.corrected, wavelengths = X, baseline = baseline, model = model, threshold = threshold, multithread = multithread)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data$directorymethoddone$methoddone(whichmethod = "pbc", data = savedata, data.info = data$data.info$clone(deep = TRUE))
  }
  data$prepdata$X <- Y.corrected
  # save additional informations for evaluation function (not implemented yet)
  # data$pbc$Xorig.beforepbc <- Y.orig
  # data$pbc$baseline <- baseline
  # data$pbc$X.pbc <- Y.corrected
  cat(green("polynomial_baseline_correction completed\n"))
  return(data)
}

