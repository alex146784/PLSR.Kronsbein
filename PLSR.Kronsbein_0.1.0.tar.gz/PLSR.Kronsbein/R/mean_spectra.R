#function to calculate the averagespectrum of a specified number of spectra
calc.meanspectra <- function(data = NULL, #PLSR.Kronsbein Dataset
                             mean.n.spectra = NULL, #this number of spectra will be averaged
                             all.repetitions = FALSE, #Set this to TRUE, if all repeated spectra should be averaged, definde with repetitions
                             repetitions = data$data.info$read.repetitions(), #the number of repetitions at one Datapoint
                             savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function or other internal functions
                             printplots.TF = FALSE, #plotted spectrums desired?
                             called.with.predict = FALSE, #set TRUE if function was called for a prediction, if only the X-data are available
                             ...){
  cat(silver("calc.meanspectra started\n"))

  check.data(data = data) #function to check, if there was passed a dataset

  #use this function only once
  if(savedata.TF && (data$directorymethoddone$is.methoddone("calc.meanspectra"))){
    stop("It is not allowed to use calc.meanspectra more than once")
  }


  #check for errors
  if(all.repetitions){
    if(is.null(repetitions)){
      stop("There are no repetitions in the data")
    }
    if(!is.null(mean.n.spectra)){
      warning("n.spectra was passed and will not be used, because all.repetitions is TRUE")
    }
    mean.n.spectra <- repetitions
  }else{
    if(!is.null(repetitions)){
      if(is.null(mean.n.spectra)){stop("pass a number of spectra with mean.n.spectra or set all.repetitions to TRUE")}
      if((repetitions/mean.n.spectra)%%1 != 0){
        stop("it is not useful, if repetitions is not a multiple of mean.n.spectra")
      }
    }
  }
  if((nrow(data$prepdata$X)/mean.n.spectra)%%1 != 0){
    stop("The number of spectra in data is not dividable through mean.n.spectra")
  }

  if(printplots.TF){printplot.allspectrums(X = data$wavelengths, Y = data$prepdata$X, name = "original spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), silent = TRUE)} #print all original plots, if this option was choosen

  #extract important data of the dataset
  X.data <- data$prepdata$X
  if(!called.with.predict){#do this not, if called in the predict function
    Y.data <- data$prepdata$Y
    Y.data.ori <- data$oriY$Y.values
  }

  #create empty matrices for the averaged data
  new.X.data <- matrix(data = NA, nrow = (nrow(data$prepdata$X)/mean.n.spectra), ncol = ncol(data$prepdata$X))
  if(!called.with.predict){#do this not, if called in the predict function
    new.Y.data <- matrix(data = NA, nrow = (nrow(data$prepdata$Y)/mean.n.spectra), ncol = ncol(data$prepdata$Y))
    new.Y.data.ori <- matrix(data = NA, nrow = (nrow(data$oriY$Y.values)/mean.n.spectra), ncol = ncol(data$oriY$Y.values))
  }

  #calculate the average spectra and average Y-values
  for (i in 1:((nrow(data$prepdata$X)/mean.n.spectra))){#in each loop there will be calculated one average spectrum
    #calculate the indices the spectra, which should be averaged
    mean.from.spec <- 1+(i-1)*mean.n.spectra
    mean.to.spec <- i*mean.n.spectra

    #calculate the means with the apply function
    new.X.data[i,] <- apply(X = X.data[mean.from.spec:mean.to.spec,,drop = FALSE], MARGIN = 2, FUN = mean)
    if(!called.with.predict){#do this not, if called in the predict function
      new.Y.data[i,] <- apply(X = Y.data[mean.from.spec:mean.to.spec,,drop = FALSE], MARGIN = 2, FUN = mean)
      new.Y.data.ori[i,] <- apply(X = Y.data.ori[mean.from.spec:mean.to.spec,,drop = FALSE], MARGIN = 2, FUN = mean)
    }
  }

  #save data in the right dataformat
  if(!called.with.predict){#do this, if not called in the predict function
    data$prepdata <- data.frame(Y = I(new.Y.data),X = I(new.X.data))
    data$oriY$Y.values <- new.Y.data.ori
  }else{#do this, if called in the predict function
    data$prepdata <- data.frame(X = I(new.X.data))
  }

  #correct number of repetitions
  if(!is.null(repetitions) && !called.with.predict){
    new.repetitions <- repetitions/mean.n.spectra
    if(new.repetitions == 1){new.repetitions <- NULL}
    data$data.info$change.repetitions(new.repetitions)
  }

  if(printplots.TF){printplot.allspectrums(X = data$wavelengths, Y = data$prepdata$X, name = "calculated mean spectra", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), silent = TRUE)} #print all spectra after the calculation of the meanspectra, if this option was choosen

  #save all necessary data for the evaluation function
  if(savedata.TF){
    savedata <- list(databefor = X.data, dataafter = data$prepdata$X, Ydata.befor = Y.data, Ydata.after = data$prepdata$Y, wavelengths = data$wavelengths, oriY.befor = Y.data.ori, oriY.after = new.Y.data.ori, mean.n.spectra = mean.n.spectra, all.repetitions = all.repetitions, old.repetitions = repetitions, new.repetitions = new.repetitions)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object activ is necessary
    data$directorymethoddone$methoddone(whichmethod = "calc.meanspectra", data = savedata, data.info = data$data.info$clone(deep = TRUE))
  }

  cat(green("calc.meanspectra completed\n"))
  return(data)
}
