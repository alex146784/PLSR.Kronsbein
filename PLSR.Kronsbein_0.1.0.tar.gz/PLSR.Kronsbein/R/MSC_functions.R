
#function to perform the msc correction
msc.adapted <- function(data, #necessary dataset
                  printplots.TF = FALSE, #plotted spectrums desired?
                  savedata.TF = TRUE, #normaly TRUE, only FALSE, if function was called in predict function
                  own.reference = NULL, #normally passed by predictionfunction(), but if you don't want to use the meanspectrum as reference you cann pass your reference here
                  ...){
  cat(silver("msc.adapted started\n"))
  
  check.data(data = data) #function to check, if there was passed a dataset
  
  #copy the necessray data
  wavelengths <- data$wavelengths
  spectrums.orig <- data$prepdata$X
  
  if(savedata.TF && (data$directorymethoddone$is.methoddone("centerX"))){ #prevent error with centered spectra
    stop("msc is not possible with centered spectra, don't use centerX() befor msc.adapted(), calculation doesn't work with a mean spectrum of zeros")
  }
  
  if(is.null(own.reference)){ #normal case, own refernce will be passed normally only in predict function
    
    referencespectrum <- apply(spectrums.orig,MARGIN = 2, FUN = mean) #calculate the mean spectrum. function apply replaces a loop through each column (MARGIN = 2)
    
    spectrums.msc <- msc(spectrums.orig, reference = referencespectrum) #calculate msc corrected spectrums, as reference the mean spectrum is used
  }else{
    referencespectrum <- own.reference
    spectrums.msc <- msc(spectrums.orig, reference = referencespectrum) #calculate msc corrected spectrums, as reference the own reference is used
  }

  
  if(printplots.TF){
    printplot.allspectrums(X = wavelengths, Y = spectrums.orig, name = "original spectrums", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY()) #print all spectrums of the original dataset in one plot
    printplot.allspectrums(X = wavelengths, Y = spectrums.msc, name = "spectrums after msc", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY()) #print all spectrums of the msc-corrected dataset in one plot
  }
  if(savedata.TF){
    savedata <- list(databefor = spectrums.orig, dataafter = spectrums.msc, wavelengths = wavelengths, referencespectrum = referencespectrum)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object activ is necessary
    data$directorymethoddone$methoddone(whichmethod = "MSC.adapted", data = savedata, data.info = data$data.info$clone(deep = TRUE))
  }
  data$prepdata$X <- spectrums.msc #save msc-corrected dataset for further operations
  # data$msc$Xorig.beformsc <- spectrums.orig #save orignal spectrums for evaluation
  # data$msc$Xmsc <- spectrums.msc #save msc-corrected spectrums for evaluation
  # data$msc$Xmeans <- spectrums.mean #save mean spectrum for evaluation
  cat(green("msc.adapted completed\n"))
  return(data)
  
}