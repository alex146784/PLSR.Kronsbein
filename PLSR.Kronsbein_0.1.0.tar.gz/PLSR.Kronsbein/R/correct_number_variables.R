
#function to correct the number of variables, if the spectra of the MPA dont fit together, sometimes they have because of a bug a different resolution
correct_number_variables_MPA2 <- function(dirspectra, #directory of the spectra
                                          wavelengths = NULL, #if no wavelengths in the spectra are rigth, pass here the new wavelengths vector
                                          number_of_variables, #what is the right number of variables
                                          savefiles = TRUE, #save the new files, if FALSE give back a list
                                          filename.Xdata = "Xdata.csv", #the filename for the Xdata
                                          filename.wavelengths = "wavelengths.csv", #the filename for the wavelengths
                                          ...){
  cat(silver("correct_number_variables_MPA2 started\n"))
  startwd <- getwd() #remember current directory
  setwd(dir = dirspectra) #set working directory to the directory where the single spectra are saved after the exportaion of OPUS
  allfiles <- list.files() #read the names of all the spectra in dirspectra

  #if no wavelengths were passed use one that fits of the spectra files
  if(is.null(wavelengths)){
    i <- 1
    repeat{#use the first one that fits
      wavelengths.test <- (as.matrix(fread.csv.trycatch(allfiles[i])))[,1,drop = TRUE] #create vector of wavelengths (the first column of the first spectrumfile)
      if(number_of_variables == length(wavelengths.test)){break}
      if(i == length(allfiles)){stop("no wavelenghts of the spectra fit to the number_of_variables, please pass your own wavelengthsvector via wavelengths.")}
      i <- i +1
    }
    wavelengths <- wavelengths.test
    rm("wavelengths.test")
  }else{
    if(length(wavelengths) != number_of_variables){stop("The passed wavelengthsvector has not the right length")}#check if wavelengths has the rigth length
  }

  X.values <- matrix(data = NA, nrow = length(allfiles), ncol = number_of_variables) #create an empty matrix for the Y.values with the right dimensions
  for (i in 1:length(allfiles)){ #loop to read the data of the single spectrum files
    X.values.test <- as.matrix(fread.csv.trycatch(allfiles[i], silent = TRUE))[,2] #save only the second column of the spectra to X.values
    if(length(X.values.test) == number_of_variables){#check if the vector for this one spectrum has the rigth length, if yes than save it, if not than correct it
      X.values[i,] <- X.values.test
    }else{
      wavelengths.wrong <- (as.matrix(fread.csv.trycatch(allfiles[i])))[,1,drop = TRUE]#load the wrong wavelengths vector
      #go through each value and save the corrected one
      for(j in 1:length(wavelengths)){
        #select the to nearest values of the wrong spectra to the new one
        subset1 <- which(wavelengths.wrong >= wavelengths[j])
        subset1 <- which(wavelengths.wrong == min(wavelengths.wrong[subset1]))
        subset2 <- which(wavelengths.wrong <= wavelengths[j])
        subset2 <- which(wavelengths.wrong == max(wavelengths.wrong[subset2]))
        subset <- c(subset1, subset2)
        #calculate weigths, which depend on the the distance between the new value and the old ones
        weights <- abs(wavelengths.wrong[subset] - wavelengths[j])
        weights <- 1/weights
        weights <- weights / sum(weights)
        if(sum(is.na(weights))>0){weights <- rep(1, length(subset))} #correction if the new one and the old one are the same values
        #calculate the new value
        X.values[i,j] <- (matrix(data = weights, nrow = 1) %*% matrix(X.values.test[subset], ncol = 1))[1,1,drop = TRUE]
      }
    }
  }
  setwd(startwd)
  if(savefiles){#write results to files
    write.csv(x = X.values, file = filename.Xdata, row.names = FALSE)
    write.csv(x = wavelengths, file = filename.wavelengths, row.names = FALSE)
    cat(green("correct_number_variables_MPA2 completed\n"))
  }else{#give back results as a list
    cat(green("correct_number_variables_MPA2 completed\n"))
    return(list(X.values = X.values, wavelengths = wavelengths))
  }
}
