#internal function to create a suitable vector of colours for the spectra dataset
generate.colourforspectra <- function(length, #the number of spectra
                                      repetitions, #how often was repeated the same datapoint, repetitions will have the same colour
                                      ...){
  #a selection of possible colours
  colours <- c("aquamarine", "chartreuse", "darkseagreen", "darkgreen", "midnightblue", "deepskyblue4", "darkturquoise", "deepskyblue", "lightblue", "lightsteelblue", "pink", "orchid", "mediumpurple", "darkorchid4", "darkred", "tomato", "orange", "moccasin", "gold", "antiquewhite2", "sienna2", "tan4", "lemonchiffon4", "black")
  if(is.null(repetitions)){repetitions <- 1}#if repetions is NULL, set it to 1
  if(length(colours) < length/repetitions){# if colours vector is to short, repeat it, until it is long enough
    colours <- rep(colours, ceiling((length/repetitions)/length(colours)))
  }
  if(repetitions > 1){#if there are repetitions, repeat each value of colours as often as repetitions
    colours <- repeat.each.value.vector(colours, rep = repetitions)
  }
  colours <- colours[1:length] #shorten colours to the right size
  return(colours)
}


view.spectra <- function(data, #PLSR.Kronsbein Dataset
                         xlim = c(NA, NA), #limits of the X-axis in a vector of the length 2, first value min and second max
                         ylim = c(NA, NA), #limits of the Y-axis in a vector of the length 2, first value min and second max
                         plottype = "l", #plottype: "l" -> lines, "p" -> points, "b" -> both
                         col.l = NULL, #possibility to pass a own colourvector for the spectra
                         col.p = NULL, #possibility to pass a own colourvector for datapoints of the spectra
                         highlight.this.spectra = NULL,#vector of the rownumbers of the spectra, which should be highlighted
                         colourspectra = FALSE, #if True, all spectra will be coloured, so it is possible to see the repetitions
                         colourramp = FALSE, #if TRUE, the spectra will be coloured depending on the Y.values (which Y.value is specified in Ycol)
                         Ycol = 1, #which column of Yvalues should be used
                         p.size = 1, #the size of the datapoints
                         l.size = 1, #the size of the lines
                         plotname = "spectra", #the name of the file and the head of the plot
                         saveplots = FALSE, #should the plot be saved as a jpg file. this is useful for big dataset, because it is mauch quicker, than show the plot in Plots
                         directory = NULL, #the directory, where the file should be safed
                         resolution = "normal", #the resolution of the jpg file. Possible selections: "normal", "high", "ultrahigh"
                         repetitions = data$data.info$read.repetitions(), #the number of repetitions at one Datapoint
                         which.spectra = NULL, #pass vector of the rownames of the spectra that should be shown
                         ...){
  cat(silver("view.spectra started\n"))
  check.data(data = data) #function to know if the dataset is correct
  originalY <- data$data.info$read.originalY()
  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  #select the subset of the spectra
  if(!is.null(which.spectra)){
    data$prepdata <- data$prepdata[which.spectra, , drop = FALSE]
    data$oriY$Y.values <- data$oriY$Y.value[which.spectra, , drop = FALSE]
  }

  data$oriY$Y.values <- checkandpeform.changes.Y(model = data, Ydata = data$oriY$Y.values, Ydata_transformation = TRUE, calc.meanspectra = TRUE)

  if(originalY){
    data$oriY$Y.values <- undo_corrections_Y(model = data, Ydata = data$oriY$Y.values)
  }

  #check if the limitations of the axes are right
  if(length(ylim) != 2){
    stop("ylim has to be a vector of the length 2. Example: c(500,1000). You can use NA as the lowest or highest value")
  }
  if(length(xlim) != 2){
    stop("xlim has to be a vector of the length 2. Example: c(500,1000). You can use NA as the lowest or highest value")
  }

  #if there is no value in xlim and ylim, than set it to the maximum and minimum of the available values
  if(is.na(xlim[1])){
    xlim[1] <- min(data$wavelengths)
  }
  if(is.na(xlim[2])){
    xlim[2] <- max(data$wavelengths)
  }
  if(is.na(ylim[1])){
    ylim[1] <- min(data$prepdata$X)
  }
  if(is.na(ylim[2])){
    ylim[2] <- max(data$prepdata$X)
  }

  #set col.p to NULL, if col.l was used
  #col.l has the fourth hightes priority
  #col.p has the lowest priority
  if(!is.null(col.l)){
    if(!is.null(col.p)){
      col.p <- NULL
      warning("col.p was set to NULL, because col.l was used")
    }
  }

  #do this if colourspectra was set to TRUE
  if(colourspectra){
    #don´t use all the other possibilities to set the colour, colourspectra has the highest priority
    if(!is.null(highlight.this.spectra)){
      highlight.this.spectra <- NULL
      warning("highlight.this.spectra was set to NULL, because colourspectra was TRUE")
    }
    if(colourramp){
      colourramp <- FALSE
      warning("colourramp was set to FALSE, because colourspectra was TRUE")
    }
    if(!is.null(col.l)){
      col.l <- NULL
      warning("col.l was set to NULL, because colourspectra was TRUE")
    }
    if(!is.null(col.p)){
      col.p <- NULL
      warning("col.p was set to NULL, because colourspectra was TRUE")
    }

    #generate the colourvector with generate.colourforspectra()
    col.l <- generate.colourforspectra(length = nrow(data$prepdata$X), repetitions = repetitions)
  }

  #do this if colourramp was set to TRUE
  if(colourramp){
    #don´t use all the other possibilities to set the colour, colourspectra has the second highest priority after colourspectra
    if(!is.null(highlight.this.spectra)){
      highlight.this.spectra <- NULL
      warning("highlight.this.spectra was set to NULL, because colourramp was TRUE")
    }
    if(!is.null(col.l)){
      col.l <- NULL
      warning("col.l was set to NULL, because colourramp was TRUE")
    }
    if(!is.null(col.p)){
      col.p <- NULL
      warning("col.p was set to NULL, because colourramp was TRUE")
    }

    input.l <- list(data = data, data.info = data$data.info)#change dataformat so it is possible to use colourramp.sorted.for.Y
    #create colour vector with Colourramp.sorted.for.Y()
    col.l <- Colourramp.sorted.for.Y(data = data, input.l = input.l, Ycol =Ycol)
  }

  #do this if highligth.this.spectra isn´t TRUE, it will be a vector of the rownumber of the spectra that should be highlighted
  if(!is.null(highlight.this.spectra)){
    #don´t use all the other possibilities to set the colour, colourspectra has the third highest priority after colourspectra and colourramp
    if(!is.null(col.l)){
      col.l <- NULL
      warning("col.l was set to NULL, because highlight.this.spectra was used")
    }
    if(!is.null(col.p)){
      col.p <- NULL
      warning("col.p was set to NULL, because highlight.this.spectra was used")
    }
    #create a colourvector with this values as "red" specified in highlight.this.spectra
    col.l <- rep("black", nrow(data$prepdata$X))
    col.l[highlight.this.spectra] <- "red"
  }



  #change the resolution of the jpg file
  if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
    switch(resolution,
           "normal" = {
             plotwidth <- 1000 #width of plot in pixels
             plotheight <- 1000 #width of plot in pixels
             plotfontsize <- 23 #size of the heads of the plot
           },
           "high" = {
             plotwidth <- 5000 #width of plot in pixels
             plotheight <- 5000 #width of plot in pixels
             plotfontsize <- 115 #size of the heads of the plot
           },
           "ultrahigh" = {
             plotwidth <- 20000 #width of plot in pixels
             plotheight <- 20000 #width of plot in pixels
             plotfontsize <- 445 #size of the heads of the plot
           }
    )
    jpeg(paste0(plotname, ".jpg"), quality = 100, width = plotwidth, height = plotheight, pointsize = plotfontsize)#create jpg file
  }

  #use printplot.allspectrums to plot the spectra
  printplot.allspectrums(X = data$wavelengths, Y = data$prepdata$X, name = plotname, xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), type = plottype, xlim = xlim, ylim = ylim, col.l = col.l, col.p = col.p, cex = p.size, lwd = l.size, silent = TRUE)

  #depending on which method was used to colour the spectra a legend will be created
  if(colourspectra){
    Y.data <- signif(data$oriY$Y.values[,Ycol], digits = 4)
    if(!is.null(repetitions)){
      selection.Y <- rep(FALSE, repetitions)
      selection.Y[1] <- TRUE
      selection.Y <- rep(selection.Y, ceiling(length(Y.data)/repetitions))
      selection.Y <- selection.Y[1:length(col.l)]
      Y.data <- Y.data[selection.Y]
      col.l <- col.l[selection.Y]
    }
    legend(x = xlim[1], y = ylim[2], legend = Y.data, col = col.l, pch = rep(20, length(col.l)), title = colnames(data$oriY$Y.values)[Ycol])
  }
  if(colourramp){
    legend.col <- round(c(min(data$oriY$Y.values[,Ycol]), quantile(data$oriY$Y.values[,Ycol],0.25), median(data$oriY$Y.values[,Ycol]), quantile(data$oriY$Y.values[,Ycol],0.75)  ,max(data$oriY$Y.values[,Ycol])), digits = 4) #values for the legend
    legend(x = xlim[1], y = ylim[2], legend =legend.col, col = c("red", "yellow", "green", "blue", "black"), pch = rep(20, 5), title = colnames(data$oriY$Y.values)[Ycol])
  }
  if(!is.null(highlight.this.spectra)){
    legend(x = xlim[1], y = ylim[2], legend = paste0(highlight.this.spectra, ", ", signif(data$oriY$Y.values[highlight.this.spectra, Ycol], digits = 4)), col = rep("red", length(highlight.this.spectra)), pch = rep(20, length(highlight.this.spectra)), title = "red marked spectra\nwhich spectrum, Y.value")
  }

  if(saveplots){
    dev.off()#end jpg export
  }
  if(saveplots & !is.null(directory)){ #if necessary set working directory back to original wd
    setwd(actwd)
  }

  cat(green("view.spectra completed\n"))
}
