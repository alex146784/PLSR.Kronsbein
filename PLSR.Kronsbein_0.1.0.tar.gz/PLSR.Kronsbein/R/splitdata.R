#function to combine generate.split() and splitdata.externalvalidation()
generate.split_and_splitdata.externalvalidation <- function(data, #dataset of fread.dataprep.plsr
                                                            trainvalues.ratio = 0.75, #the part of the values, which should be used for the training of the model
                                                            whichY = 1, #if there are more than one Y-value, then use that one, with this column number
                                                            repetitions = data$data.info$read.repetitions(), #the number of repetitions at one Datapoint
                                                            savedata.TF = TRUE,
                                                            ...){
  split <- generate.split(data = data, trainvalues.ratio = trainvalues.ratio, whichY = whichY, repetitions = repetitions)
  data <- splitdata.externalvalidation(data = data, split = split, savedata.TF = savedata.TF)
  return(data)
}



#function to generate a list of vectors, which will be used in splitdata.externalvalidation
generate.split <- function(data, #dataset of fread.dataprep.plsr
                           trainvalues.ratio = 0.75, #the part of the values, which should be used for the training of the model
                           whichY = 1, #if there are more than one Y-value, then use that one, with this column number
                           repetitions = data$data.info$read.repetitions(), #the number of repetitions at one Datapoint
                           ...){
  cat(silver("generate.split started\n"))

  check.data(data = data) #function to check, if there was passed a dataset

  #prevent errors
  if(is.null(data)){stop("data have to be passed")}
  if(!(trainvalues.ratio >=0 | trainvalues.ratio <= 1)){stop("trainvalues.ratio has to be between 0 and 1")}
  #create a vector of the indizes, which values should be used to train the model
  if(is.null(repetitions)){ #normal case
    split.vec <- createDataPartition(y = data$prepdata$Y[,whichY], p = trainvalues.ratio, list = FALSE) #call fucntion to create the split.vec
    train <- rep(FALSE, nrow(data$prepdata$Y)) #the logical vector for training is first completly filled with FALSEs
    train[split.vec] <- TRUE#then set the values which were defined in split.vec to TRUE, so this values will be used for the training
  }else{ #do this to take care to the circumstance that there are repetiotions in the dataset

    #create a vector with on TRUE and FALSEs with a length of number of repetitions
    repvector <- rep(FALSE, repetitions)
    repvector[1] <- TRUE

    repvector <- rep(repvector, (nrow(data$prepdata$Y)/repetitions)) #vector, that discribes subset of the dataset with only one repetition in it
    split.vec <- createDataPartition(y = data$prepdata$Y[repvector,whichY], p = trainvalues.ratio, list = FALSE) #genereate split.vec with the subset of data
    train <- rep(FALSE, (nrow(data$prepdata$Y)/repetitions)) #the logical vector for training is first completly filled with FALSEs
    train[split.vec] <- TRUE#then set the values which were defined in split.vec to TRUE, so this values will be used for the training
    train <- matrix(rep(train,repetitions), nrow = repetitions, byrow = TRUE) #construct to repeat each value in train, (this row and row below)
    train <- as.vector(train)
  }




  test <- !train #all values which were FALSE in train are TRUE in test, these are the test values
  infos <- list(trainvalues.ratio = trainvalues.ratio, whichY = whichY) #save in addition a infofile, that will be used of splitdata.externalvalidation to save it to directorymethoddone
  output <- list(train = train, test = test, infos = infos) #output is a list with all important data
  cat(green("generate.split completed\n"))
  return(output)
}

#function to split the data into train and test data for the externalvalidation
splitdata.externalvalidation <- function(data, split = NULL, savedata.TF = TRUE){
  #prevent errors
  if(savedata.TF && data$directorymethoddone$is.methoddone("splitdata.externalvalidation")){stop("splitdata could be performed only one time during the datapreperation.")}
  if(is.null(data)) stop("please pass a dataset")
  if(is.null(split)) stop("please pass split, generated with generate.split()")
  #split the dataset with split$...
  if(savedata.TF){
    test.X <- data$prepdata$X[split$test, ,drop = FALSE]
    test.orig.Y <- data$oriY$Y.values[split$test,,drop = FALSE]
    test.orig.Y.center <- data$prepdata$Y[split$test,,drop = FALSE]
  }
  data$prepdata <- data$prepdata[split$train,,drop = FALSE]
  data$oriY$Y.values <- data$oriY$Y.values[split$train,,drop = FALSE]
  #save all informations to directorymethoddone
  if(savedata.TF){
    savedata <- list(train.X = data$prepdata$X, test.X = test.X, test.orig.Y = test.orig.Y, test.orig.Y.center = test.orig.Y.center, infos = split$infos, split = split)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object activ is necessary
    data$directorymethoddone$methoddone(whichmethod = "splitdata.exval", data = savedata, data.info = data$data.info$clone(deep = TRUE))
  }


  return(data)
}
