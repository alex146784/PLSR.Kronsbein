create.kFUN <- function(kfun, sigma = 1, degree = 1, scale = 1, offset = 1, order = 1){
  cat(silver("create.kFUN started\n"))
  switch(kfun,
         "linear" = {kFUN <- vanilladot()},
         "gauss" = {kFUN <- rbfdot(sigma = sigma)},
         "poly" = {kFUN <- polydot(degree = degree, scale = scale, offset = offset)},
         "tan" = {kFUN <- tanhdot(scale = scale, offset = offset)},
         "laplace" = {kFUN <- laplacedot(sigma = sigma)},
         "bessel" = {kFUN <- besseldot(sigma = sigma, order = order, degree = degree)},
         "anova" = {kFUN <- anovadot(sigma = sigma, degree = degree)},
         "spline" = {kFUN <- splinedot()},
         {stop("no valid kfun")}
  )
  return(kFUN)
  cat(green("create.kFUN completed\n"))
}



kpls <- function(data = NULL, #dataset for kpls, Important: create dataset with dataprep.plsr function
                 ncomp = NULL, #number of components, which should be evaluated
                 kfun = "linear",
                 sigma = 1,
                 degree = 1,
                 scale = 1,
                 offset = 1,
                 order = 1,
                 centeredY = data$data.info$read.centeredY(), #Y should be always centered (TRUE), only change if you know what you do
                 repetitions = data$data.info$read.repetitions(), #the number of repetitions at one Datapoint
                 savedata.TF = TRUE, #should the data be safed to directorymethoddone. Always TRUE, only in predict function FALSE
                 fast = FALSE,
                 ...){
  if(!fast) cat(silver("kpls started\n"))
  originalY <- data$data.info$read.originalY()

  max.ncomp <- calc.max.comp(data = data, validation = "none", segments = segments)
  if(is.null(ncomp)){ncomp <- max.ncomp}
  if(ncomp > max.ncomp){
    ncomp <- max.ncomp
    warning(paste0("The number of components (ncomp) was set to ", max.ncomp, " ,because it is not possible to calculate more components"))
  }

  if(is.function(kfun)){
    kFUN <- kfun
    kfun <- "own function"
  }else{
    kFUN <- create.kFUN(kfun = kfun, sigma = sigma, degree = degree, scale = scale, offset = offset, order = order)
  }

  X <- data$prepdata$X
  Y <- data$prepdata$Y


  K <- kernelMatrix(kernel = kFUN, x = X)
  n <- ncol(K)
  N <- matrix(data = 1/n, ncol = n, nrow = n)
  K1 <- K - (N %*% K) - (K %*% N) + (N %*% K %*% N)

  e <- K1
  f <- Y

  t.all <- matrix(data = NA, nrow = nrow(X), ncol = ncomp) #scores
  u.all <- matrix(data = NA, nrow = nrow(X), ncol = ncomp) #scores
  q.all <- matrix(data = NA, nrow = ncomp, ncol = ncol(Y)) #Y-loadings

  for(a in 1:ncomp){
    iter <- 1
    u.old <- f[,1, drop = FALSE]
    repeat{
      t.a <- e %*% u.old
      t.a <- t.a / length.vector.(t.a)
      q.a <- t(f) %*% t.a
      u.a <- f %*% q.a
      u.a <- u.a / length.vector.(u.a)
      crit <- length.vector.(u.a - u.old) / length.vector.(u.old)
      u.old <- u.a
      iter <- iter + 1
      if(crit <= 10^-9 || iter == 2000){
        if(iter == 2000){warning("max number of loops reached")}
        break
      }
    }
    #save all calculated data for this component to the matrices
    t.all[,a] <- t.a
    u.all[,a] <- u.a
    q.all[a,] <- q.a

    e <- (diag(n) - t.a %*% t(t.a)) %*% e %*% (diag(n) - t.a %*% t(t.a))
    f <- f - t.a %*% t(t.a) %*% f
  }
  B <- array(data = NA, dim = c(n, ncol(Y), ncomp))
  for(i in 1:ncomp){
    B[,,i] <- u.all[,1:i] %*% inv(t(t.all[,1:i]) %*% K1 %*% u.all[,1:i]) %*% (t(t.all[,1:i]) %*% Y)

  }
  R <- u.all %*% inv(t(t.all) %*% K1 %*% u.all)

  model <- list()

  if(!fast){
    Y.pred <- array(data = NA, dim = c(n, ncol(Y),ncomp))
    for(i in 1:ncomp){
      Y.pred[,,i] <- K1 %*% B[,,i]
    }
    Y.meas <- data$oriY$Y.values
    Y.meas <- checkandpeform.changes.Y(model = data, Ydata = Y.meas, Ydata_transformation = TRUE)
    if(originalY){
      Y.meas <- undo_corrections_Y(model = data, Ydata = Y.meas)
    }
    Y.pred <- undo_corrections_Y(model = data, Ydata = Y.pred)

    RMSEC <- parameter.calc(meas = Y.meas, pred = Y.pred)

    model$coefficients <- B
    dimnames(model$coefficients) <- list(NULL,colnames(Y), paste0("comp", 1:ncomp))
    model$scores <- t.all
    model$loadings <- t(t(t.all) %*% K1)
    model$Yscores <- u.all
    model$Yloadings <- t(q.all)
    model$projection <- R
    model$Xmeans <- rep(0, n)
    model$Ymeans <- rep(0, nrow(Y))
    model$Xtotvar <- sum(K1^2)
    model$Xvar <- apply(X = (model$loadings)^2, MARGIN = 2, sum)
    model$Ytotvar <- sum(Y^2)
    model$Yvar <- apply(X = (model$Yloadings)^2, MARGIN = 2, sum)

    #calculate different types of the explained variance and save them
    part.var <- model$Xvar / model$Xtotvar
    part.cum.var <- rep(NA, length(part.var))
    for(i in 1:length(part.var)){
      part.cum.var[i] <- sum(part.var[1:i])
    }
    model$part.Yvar <- model$Yvar / model$Ytotvar
    model$var <- model$Xvar
    model$part.var <- part.var
    model$part.cum.var <- part.cum.var
    model$RMSEC <- RMSEC
  }

  model$X <- X
  model$Y <- Y
  model$B <- B
  model$K <- K
  model$N <- N
  model$n <- n
  model$kFUN <- kFUN

  data.output <- data
  data.output$model <- model

  if(savedata.TF){
    kpls.data <- list(kFUN = kFUN, kfun = kfun, sigma = sigma, degree = degree, scale = scale, offset = offset, order = order)
    savedata <- list(kpls = TRUE, kpls.data = kpls.data, inputdata = data$prepdata, oriY = data$oriY, wavelengths = data$wavelengths, model = model,  ncomp = ncomp, directorymethoddone = data.output$directorymethoddone$clone(deep = TRUE))
    data.output$directorymethoddone <- data.output$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data.output$directorymethoddone$methoddone(whichmethod = "plsr.ex", data = savedata, data.info = data.output$data.info$clone(deep = TRUE)) #save the data to a new methoddone object in directorymethoddone

  }

  if(!fast) cat(green("kpls completed\n"))
  return(data.output)
}

kpls.predict <- function(model, which.comp, newdata){
  K <- kernelMatrix(kernel = model$kFUN, x = newdata, y = model$X)
  N <- matrix(data = 1/model$n, ncol = model$n, nrow = nrow(newdata))
  K1 <- K - (N %*% model$K) - (K %*% model$N) + (N %*% model$K %*% model$N)

  Y.pred <- array(data = NA, dim = c(nrow(newdata), ncol(model$Y), length(which.comp)))
  for(i in which.comp){
    Y.pred[,,i] <- K1 %*% model$B[,,i]
  }
  return(Y.pred)
}
