#function to evaluate the PCA
PCA.eval <- function(data = NULL,
                     which.comp = NULL,
                     ...){

  cat(silver("PCA.eval started\n"))
  originalY <- data$data.info$read.originalY()
  whichfunc <- "PCA.calc" #to simply copy the most part of function, use a variable
  input <- data$directorymethoddone$read.data(whichfunc) #read the required dataset, if this method was performed more than once, than all data will be in this list
  howoften <- data$directorymethoddone$number.methoddone(whichfunc) #read how often this method was performed, to know how often the following loop has be performed.

  for (i in 1:howoften){ #loop for each time this method was performed and so the results have to be saved
    name.method <- paste(whichfunc,i, sep = "") #exact name of the performed method
    input.l <- input[[name.method]] #selcet the data of the performed method, data of only one method

    foldername <- paste0(data$directorymethoddone$read.counter.directory(name.method),"_",name.method)
    suppressWarnings(dir.create(paste0(foldername))) #create new directory for the performed method
    setwd(foldername) #go into this directory


    if(length(which.comp) >= 2){#normal loading and scoreplot only useful with 2 components
      suppressWarnings(dir.create("Loadingplots"))
      PCA.loadingplot(data = data, which.comp = which.comp, saveplots = TRUE, directory = "Loadingplots", which.n.method = input.l)
      for(i.Ycol in 1:ncol(input.l$data$oriY$Y.values)){ #create a Scoreplot for each Y value, so the Y values can be shown as colours
        name.dir <- paste0("Scoreplots_Y",i.Ycol)
        PCA.scoreplot(data = data, which.comp = which.comp, saveplots = TRUE, directory = name.dir, Ycol = i.Ycol, which.n.method = input.l)
      }
    }
    #loadingplot as for one comp against the variable
    PCA.loadingplot.singlecomp(data = data, which.comp = which.comp, saveplots = TRUE, directory = "Loadingplots.singlecomp", which.n.method = input.l)
    for(i.Ycol in 1:ncol(input.l$data$oriY$Y.values)){ #create a Scoreplot for each Y value, so the Y values can be shown as colours
      name.dir <- paste0("Scoreplots.singlecomp_Y",i.Ycol)
      #scoreplot of one component against the sample
      PCA.scoreplot.singlecomp(data = data, which.comp = which.comp, saveplots = TRUE, directory = name.dir, Ycol = i.Ycol, which.n.method = input.l)
    }
    #print all different screeplots for the explained variance of the components
    PCA.screeplot(data = data, type = "var",  which.comp = which.comp, saveplots = TRUE, directory = "Screeplots", which.n.method = input.l)
    PCA.screeplot(data = data, type = "part.var",  which.comp = which.comp, saveplots = TRUE, directory = "Screeplots", which.n.method = input.l)
    PCA.screeplot(data = data, type = "part.cum.var",  which.comp = which.comp, saveplots = TRUE, directory = "Screeplots", which.n.method = input.l)

    #write all different datasets to csv files
    suppressWarnings(dir.create("datasets"))
    setwd("datasets")
    write.csv(input.l$data$data.PCA$loadings, paste0("loadings.csv"))
    write.csv(input.l$data$data.PCA$scores, paste0("scores.csv"))
    write.csv(input.l$data$data.PCA$eigenvectors, paste0("eigenvectors.csv"))
    write.csv(input.l$data$data.PCA$eigenvalues, paste0("eigenvalues.csv"))
    write.csv(input.l$data$data.PCA$var, paste0("var.csv"))
    write.csv(input.l$data$data.PCA$part.var, paste0("part.var.csv"))
    write.csv(input.l$data$data.PCA$part.cum.var, paste0("part.cum.csv"))
    write.csv(input.l$data$data.PCA$prcomp$x, "centered_scaled_X.csv")
    write.csv(input.l$data$inputdata$X, "original_X.csv")
    Y.values <- input.l$data$oriY$Y.values
    if(originalY){
      Y.values <- undo_corrections_Y(model = data, Ydata = Y.values)
    }
    write.csv(Y.values, "original_Y.csv")
    setwd("..")

    #create an infofile, if the data was centered or standardized
    sink(file = "infos.PCA.txt")
    cat("INFOS PCA\n\n")
    if(input.l$data$center){cat("The data were centered for PCA.\n")}
    if(input.l$data$standardize){cat("The data were scaled (standardized) for PCA.\n")}
    sink() #stop writting outputs to a file

    setwd("..")
  }
  cat(green("PCA.eval completed\n"))
}






#function to print scoreplots for two components at a time
PCA.scoreplot <- function(data, #model of PCA.calc
                          which.comp = c(1,2), #which comp should be printed
                          colourramp = TRUE, #colour the points, depending on the Y-values
                          fixedAxes = FALSE, #if TRUE the Axes will alway have be the same scale for all components
                          labels.sample.name = FALSE, #Label of the names of the datapoints
                          labels.Yvalue = FALSE, #Label the Yvalue for each datapoint
                          Ycol = 1, #for which Ycol the points will be coloured or labled
                          plotcex = 0.8, #size of the points
                          plotpch = 20, #type of datapoints
                          textcex = 0.5, #size of the text of labels
                          textpos = 3, #postion of the text of the labels (3 = above datapoints)
                          saveplots = FALSE, #save plots to jpeg files
                          directory = NULL, #if save the plots, then save them to this directory
                          plotquality = 100, #percentage of quality
                          plotwidth = 1000, #width of plot in pixels
                          plotheight = 1000, #width of plot in pixels
                          plotfontsize = 23, #size of the heads of the plot
                          col = "black", #colour of the datapoints, will be overwritten of the colourramp
                          which.n.method = NULL, #parameter which repetition of a function should be evaluated (integer)
                          ...){
  cat(silver("PCA.scoreplot started\n"))

  check.data(data = data, PCA = TRUE) #function to know if the dataset is correct
  originalY <- data$data.info$read.originalY()

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "PCA.calc")#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  Y.values <- input.l$data$oriY$Y.values
  if(originalY){
    Y.values <- undo_corrections_Y(model = data, Ydata = Y.values)
  }

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  if(length(which.comp) < 2){ #check if there are at least two components
    stop("the length of the vector which.comp has to be 2 or longer, if you only want to plot one component use PCA.scoreplot.singlcomp()")
  }



  if(labels.sample.name & labels.Yvalue){stop("only use lables.sample.name or labels.Yvalue")} #check if both is TRUE
  if(labels.sample.name){
    labels. <- rownames(input.l$data$data.PCA$scores) #take the rownames of Scores as labels
    if(is.null(labels.)){
      labels. <- 1:nrow(input.l$data$data.PCA$scores) #if there are no rownames use the rownumbers
      warning("Because there were no rownames in scores, the rownumber were used as labels.")
    }
  }
  if(labels.Yvalue){
    if(ncol(Y.values) < Ycol){stop("this Ycol is not available!")} #check whether Ycol is available
    labels. <- Y.values[,Ycol, drop = TRUE] #use the Ymatrix and choose the specified Ycol for the labels
    labels. <- round(labels., digits = 2)
  }

  if(colourramp){#create a coloured plot, if requested
    col <- Colourramp.sorted.for.Y(data = data, input.l = input.l, Ycol = Ycol) #create a vector with colours, depending on the Yvalues
    legend.col <- round(c(min(Y.values[,Ycol]), quantile(Y.values[,Ycol],0.25), median(Y.values[,Ycol]),  quantile(Y.values[,Ycol],0.75), max(Y.values[,Ycol])), digits = 4) #values for the legend
  }
  if(fixedAxes){
    lim <- c(min(input.l$data$data.PCA$scores),max(input.l$data$data.PCA$scores)) #if fixedAxes is TRUE, use always the same dimensions for the axes
  }
  for(i1 in which.comp){ #loop for the components
    for(i2 in which.comp) #loop for the components
      if(i1 < i2){ #do the following only if i1 is smalles than i2, so all usefull combinations will be printed
        xlab <- paste0("PC", which.comp[i1], " (", round((input.l$data$data.PCA$part.var[i1]*100), digits=2),"%)") #label X-axis
        ylab <- paste0("PC", which.comp[i2], " (", round((input.l$data$data.PCA$part.var[i2]*100), digits=2),"%)") #label Y-axis
        if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
          jpeg(paste0("PCA.scoreplot.comp=",i1, "_and_", i2, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
        }
        if(fixedAxes){ #depending on fixedAxes call the plot function with lim parameter or without
          plot(x = input.l$data$data.PCA$scores[,which.comp[i1]], y = input.l$data$data.PCA$scores[,which.comp[i2]], main = "PCA.Scoreplot", xlab = xlab, ylab = ylab, xlim = lim, ylim = lim, type = "p", col = col, pch = plotpch, cex = plotcex)
          if(colourramp){ #add legend, if colourramp is TRUE
            legend(x = lim[1], y = lim[2], legend =legend.col, col = c("red", "yellow", "green", "blue", "black"), pch = rep(plotpch, 5), title = colnames(Y.values)[Ycol])
          }
        }else{
          plot(x = input.l$data$data.PCA$scores[,which.comp[i1]], y = input.l$data$data.PCA$scores[,which.comp[i2]], main = "PCA.Scoreplot", xlab = xlab, ylab = ylab, type = "p", col = col, pch = plotpch, cex = plotcex)
          if(colourramp){ #add legend, if colourramp is TRUE
            legend(x = min(input.l$data$data.PCA$scores[,which.comp[i1]]), y = max(input.l$data$data.PCA$scores[,which.comp[i2]]), legend = legend.col, col =  c("red", "yellow", "green", "blue", "black"), pch = rep(plotpch, 5), title = colnames(Y.values)[Ycol])
          }
        }
        if(labels.sample.name | labels.Yvalue){ #if there are labels, add them to the plot
          text(x = input.l$data$data.PCA$scores[,which.comp[i1]], y = input.l$data$data.PCA$scores[,which.comp[i2]], labels = labels., cex = textcex, pos = textpos)
        }

        if(saveplots){
          dev.off()#end jpg export
        }
      }
  }
  if(saveplots & !is.null(directory)){ #if necessary set working directory back to original wd
    setwd(actwd)
  }
  cat(green("PCA.scoreplot completed\n"))
}

#function to print scoreplots for one components at a time
PCA.scoreplot.singlecomp <- function(data, #model of PCA.calc
                                     which.comp = 1, #which comp should be printed
                                     colourramp = FALSE, #colour the points, depending on the Y-values
                                     fixedAxes = FALSE, #if TRUE the Axes will alway have be the same scale for all components
                                     labels.sample.name = FALSE, #Label the names of the datapoints
                                     labels.Yvalue = FALSE, #Label the Yvalue for each datapoint
                                     Ycol = 1, #for which Ycol the points will be coloured or labled
                                     plotcex = 0.8, #size of the points
                                     plotpch = 20, #type of datapoints
                                     textcex = 0.5, #size of the text of labels
                                     textpos = 3, #postion of the text of the labels (3 = above datapoints)
                                     saveplots = FALSE, #save plots to jpeg files
                                     directory = NULL, #if save the plots, then save them to this directory
                                     plotquality = 100, #percentage of quality
                                     plotwidth = 1000, #width of plot in pixels
                                     plotheight = 500, #width of plot in pixels
                                     plotfontsize = 23, #size of the heads of the plot
                                     col = "black", #colour of the datapoints, will be overwritten of the colourramp
                                     which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                                     ...){
  cat(silver("PCA.scoreplot.singlecomp started\n"))

  check.data(data = data, PCA = TRUE) #function to know if the dataset is correct
  originalY <- data$data.info$read.originalY()

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "PCA.calc")#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  Y.values <- input.l$data$oriY$Y.values
  if(originalY){
    Y.values <- undo_corrections_Y(model = data, Ydata = Y.values)
  }

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  if(labels.sample.name & labels.Yvalue){stop("only use lables.sample.name or labels.Yvalue")}
  if(labels.sample.name){
    labels. <- rownames(input.l$data$data.PCA$scores) #take the rownames of Scores as labels
    if(is.null(labels.)){
      labels. <- 1:nrow(input.l$data$data.PCA$scores) #if there are no rownames use the rownumbers
      warning("Because there were no rownames in scores, the rownumber were used as labels.")
    }
  }
  if(labels.Yvalue){
    if(ncol(Y.values) < Ycol){stop("this Ycol is not available!")} #check whether Ycol is available
    labels. <- Y.values[,Ycol, drop = TRUE] #use the Ymatrix and choose the specified Ycol for the labels
    labels. <- round(labels., digits = 2)
  }
  if(colourramp){
    col <- Colourramp.sorted.for.Y(data = data, input.l = input.l, Ycol = Ycol) #create a vector with colours, depending on the Yvalues
    legend.col <- round(c(min(Y.values[,Ycol]), quantile(Y.values[,Ycol],0.25), median(Y.values[,Ycol]),  quantile(Y.values[,Ycol],0.75), max(Y.values[,Ycol])), digits = 4) #values for the legend
  }
  if(fixedAxes){
    xlim <- c(min(input.l$data$data.PCA$scores),max(input.l$data$data.PCA$scores)) #if fixedAxes is TRUE, use always the same dimensions for the axes
  }

  ylab <- colnames(Y.values)[Ycol] #label Y-axis

  if(is.null(ylab)){ylab <- paste0("Ydata column nr. ", Ycol)}
  for(i1 in which.comp){ #loop for the components
    xlab <- paste0("PC", which.comp[i1], " (", round((input.l$data$data.PCA$part.var[i1]*100), digits=2),"%)") #label X-axis
    if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
      jpeg(paste0("PCA.scoreplot.comp=",i1, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    }
    if(fixedAxes){ #depending on fixedAxes call the plot function with lim parameter or without
      plot(x = input.l$data$data.PCA$scores[,which.comp[i1]], y = Y.values[,Ycol], main = "PCA.Scoreplot", xlab = xlab, ylab = ylab, xlim = xlim, type = "p", col = col, pch = plotpch, cex = plotcex)
      if(colourramp){ #add legend, if colourramp is TRUE
        legend(x = xlim[1], y = max(Y.values[,Ycol]), legend =legend.col, col = c("red", "yellow", "green", "blue", "black"), pch = rep(plotpch, 5), title = colnames(Y.values)[Ycol])
      }
    }else{
      plot(x = input.l$data$data.PCA$scores[,which.comp[i1]], y = Y.values[,Ycol], main = "PCA.Scoreplot", xlab = xlab, ylab = ylab, type = "p", col = col, pch = plotpch, cex = plotcex)
      if(colourramp){ #add legend, if colourramp is TRUE
        legend(x = min(input.l$data$data.PCA$scores[,which.comp[i1]]), y = max(Y.values[,Ycol]), legend = legend.col, col = c("red", "yellow", "green", "blue", "black"), pch = rep(plotpch, 5), title = colnames(Y.values)[Ycol])
      }
    }
    if(labels.sample.name | labels.Yvalue){ #if there are labels, add them to the plot
      text(x = input.l$data$data.PCA$scores[,which.comp[i1]], y = Y.values[,Ycol], labels = labels., cex = textcex, pos = textpos)
    }
    if(saveplots){
      dev.off()#end jpg export
    }
  }
  if(saveplots & !is.null(directory)){ #if necessary set working directory back to original wd
    setwd(actwd)
  }
  cat(green("PCA.scoreplot.singlecomp completed\n"))
}

#function to printloadingplots for two components at a time
PCA.loadingplot <- function(data, #model of PCA.calc
                            which.comp = c(1,2), #which comp should be printed
                            fixedAxes = FALSE, #if TRUE the Axes will alway have be the same scale for all components
                            labels.variable.name = FALSE, #Label the names of the datapoints
                            labels.wavelengths = FALSE, #Label with the values of wavelengths
                            plotcex = 0.8, #size of the points
                            plotpch = 20, #type of datapoints
                            textcex = 0.5, #size of the text of labels
                            textpos = 3, #postion of the text of the labels (3 = above datapoints)
                            saveplots = FALSE, #save plots to jpeg files
                            directory = NULL, #if save the plots, then save them to this directory
                            plotquality = 100, #percentage of quality
                            plotwidth = 1000, #width of plot in pixels
                            plotheight = 1000, #width of plot in pixels
                            plotfontsize = 23, #size of the heads of the plot
                            col = "black", #colour of the datapoints
                            which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                            ...){
  cat(silver("PCA.loadingplot started\n"))

  check.data(data = data, PCA = TRUE) #function to know if the dataset is correct

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "PCA.calc")#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  if(length(which.comp) < 2){ #check if there are at least two components
    stop("the length of the vector which.comp has to be 2 or longer, if you only want to plot one component use PCA.scoreplot.singlcomp()")
  }

  if(labels.variable.name & labels.wavelengths){stop("only use lables.variable.name or labels.wavelengths")}
  if(labels.variable.name){
    labels. <- rownames(input.l$data$data.PCA$loadings) #take the rownames of Loadings as labels
    if(is.null(labels.)){ #if there are no rownames use the rownumbers
      labels. <- 1:nrow(input.l$data$data.PCA$loadings)
      warning("Because there were no rownames in loadings, the rownumber were used as labels.")
    }
  }
  if(labels.wavelengths){
    labels. <- input.l$data$wavelengths #use the Ymatrix and choose the specified Ycol for the labels
    labels. <- round(labels., digits = 0)
  }
  if(fixedAxes){
    lim <- c(min(input.l$data$data.PCA$loadings),max(input.l$data$data.PCA$loadings)) #if fixedAxes is TRUE, use always the same dimensions for the axes
  }
  for(i1 in which.comp){ #loop for the components
    for(i2 in which.comp) #loop for the components
      if(i1 < i2){ #do the following only if i1 is smalles than i2, so all usefull combinations will be printed
        xlab <- paste0("PC", which.comp[i1], " (", round((input.l$data$data.PCA$part.var[i1]*100), digits=2),"%)") #label X-axis
        ylab <- paste0("PC", which.comp[i2], " (", round((input.l$data$data.PCA$part.var[i2]*100), digits=2),"%)") #label Y-axis
        if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
          jpeg(paste0("PCA.loadingplot.comp=",i1, "_and_", i2, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
        }
        if(fixedAxes){ #depending on fixedAxes call the plot function with lim parameter or without
          plot(x = input.l$data$data.PCA$loadings[,which.comp[i1]], y = input.l$data$data.PCA$loadings[,which.comp[i2]], main = "PCA.Loadingplot", xlab = xlab, ylab = ylab, xlim = lim, ylim = lim, type = "p", col = col, pch = plotpch, cex = plotcex)
        }else{
          plot(x = input.l$data$data.PCA$loadings[,which.comp[i1]], y = input.l$data$data.PCA$loadings[,which.comp[i2]], main = "PCA.Loadingplot", xlab = xlab, ylab = ylab, type = "p", col = col, pch = plotpch, cex = plotcex)
        }
        if(labels.variable.name | labels.wavelengths){ #if there are labels, add them to the plot
          text(x = input.l$data$data.PCA$loadings[,which.comp[i1]], y = input.l$data$data.PCA$loadings[,which.comp[i2]], labels = labels., cex = textcex, pos = textpos)
        }
        if(saveplots){
          dev.off()#end jpg export
        }
      }
  }
  if(saveplots & !is.null(directory)){ #if necessary set working directory back to original wd
    setwd(actwd)
  }
  cat(green("PCA.loadingplot completed\n"))
}

#function to printloadingplots for one component at a time
PCA.loadingplot.singlecomp <- function(data, #model of PCA.calc
                                       which.comp = 1, #which comp should be printed
                                       fixedAxes = FALSE, #if TRUE the Axes will alway have be the same scale for all components
                                       labels.variable.name = FALSE, #Label the names of the datapoints
                                       labels.wavelengths = FALSE, #Label with the values of wavelengths
                                       plotcex = 0.8, #size of the points
                                       plotpch = 20, #type of datapoints
                                       plottype = "p", #plottype
                                       textcex = 0.5, #size of the text of labels
                                       textpos = 3, #postion of the text of the labels (3 = above datapoints)
                                       saveplots = FALSE, #save plots to jpeg files
                                       directory = NULL, #if save the plots, then save them to this directory
                                       plotquality = 100, #percentage of quality
                                       plotwidth = 1000, #width of plot in pixels
                                       plotheight = 500, #width of plot in pixels
                                       plotfontsize = 23, #size of the heads of the plot
                                       col = "black", #colour of the datapoints
                                       which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                                       ...){
  cat(silver("PCA.loadingplot.singlecomp started\n"))

  check.data(data = data, PCA = TRUE) #function to know if the dataset is correct

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "PCA.calc")#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  if(labels.variable.name & labels.wavelengths){stop("only use lables.variable.name or labels.wavelengths")}
  if(labels.variable.name){
    labels. <- rownames(input.l$data$data.PCA$loadings) #take the rownames of Loadings as labels
    if(is.null(labels.)){ #if there are no rownames use the rownumbers
      labels. <- 1:nrow(input.l$data$data.PCA$loadings)
      warning("Because there were no rownames in loadings, the rownumber were used as labels.")
    }
  }
  if(labels.wavelengths){
    labels. <- input.l$data$wavelengths #use the Ymatrix and choose the specified Ycol for the labels
    labels. <- round(labels., digits = 0)
  }
  if(fixedAxes){
    ylim <- c(min(input.l$data$data.PCA$loadings),max(input.l$data$data.PCA$loadings)) #if fixedAxes is TRUE, use always the same dimensions for the axes
  }

  xlab <- paste0("variable (", data$data.info$read.UnitspecX(), ")") #label X-axis

  for(i1 in which.comp){ #loop for the components
    ylab <- paste0("loading value PC", which.comp[i1], " (", round((input.l$data$data.PCA$part.var[i1]*100), digits=2),"%)") #label Y-axis
    if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
      jpeg(paste0("PCA.loadingplot.comp=",i1, ".jpg"), quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
    }
    if(fixedAxes){ #depending on fixedAxes call the plot function with lim parameter or without
      plot(x = input.l$data$wavelengths, y = input.l$data$data.PCA$loadings[,which.comp[i1]], main = "PCA.Loadingplot", xlab = xlab, ylab = ylab, ylim = ylim, type = plottype, col = col, pch = plotpch, cex = plotcex)
    }else{
      plot(x = input.l$data$wavelengths, y = input.l$data$data.PCA$loadings[,which.comp[i1]], main = "PCA.Loadingplot", xlab = xlab, ylab = ylab, type = plottype, col = col, pch = plotpch, cex = plotcex)
    }
    if(labels.variable.name | labels.wavelengths){ #if there are labels, add them to the plot
      text(x = input.l$data$wavelengths, y = input.l$data$data.PCA$loadings[,which.comp[i1]], labels = labels., cex = textcex, pos = textpos)
    }
    if(saveplots){
      dev.off()#end jpg export
    }
  }
  if(saveplots & !is.null(directory)){ #if necessary set working directory back to original wd
    setwd(actwd)
  }
  cat(green("PCA.loadingplot.singlecomp completed\n"))
}

#function to print a screeplot to show the explained variance of the components
PCA.screeplot <- function(data, #model of PCA.calc
                          which.comp = NULL, #which comp should be print, default all
                          type = "part.var", #plottype (var -> variance, part.var -> partial variance per comp, part.cum.var -> cumulative partial variance)
                          saveplots = FALSE, #save plots to jpeg files
                          directory = NULL, #if save the plots, then save them to this directory
                          plotquality = 100, #percentage of quality
                          plotwidth = 1000, #width of plot in pixels
                          plotheight = 500, #width of plot in pixels
                          plotfontsize = 23, #size of the heads of the plot
                          col = "grey", #colour of the datapoints
                          which.n.method = NULL,#parameter which repetition of a function should be evaluated (integer)
                          ...){
  cat(silver("PCA.screeplot started\n"))

  check.data(data = data, PCA = TRUE) #function to know if the dataset is correct

  input.l <- check.which.n.method_or_read(which.n.method = which.n.method, data = data, whichfunc = "PCA.calc")#check if directorymethoddonedata were passed with which.n.method or if the data must be read out

  actwd <- check.set.create.directory(saveplots = saveplots, directory = directory) #function to check, if the data should be saved, if the directory exist, else create one (returns the current directory)

  if(is.null(which.comp)){ #if which.comp was not specified set to the maximum available components
    which.comp <- 1:length(input.l$data$data.PCA$var)
  }
  switch(type, #set all plot parameters depending on plot type
         "var" = {
           plot.name <- "explained variance per component"
           data.plot <- input.l$data$data.PCA$var
           jpeg.name <- "PCA.var.plot.jpg"
           ylab = "variance"
           ylim = c(0,max(input.l$data$data.PCA$var))
         },
         "part.var" = {
           plot.name <- "percentage of the explained variance per component"
           data.plot <- input.l$data$data.PCA$part.var *100
           jpeg.name <- "PCA.part.var.plot.jpg"
           ylab <- "percentage variance [%]"
           ylim = c(0,100)
         },
         "part.cum.var" ={
           plot.name <- "cumulative percentage of the explained variance per component"
           data.plot <- input.l$data$data.PCA$part.cum.var *100
           jpeg.name <- "PCA.part.cum.var.plot.jpg"
           ylab <- "percentage variance [%]"
           ylim = c(0,100)
         },
         {stop("invalid character for type. Possible: \"var\", \"part.var\", \"part.cum.var\"")} #if no valid plottype was entered, print an error
  )
  if(saveplots){ #if plots should be safed, call jpeg function with following parameters for jpg export
    jpeg(jpeg.name, quality = plotquality, width = plotwidth, height = plotheight, pointsize = plotfontsize)
  }
  #print a barplot with the informations
  barplot(height = data.plot[which.comp], names.arg = which.comp, main = "PCA.Screeplot", xlab = "component", ylab = ylab, ylim = ylim, sub = plot.name, col = col)

  if(saveplots){
    dev.off()#end jpg export
  }

  if(saveplots & !is.null(directory)){#if necessary set working directory back to original wd
    setwd(actwd)
  }

  cat(green("PCA.screeplot completed\n"))
}

