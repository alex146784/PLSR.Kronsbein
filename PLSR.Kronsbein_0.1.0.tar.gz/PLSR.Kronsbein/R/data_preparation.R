#standard function to prepare the date for all other function in this programm
dataprep.plsr <- function(X.values, #matrix for the Xvalues (Y values of the spectrum)
                          Y.values = NULL, #matrix for the Y values
                          wavelengths, #matrix for the X-values of the sprectrum, normally the wavelengths
                          centerY = TRUE, #boolean to center the Ydata, only change if you know what you do, if not plsr.ex could do shit
                          originalY = TRUE, #should be used for all evaluation functions the original Y.values
                          add.infos = NULL, #add.infos passed through other dataprep function
                          UnitspecY = "", #Unitspec of the Y data
                          UnitspecX = "", #Unitspec of the X data
                          repetitions = NULL, #the number of repetitions at one Datapoint
                          printplots.TF = FALSE, #should the spectrum be plotted
                          colnames.X = NULL, #if not in the passed matrix add the columnnames
                          rownames.X.Y = NULL, #if not in the passed matrix add the rownames for both matrices, Y and X values have to fit to each other
                          colnames.Y = NULL, #if not in the passed matrix add the columnnames
                          ...){

  cat(silver("dataprep.plsr started\n"))
  #Test for mistakes
  if(!is.matrix(X.values)){stop("X.values has to be a matrix.")}
  if(!is.matrix(Y.values)&& !is.null(Y.values)){stop("Y.values has to be a matrix.")}
  if(!is.numeric(wavelengths)){stop("wavelengths has to be a vector with all wavelengths or wavenumbers.")}
  if(ncol(X.values) != length(wavelengths)){stop("There has to be a value in wavelengths for each column in X.values. One Column in X.values are the values of all spectra at the same wavelength")}
  if(nrow(X.values) != nrow(Y.values) && !is.null(Y.values)){stop("There has to be the same number of rows in X.values and Y.values. One row in X.values represents one spectrum and the row in Y.values are all depending Y or Responsevalues for this spectum.")}
  if(centerY == FALSE){warning("Are you sure not to center the Y data. Only do this, if you know what you do. It is possible, that the plsr.ex function doesn't work like it should, if the Ydata aren't centerd.")}
  if(is.null(Y.values)){warning("no Y.values were passed, this is necessary to create a model later")}
  if(!is.null(rownames.X.Y)){ #if rownames.X.Y was passed check if everything is okay and then set the rownames to this vector
    if(!is.character(rownames.X.Y) || !is.vector(rownames.X.Y)){stop("rownames.X.Y has to be a vector of characters")}
    if(nrow(X.values) != length(rownames.X.Y) || (nrow(Y.values) != length(rownames.X.Y) && !is.null(Y.values))){stop("rownames.X.Y has to have the same length, like the number of rows in X.values and Y.values")}
    rownames(X.values) <- rownames.X.Y
    if(!is.null(Y.values)){
      rownames(Y.values) <- rownames.X.Y
    }
  }

  if(!is.null(colnames.X)){ #if colnames.X was passed check if everything is okay and then set the colnames of X.values to this vector
    if(!is.character(colnames.X) || !is.vector(colnames.X)){stop("colnames.X has to be a vector of characters")}
    if(ncol(X.values) != length(colnames.X) ){stop("colnames.X has to have the same length, like the number of columns in X.values")}
    colnames(X.values) <- colnames.X
  }

  if(!is.null(colnames.Y) && !is.null(Y.values)){ #if colnames.Y was passed check if everything is okay and then set the colnames of Y.values to this vector
    if(!is.character(colnames.Y) || !is.vector(colnames.Y)){stop("colnames.Y has to be a vector of characters")}
    if(ncol(Y.values) != length(colnames.Y) ){stop("colnames.Y has to have the same length, like the number of columns in Y.values")}
    colnames(Y.values) <- colnames.Y
  }

  #center Y-values, to prevent mistakes in plsr function
  if(centerY && !is.null(Y.values)){
    Y.values.ori <- Y.values #save orinal Y-values
    Y.mean <- apply(Y.values, MARGIN = 2, FUN = mean) #calculate means of the Responseparameters
    Y.values <- apply.t(Y.values, MARGIN = 1, FUN = substract.spectrum, mean.spec = Y.mean)#misused function, y values are not spectra, but it works in the same way
  }


  if(!is.null(Y.values)){
    dataprep <- list(prepdata = data.frame(Y = I(Y.values),X = I(X.values) )) #save prepared data in a list, so additional information could be passed
  }else{
    dataprep <- list(prepdata = data.frame(X = I(X.values) )) #save prepared data in a list, so additional information could be passed
  }
  #names(dataprep) <- "prepdata"
  if(centerY&& !is.null(Y.values)){#save original values and Ymean
    dataprep$oriY$Y.values <- Y.values.ori
    dataprep$oriY$Y.mean <- Y.mean
  }else{
    dataprep$oriY$Y.values <-Y.values
  }
  if(!is.null(wavelengths)){
    if(!is.vector(wavelengths)){stop("No vector passed with wavelengths!")}# check if passed data is Vector
    if(length(wavelengths)!=ncol(X.values)){ #prevent error, that number of values of wavelengths and the number of spectrums aren´t similar
      message(paste("number of values in wavelengths: ",length(wavelengths))) #for information the number of values in wavelengths
      message(paste("number of measuringpoints in one spectrum: ",ncol(X.values))) #for information the number of spectrums
      stop("The number of values in wavelengths must be the same as the number of measuringpoints of one spectrum") #errormessage
    }
    dataprep$wavelengths <- wavelengths #adds wavelengths to dataset
  }

  #check if the number of repetitions is senseful
  if(!is.null(repetitions) && (nrow(dataprep$prepdata) %% repetitions) != 0){stop("The number of samples has to divisible through the repetitions!")}

  #create data.info object with the informations about the units, the repetitions and if the data were centered
  dataprep$data.info <- data.info$new(centeredY = centerY, originalY = originalY, UnitspecX = UnitspecX, UnitspecY = UnitspecY, repetitions = repetitions)

  if(printplots.TF){printplot.allspectrums(X = dataprep$wavelengths, Y = dataprep$prepdata$X, name = "initial spectrum", xlab = dataprep$data.info$read.UnitspecX(), ylab = dataprep$data.info$read.UnitspecY(), type = "l")} #print all spectrums

  dataprep$directorymethoddone <- directorymethoddone$new() #adds the object directorymethoddone to the dataset, for every datapreperationmethod there will be an entry
  #list of all additional infos
  infos <- list(centerY = centerY, originalY = originalY)
  #list of all data, that should be saved to methoddoneobject
  if(is.null(add.infos)){add.infos <- list(dataprep.method = "dataprep.plsr")}#check if there were addi.infos in a function, which calls this function, else set add.infos
  savedata <- list(dataX = X.values, dataY = Y.values, dataYori = dataprep$oriY$Y.values, dataYmean = dataprep$oriY$Y.mean, wavelengths = wavelengths, infos = infos, UnitspecX = UnitspecX, UnitspecY = UnitspecY, repetitions = repetitions, add.infos = add.infos)
  dataprep$directorymethoddone$methoddone(whichmethod = "dataprep.plsr", data = savedata, data.info = dataprep$data.info$clone(deep = TRUE)) #save savedata to a methoddone object in directorymethoddone
  cat(green("dataprep.plsr completed\n"))
  return(dataprep)


}


fread.MPA2.dataprep.plsr <- function(dirspectra, #directory of the spectra
                                     Yfile = NULL, #file for the
                                     Y.col = NULL, #only necessary, if file was passed. Necessary to split file into X and Y data
                                     repeatYvalues = FALSE, #repeat all values in Yfile
                                     centerY = TRUE, #boolean to center the Ydata, only change if you know what you do, if not plsr.ex could do shit
                                     originalY = TRUE, #should be used for all evaluation functions the original Y.values
                                     UnitspecY = "", #Unitspec of the Y data
                                     UnitspecX = "", #Unitspec of the X data
                                     repetitions = NULL, #the number of repetitions at one Datapoint
                                     printplots.TF = FALSE,
                                     colnames.X = NULL, #if not in the passed matrix add the columnnames
                                     rownames.X.Y = NULL, #if not in the passed matrix add the rownames for both matrices, Y and X values have to fit to each other
                                     colnames.Y = NULL, #if not in the passed matrix add the columnnames
                                     ...){
  cat(silver("fread.MPA2.dataprep.plsr started\n"))
  startwd <- getwd() #remember current directory
  setwd(dir = dirspectra) #set working directory to the directory where the single spectra are saved after the exportaion of OPUS
  allfiles <- list.files() #read the names of all the spectra in dirspectra
  #allreaddata <- list()

  wavelengths <- (as.matrix(fread.csv.trycatch(allfiles[1])))[,1,drop = TRUE] #create vector of wavelengths (the first column of the first spectrumfile)
  X.values <- matrix(data = NA, nrow = length(allfiles), ncol = length(wavelengths)) #create an empty matrix for the Y.values with the right dimensions
  for (i in 1:length(allfiles)){ #loop to read the data of the single spectrum files
    X.values[i,] <- as.matrix(fread.csv.trycatch(allfiles[i], silent = TRUE))[,2] #save only the second column of the spectra to X.values
  }
  colnames(X.values) <- wavelengths #name the columns of X.values
  if (any(is.na(X.values))){stop("a mistake happend during the reading process of the data, maybe the data don´t fit together.")} #test for errors
  setwd(startwd)#set wd back to startwd
  if(!is.null(Yfile)){
    Y.values <- as.matrix(fread.csv.trycatch(Yfile))#read the Y.values
  }else{
    Y.values <- NULL
    warning("no Yfile was passed, this is necessary to create a model")
  }


  if(!is.null(Y.col) && !is.null(Y.values)){
    if(!is.numeric(Y.col)){stop("Ycol has to be numeric")}
    Y.values <- Y.values[,Y.col, drop = FALSE]
  }


  if(repeatYvalues && !is.null(repetitions) && !is.null(Y.values)){
    Y.values.l <- matrix(NA, nrow = nrow(Y.values)*repetitions, ncol = ncol(Y.values))
    for(i in 1:ncol(Y.values)){
      Y.values.i <- Y.values[,i]
      Y.values.i <- repeat.each.value.vector(vector = Y.values.i, rep = repetitions)
      Y.values.l[,i] <- Y.values.i
    }
    Y.values <- Y.values.l
  }

  #additional infos, which are not included in dataprep.plsr
  add.infos <- list(dataprep.method = "fread.MPA2.dataprep.plsr" ,dirspectra = dirspectra, sourceYfile = Yfile, directory = startwd, repeatYvalues = repeatYvalues, sourceYcol = Y.col)

  #call dataprepfunction, which does the rest
  dataprep <- dataprep.plsr(X.values = X.values, Y.values = Y.values, wavelengths = wavelengths, centerY = centerY, originalY = originalY, UnitspecX = UnitspecX, UnitspecY = UnitspecY, repetitions = repetitions,  add.infos = add.infos, printplots.TF = printplots.TF, rownames.X.Y = rownames.X.Y, colnames.X = colnames.X, colnames.Y = colnames.Y)

  cat(green("fread.MPA2.dataprep.plsr completed\n"))
  return(dataprep)
}



#Daten einlesen und direkt anpassen für PLSR
fread.dataprep.plsr <- function(file = NULL, #name of csv file for the complete raw data, file have to in the same folder, as the executed file
                                Xfile = NULL, #only necessary, if no file was passed. Pass file for the Xdata
                                Yfile = NULL, #only necessary, if no file was passed. Pass file for the Ydata
                                X.col = NULL, #only necessary, if file was passed. Necessary to split file into X and Y data
                                Y.col = NULL, #only necessary, if file was passed. Necessary to split file into X and Y data
                                wavelengths = NULL, #additional information for further functions, to know which variable has which wavelength
                                wavelengths.file = NULL, #file for the wavelengths
                                centerY = TRUE, #boolean to center the Ydata, only change if you know what you do, if not plsr.ex could do shit
                                originalY = TRUE, #should be used for all evaluation functions the original Y.values
                                UnitspecY = "", #Unitspec of the Y data
                                UnitspecX = "", #Unitspec of the X data
                                repetitions = NULL, #the number of repetitions at one Datapoint
                                printplots.TF = FALSE, #if TRUE, all plots are going to be printed
                                colnames.X = NULL, #if not in the passed matrix add the columnnames
                                rownames.X.Y = NULL, #if not in the passed matrix add the rownames for both matrices, Y and X values have to fit to each other
                                colnames.Y = NULL, #if not in the passed matrix add the columnnames
                                ...){
  cat(silver("fread.dataprep.plsr started\n"))
  if(!is.null(file)){ #test if file is available, further procedure depends on this.
    if(is.null(X.col)|is.null(Y.col)){stop("please add X.col or/and Y.col to split the file")} #test if columns were specified, if not stop
    Orig.data <- fread.csv.trycatch(file) #read file and check if everything is okay.
    X.values <- as.matrix(Orig.data)[,X.col,drop = FALSE] #save the right columns as matrix as the X-Values
    Y.values <- as.matrix(Orig.data)[,Y.col,drop = FALSE] #save the right columns as matrix as the Y-Values
    if(!is.null(Xfile)|!is.null(Yfile)){warning("Xfile and/or Yfile not used, because file was indicated and so this files weren´t necessary!")} #if Xfile and Yfile were additionaly specified, inform the user, that these file weren´t used
  }else{
    if(is.null(Xfile)){stop("please add a source for the data(file or Xfile and Yfile)")} #if no file was specified stop program and inform user
    if(is.null(X.col)){ #if col were defined cut down file
      X.values <- as.matrix(fread.csv.trycatch(Xfile))#read file and check if everything is okay and save as matrix.
    }else{
      X.values <- as.matrix(fread.csv.trycatch(Xfile))[,X.col,drop = FALSE]
    }
    if(!is.null(Yfile)){
      if(is.null(Y.col)){#if col were defined cut down file
        Y.values <- as.matrix(fread.csv.trycatch(Yfile))#read file and check if everything is okay and save as matrix.
      }else{
        Y.values <- as.matrix(fread.csv.trycatch(Yfile))[,Y.col,drop = FALSE]
      }
    }else{
      Y.values <- NULL
      warning("no Yfile was passed, this is necessary to create a model")
    }


    if(nrow(X.values) != nrow(Y.values) && !is.null(Y.values)){stop("Yfile and Xfile have to be the same length")} #test if the number of spectrum fits to the number of response values
  }

  #prevent errors with wavelengths
  if(is.null(wavelengths) & is.null(wavelengths.file)){stop("wavelengths have to passed via a vector (wavelengths) or a sourcefile (wavelengths.file)")}
  if((!is.null(wavelengths)) & (!is.null(wavelengths.file))){stop("please wavelengths data only via one option as a vector (wavelengths) or as sourcefile (wavelengths.file)")}
  if((!is.null(wavelengths)) & ((!is.vector(wavelengths)) | (!is.numeric(wavelengths)))){stop("wavelengths has to be a numeric vector")}
  if((!is.null(wavelengths.file)) & (!is.character(wavelengths.file))){stop("wavelengths.file has to be a character with the name of the source file")}

  #read wavelengths out of a file, else keep passed wavelengths, as they are (do nothing)
  if(is.null(wavelengths)){
    wavelengths <- fread.csv.trycatch(wavelengths.file) #read wavelengths
    if(ncol(wavelengths) > 1){stop("the wavelengths in the sourcefile have to be saved in one column, necessary to be saved as a vector")} #check, if the dimensions are right
    wavelengths <- wavelengths[[1]] #save wavelengths as a vector
  }

  dirgetwd <- getwd()
  #additional infos, which are not included in dataprep.plsr
  add.infos <- suppressWarnings(list(dataprep.method = "fread.dataprep.plsr" ,sourcefile = file, sourceXfile = Xfile, sourceYfile = Yfile, sourceXcol = paste0(min(X.col),":",max(X.col)), sourceYcol = paste0(min(Y.col),":",max(Y.col)), directory = dirgetwd))

  #call dataprepfunction, which does the rest
  dataprep <- dataprep.plsr(X.values = X.values, Y.values = Y.values, wavelengths = wavelengths, centerY = centerY, originalY = originalY, UnitspecX = UnitspecX, UnitspecY = UnitspecY, repetitions = repetitions, add.infos = add.infos, printplots.TF = printplots.TF, rownames.X.Y = rownames.X.Y, colnames.X = colnames.X, colnames.Y = colnames.Y)
  cat(green("fread.dataprep.plsr completed\n"))
  return(dataprep)
}
