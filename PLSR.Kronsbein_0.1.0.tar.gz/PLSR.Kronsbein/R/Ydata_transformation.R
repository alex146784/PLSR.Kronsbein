#function to perform a Ydatatransformation
Ydata_transformation <- function(data, #PLSR.Kronbein dataset
                                 fun = NULL,#choose a predefined fucntion
                                 transformationFUN = NULL, #pass here the transformationfunction
                                 backtransformationFUN = NULL,#pass here the backtransformationfucntion, which undos the transformationfucntion
                                 whichYvalues = 1:ncol(data$prepdata$Y), #which Y.columns should be tranformed
                                 savedata.TF = TRUE,  #savedata to directoryPLS.methoddone
                                 centeredY = data$data.info$read.centeredY(), #were the Y-variables centered, normally TRUE
                                 othermean_for_centerY = NULL, #necessary for predictfunction
                                 silent = FALSE, #no consol output
                                 ...){

  cat(silver("Ydata_transformation started\n"))
  if(savedata.TF && (data$directorymethoddone$is.methoddone("Ydata_transformation"))){#it is not possible to perform this function more than once
    stop("It is only possible to perform the Ydata_tranformation once!")
  }
  if(savedata.TF && ((data$directorymethoddone$is.methoddone("centerY")) || (data$directorymethoddone$is.methoddone("standardizeY")) || (data$directorymethoddone$is.methoddone("scaleY")))){
    stop("Don't use centerY(), standardizeY(), scaleY() befor this function")
  }

  #predefined transformationfunctions
  if(is.null(transformationFUN)){
    switch(fun,
           "inverse" = {
             transformationFUN <- function(X){return(1/X)}
             backtransformationFUN <- function(X){return(1/X)}
           },
           "log10" = {
             transformationFUN <- function(X){return(log(X,10))}
             backtransformationFUN <- function(X){return(10^X)}
           },
           "square" = {
             transformationFUN <- function(X){return(X^2)}
             backtransformationFUN <- function(X){return(X^0.5)}
           },
           "root" = {
             transformationFUN <- function(X){return(X^0.5)}
             backtransformationFUN <- function(X){return(X^2)}
           },
           stop("no valid fun"))

  }else{
    if(!is.null(fun)){
      warning("fun is going not to be used, because a own tranformationFUN was passed.")
    }
    if(!is.null(backtransformationFUN)){
      warning("no backtransformationFUN was passed. Please pass one or set originalY in a dataprep.plsr() function to FALSE")
    }
  }

  Ydata <- data$oriY$Y.values[,whichYvalues, drop = FALSE]

  if(!is.matrix(Ydata)){Ydata <- as.matrix(Ydata)}
  databefor <- Ydata
  newYdata <- transformationFUN(Ydata)#perform transformation

  #center Y-values, to prevent mistakes in plsr function
  if(centeredY){
    if(is.null(othermean_for_centerY)){
      newYdata.ori <- newYdata #save original Y-values
      newYdata.mean <- apply(newYdata, MARGIN = 2, FUN = mean) #calculate means of the Responseparameters
      newYdata <- apply.t(newYdata, MARGIN = 1, FUN = substract.spectrum, mean.spec = newYdata.mean)#misused function, y values are not spectra, but it works in the same way
    }else{
      newYdata.ori <- newYdata #save original Y-values
      newYdata.mean <- othermean_for_centerY
      newYdata <- apply.t(newYdata, MARGIN = 1, FUN = substract.spectrum, mean.spec = newYdata.mean)#misused function, y values are not spectra, but it works in the same way
    }

    data.centerY <- list(newYdata.ori = newYdata.ori, newYdata.mean = newYdata.mean, newYdata = newYdata)
  }else{
    data.centerY <- NULL
  }



  if(savedata.TF){#save data to methoddone
    savedata <- list(databefor = databefor, dataafter = newYdata, data.centerY = data.centerY, transformationFUN = transformationFUN, backtransformationFUN = backtransformationFUN, whichYvalues = whichYvalues, centeredY = centeredY)
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object activ is necessary
    data$directorymethoddone$methoddone(whichmethod = "Ydata_transformation", data = savedata, data.info = data$data.info$clone(deep = TRUE))
  }

  data$prepdata$Y[,whichYvalues] <- newYdata

  if(centeredY){ #change original Y.values
    data$oriY$Y.values <- newYdata.ori
    data$oriY$Y.mean <- newYdata.mean
  }else{
    data$oriY$Y.values <- newYdata
    data$oriY$Y.mean <- NULL
  }
  cat(green("Ydata_transformation completed\n"))
  return(data)
}


