
#general internal function to perform centerX(), scaleX(), standardizeX()
centerX_scaleX_standardizeX <- function(data, #pass dataset of dataprep.plsr() or another dataprep function
                                     printplots.TF, #boolean to decide, if the spectrum is going to be printed
                                     method, #choose the method, "center", "scale", "standardize"
                                     scales = NULL, #if "scale" choosen as method, pass here the the scales
                                     savedata.TF = TRUE, #only set false in predict function, to perform method to new data
                                     referencedata = NULL, #referencedata of initially centering/standardisation, to perform method in the same way in the predict function
                                     ...){
  cat(silver("centerX_scaleX_standardizeX started\n"))

  check.data(data = data) #function to check, if there was passed a dataset

  wavelengths <- data$wavelengths #save wavelengths to a variable
  spectrums.orig <- data$prepdata$X #save original spectrums to a variable
  if(printplots.TF){printplot.allspectrums(X = wavelengths, Y = spectrums.orig, name = "original spectrum", xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), silent = TRUE)} #print all original plots, if this option was choosen

  if(savedata.TF){
    old.UnitspecX <- data$data.info$read.UnitspecX() #save old UnitspecX because scaling and standardizing is changing the Unit to no Unit
  }

  if(method == "centerX"){#make this if method is center

    if(is.null(referencedata)){#normal execution of center function
      spectrum.mean <- apply(spectrums.orig, MARGIN = 2, FUN = mean) #calculate the mean spectrum. function apply replaces a loop through each column (MARGIN = 2)
      output <- apply.t(spectrums.orig, MARGIN = 1, FUN = substract.spectrum, mean.spec = spectrum.mean) #substract the meanspectrum of each spectrum to center the spectrum. apply.t is a corrected version of apply(MARGIN = 2)
    }else{#excecution for predict function. Mean spectrum of initial center function will be used
      output <- apply.t(spectrums.orig, MARGIN = 1, FUN = substract.spectrum, mean.spec = referencedata) #substract the meanspectrum of each spectrum to center the spectrum. apply.t is a corrected version of apply(MARGIN = 2)
    }

    name.plot <- "centered spectrum" #save the right name for the next plot
  }

  if(method == "scaleX"){ #make this if method is scale
    #no split for initial and predict function, because for predict, the same scale could be used
    if(is.null(scales)){stop("to scale a spectrum, the scales have to be passed")} #test if scale was passed
    output <- apply.t(spectrums.orig, MARGIN = 1, FUN = divide.spectrum, scale.spec = 1/scales) #divide spectrum through reference spectrum. apply.t is a corrected version of apply(MARGIN = 2)
    name.plot <- "scaled spectrum" #save the right name for the next plot
    if(savedata.TF){ #if TRUE, change unit and save it to cloned data.info
      data$data.info <- data$data.info$clone(deep = TRUE)
      data$data.info$change.UnitspecY("scaled [no Unit]")
    }
  }

  if(method == "standardizeX"){ #make this if method is standardize
    if(savedata.TF){ #in the other case there is no directorymethoddone object
      if(savedata.TF && !(data$directorymethoddone$is.methoddone("centerX"))){ #give back a warning, if center function was not performed befor standardizing
        warning("It is useful to center the data first, befor to standardize them!")
      }
      data$data.info <- data$data.info$clone(deep = TRUE)
      data$data.info$change.UnitspecY("standardized [no Unit]")
    }

    if(is.null(referencedata)){#normal execution of standardize function
      spectrum.sd <- apply(spectrums.orig, MARGIN = 2, FUN = sd)# calculate standard deviation spectrum
      output <- apply.t(spectrums.orig, MARGIN = 1, FUN = divide.spectrum, scale.spec = spectrum.sd) #divide spectrum through reference spectrum. apply.t is a corrected version of apply(MARGIN = 2)
    }else{#excecution for predict function. Mean spectrum of initial center function will be used
      output <- apply.t(spectrums.orig, MARGIN = 1, FUN = divide.spectrum, scale.spec = referencedata) #divide spectrum through reference spectrum. apply.t is a corrected version of apply(MARGIN = 2)
    }

    name.plot <- "standardized spectrum" #save the right name for the next plot
  }

  if(printplots.TF){printplot.allspectrums(X = wavelengths, Y = output, name = name.plot, xlab = data$data.info$read.UnitspecX(), ylab = data$data.info$read.UnitspecY(), silent = TRUE)} #print all edited plots, if this option was choosen

  if(savedata.TF){ #data will be saved always, except the function is performed in the predict function
    #save interesting data depending on the method
    if(method == "centerX"){savedata <- list(databefor = spectrums.orig, dataafter = output, wavelengths = wavelengths, meanspectrum = spectrum.mean, old.UnitspecX = old.UnitspecX)}
    if(method == "scaleX"){savedata <- list(databefor = spectrums.orig, dataafter = output, wavelengths = wavelengths, scales = scales, old.UnitspecX = old.UnitspecX)}
    if(method == "standardizeX"){savedata <- list(databefor = spectrums.orig, dataafter = output, wavelengths = wavelengths, sdspectrum = spectrum.sd, old.UnitspecX = old.UnitspecX)}
    data$directorymethoddone <- data$directorymethoddone$clone(deep = TRUE) #clone object active is necessary
    data$directorymethoddone$methoddone(whichmethod = method, data = savedata, data.info <- data$data.info$clone(deep = TRUE)) #save all savedata to directorymethoddone object
  }
  data$prepdata$X <- output #save edited spectra to dataset
  cat(green("centerX_scaleX_standardizeX completed\n"))
  return(data)


}

centerX <- function(data, #pass dataset of fread.dataprep.plsr()
                   printplots.TF = FALSE, #boolean to decide, whether the spectrum is going to be printed
                   savedata.TF = TRUE, #only set false in predict function, to perform method to new data
                   referencedata = NULL, #referencedata of initially centering/standardisation, to perform method in the same way in the predict function
                   ...){
  output <- centerX_scaleX_standardizeX(data = data, printplots.TF = printplots.TF, method = "centerX", savedata.TF = savedata.TF, referencedata = referencedata)
  return(output)
}

scaleX <- function(data, #pass dataset of fread.dataprep.plsr()
                   scales = NULL, #vector with scales for the spectrum
                   printplots.TF = FALSE, #boolean to decide, whether the spectrum is going to be printed
                   savedata.TF = TRUE, #only set false in predict function, to perform method to new data
                   ...){
  output <- centerX_scaleX_standardizeX(data = data, printplots.TF = printplots.TF, scales = scales, method = "scaleX", savedata.TF = savedata.TF)
  return(output)
}

standardizeX <- function(data, #pass dataset of fread.dataprep.plsr()
                        printplots.TF = FALSE, #boolean to decide, whether the spectrum is going to be printed
                        savedata.TF = TRUE, #only set false in predict function, to perform method to new data
                        referencedata = NULL, #referencedata of initially centering/standardisation, to perform method in the same way in the predict function
                        ...){
  output <- centerX_scaleX_standardizeX(data = data, printplots.TF = printplots.TF, method = "standardizeX", savedata.TF = savedata.TF, referencedata = referencedata)
  return(output)
}
